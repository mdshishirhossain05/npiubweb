<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

//Home Route
Route::get('/', [HomeController::class, 'home'])->name('welcome');

//Other Routes
// Route::get('/undergraduate-program', function () {
//     return view('admission/undergraduate');
// });

// Undergraduate routes
Route::get('/undergraduate-program', [DepartmentController::class, 'undergraduateRequirements'])
    ->name('admission.undergrad');


// Graduate routes
Route::get('/graduate-program', [DepartmentController::class, 'graduateRequirements'])
    ->name('admission.graduate');
    
Route::get('/faqs', function () {
    return view('admission/faqs');
});

Route::get('/apply-admission', function () {
    return view('admission/apply');
});

Route::get('/board-of-trustees', function() {
    return view('trustee/board');
});

Route::get('/vision-mission', function() {
    return view('vision/vision-mission');
});


//Syndicate
Route::get('/syndicate', function() {
    return view('syndicate.syndicate');
})->name('syndicate');




//Academic Council

Route::get('/academic-council', function() {
    return view('academic_council.academic_council');
})->name('academic_council');




//Contact Routes
Route::get('/contact', [OfficesController::class, 'officeContact'])->name('contact.index');
Route::get('/location', [OfficesController::class, 'officeLocation'])->name('contact.location');
Route::post('/contact-send', [ContactController::class, 'sendMessage'])->name('contact.send');

//Departments Routes
Route::get('/departments/cse', [DepartmentController::class, 'cse'])->name('department.cse');
Route::get('/departments/eee', [DepartmentController::class, 'eee'])->name('department.eee');
Route::get('/departments/food-engineering', [DepartmentController::class, 'food_eng'])->name('department.food_eng');
Route::get('/departments/bba', [DepartmentController::class, 'bba'])->name('department.bba');
Route::get('/departments/mba', [DepartmentController::class, 'mba'])->name('department.mba');
Route::get('/departments/english', [DepartmentController::class, 'english'])->name('department.english');

//News Routes
Route::get('/news', [NewsController::class, 'index'])->name('news.archives');
Route::get('/news/{slug}', [NewsController::class, 'view'])->name('news.view');

//Galleries Routes
Route::get('/galleries', [GalleryController::class, 'index'])->name('galleries.galleries');


//Alumni Routes
Route::get('/alumni', [AlumniController::class, 'index'])->name('alumni.alumni');
Route::get('/alumni/{slug}', [AlumniController::class, 'view'])->name('alumni.view');

//Offices Routes
Route::get('/offices/vice-chancellor', [OfficesController::class, 'viceChancellor'])->name('offices.vice_chancellor');
Route::get('/offices/pro-vc', [OfficesController::class, 'proVc'])->name('offices.pro_vc');
Route::get('/offices/treasurer', [OfficesController::class, 'treasurer'])->name('offices.treasurer');
Route::get('/offices/registrar', [OfficesController::class, 'registrar'])->name('offices.registrar');
Route::get('/offices/controller_of_examinations', [OfficesController::class, 'controllerOfExaminations'])->name('offices.controller_of_examinations');
Route::get('/offices/director_of_accounts', [OfficesController::class, 'directorOfAccounts'])->name('offices.director_of_accounts');
Route::get('/offices/library', [OfficesController::class, 'library'])->name('offices.library');
Route::get('/offices/admissions', [OfficesController::class, 'admissions'])->name('offices.admissions');
Route::get('/offices/iqac', [OfficesController::class, 'iqac'])->name('offices.iqac');

//Notices Routes
Route::get('/notices', [NoticeController::class, 'index'])->name('notices.board');
Route::get('/notices/{slug}', [NoticeController::class, 'view'])->name('notices.view');

//Research Routes
Route::get('/research', [ResearchController::class, 'index'])->name('research.archives');
Route::get('/research/{slug}', [ResearchController::class, 'view'])->name('research.view');

Route::get('/faculties/{slug}', [FacultyController::class, 'view'])->name('faculties.view');
Route::get('/officers/{slug}', [OfficersController::class, 'view'])->name('officers.view');
Route::get('/offices/{slug}', [OfficesController::class, 'view'])->name('offices.view');




