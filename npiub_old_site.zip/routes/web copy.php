
<?php

use App\Http\Controllers\Admin\HomeController as AdminHomeController;
use App\Http\Controllers\Admin\OfficesController as AdminOfficesController;
use App\Http\Controllers\Admin\NewsController as AdminNewsController;
use App\Http\Controllers\Admin\ResearchController as AdminResearchController;
use App\Http\Controllers\Admin\FacultyController as AdminFacultyController;
use App\Http\Controllers\Admin\GalleryController as AdminGalleryController;
use App\Http\Controllers\Admin\AlumniController as AdminAlumniController;
use App\Http\Controllers\Admin\ContactMessageController as AdminContactMessageController;

use App\Http\Controllers\HomeController as PublicHomeController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\OfficesController as PublicOfficesController;
use App\Http\Controllers\NewsController as PublicNewsController;
use App\Http\Controllers\ResearchController as PublicResearchController;
use App\Http\Controllers\AlumniController as PublicAlumniController;
use App\Http\Controllers\NoticeController as PublicNoticeController;
use App\Http\Controllers\Admin\NoticeController as AdminNoticeController;
use App\Http\Controllers\FacultyController as PublicFacultyController;
use App\Http\Controllers\OfficersController as PublicOfficersController;
use App\Http\Controllers\Admin\OfficersController as AdminOfficersController;
use App\Http\Controllers\GalleryController as PublicGalleryController;
use App\Http\Controllers\ContactController as PublicContactController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\AdmissionController;

// Public Routes
Route::get('/', [PublicHomeController::class, 'home']);

Route::get('/news-archives', [PublicNewsController::class, 'index'])->name('news.archives');
Route::get('/news/{slug}', [PublicNewsController::class, 'show'])->name('news.show'); // Updated route name

Route::get('/undergraduate-program', function () {
    return view('admission/undergraduate');
});
Route::get('/graduate-program', function () {
    return view('admission/graduate');
});
Route::get('/faqs', function () {
    return view('admission/faqs');
});
Route::get('/apply-admission', [AdmissionController::class, 'apply'])->name('admission.apply');

// Contact Routes
Route::get('/contact', [PublicOfficesController::class, 'officeContact'])->name('contact.index');
Route::get('/location', [PublicOfficesController::class, 'officeLocation'])->name('contact.location');
Route::post('/contact-send', [PublicContactController::class, 'sendMessage'])->name('contact.send');

// Departments Routes
Route::get('/department-cse', [DepartmentController::class, 'cse'])->name('department.cse');
Route::get('/department-eee', [DepartmentController::class, 'eee'])->name('department.eee');
Route::get('/department-food-engineering', [DepartmentController::class, 'food_eng'])->name('department.food_eng');
Route::get('/department-bba', [DepartmentController::class, 'bba'])->name('department.bba');
Route::get('/department-mba', [DepartmentController::class, 'mba'])->name('department.mba');
Route::get('/department-english', [DepartmentController::class, 'english'])->name('department.english');

// Galleries Routes
Route::get('/galleries', [PublicGalleryController::class, 'index'])->name('galleries.index');

// Alumni Routes
Route::get('/alumni', [PublicAlumniController::class, 'index'])->name('alumni.index');

// Offices Routes
Route::get('/offices/vice-chancellor', [PublicOfficesController::class, 'viceChancellor'])->name('offices.vice_chancellor');
Route::get('/offices/pro-vc', [PublicOfficesController::class, 'proVc'])->name('offices.pro_vc');
Route::get('/offices/treasurer', [PublicOfficesController::class, 'treasurer'])->name('offices.treasurer');
Route::get('/offices/registrar', [PublicOfficesController::class, 'registrar'])->name('offices.registrar');
Route::get('/offices/controller_of_examinations', [PublicOfficesController::class, 'controllerOfExaminations'])->name('offices.controller_of_examinations');
Route::get('/offices/director_of_accounts', [PublicOfficesController::class, 'directorOfAccounts'])->name('offices.director_of_accounts');
Route::get('/offices/library', [PublicOfficesController::class, 'library'])->name('offices.library');
Route::get('/offices/admissions', [PublicOfficesController::class, 'admissions'])->name('offices.admissions');
Route::get('/offices/iqac', [PublicOfficesController::class, 'iqac'])->name('offices.iqac');

// Notices Routes
Route::get('/notices', [PublicNoticeController::class, 'index'])->name('notices.index');

// Research Routes
Route::get('/research-archives', [PublicResearchController::class, 'index'])->name('research.archives');

// Admin Routes
Route::middleware(['auth', 'verified'])->prefix('admin')->group(function () {
    Route::get('/', function () {
        return view('admin.home');
    })->name('dashboard');

    // Profile Management Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // User Management Routes
    Route::resource('users', AdminUserController::class);

    // Offices Management Routes
    Route::resource('offices', AdminOfficesController::class);

    // News Management Routes
    Route::resource('news', AdminNewsController::class)->names([
        'index' => 'news.index',
        'create' => 'news.create',
        'store' => 'news.store',
        'show' => 'admin.news.show',
        'edit' => 'news.edit',
        'update' => 'news.update',
        'destroy' => 'news.destroy',
    ]);

    // Research Management Routes
    Route::resource('research', AdminResearchController::class);

    // Alumni Management Routes
    Route::resource('alumni', AdminAlumniController::class);

    // Notice Management Routes
    Route::resource('notices', AdminNoticeController::class);

    // Faculties Management Routes
    Route::resource('faculties', AdminFacultyController::class);

    // Officers Management Routes
    Route::resource('officers', AdminOfficersController::class);

    // Galleries Management Routes
    Route::resource('galleries', AdminGalleryController::class);
});

// Auth routes
require __DIR__.'/auth.php';
