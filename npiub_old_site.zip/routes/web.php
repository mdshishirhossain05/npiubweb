<?php


// Auth routes
require __DIR__.'/public.php';

// Auth routes
require __DIR__.'/admin.php';

// Auth routes
require __DIR__.'/auth.php';
