<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\HomeController ;
use App\Http\Controllers\Admin\OfficesController as AdminOfficesController;
use App\Http\Controllers\Admin\NewsController as AdminNewsController;
use App\Http\Controllers\Admin\ResearchController as AdminResearchController;
use App\Http\Controllers\Admin\AlumniController as AdminAlumniController;
use App\Http\Controllers\Admin\NoticeController as AdminNoticeController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Admin\FacultyController as AdminFacultyController;
use App\Http\Controllers\Admin\OfficersController as AdminOfficersController;
use App\Http\Controllers\Admin\GalleryController as AdminGalleryController;
use App\Http\Controllers\Admin\ContactMessageController;

use App\Http\Controllers\HomeController as FrontendHomeController;
use App\Http\Controllers\ContactController as FrontendContactController;
use App\Http\Controllers\OfficesController as FrontendOfficesController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\NewsController as FrontendNewsController;
use App\Http\Controllers\GalleryController as FrontendGalleryController;
use App\Http\Controllers\AlumniController as FrontendAlumniController;
use App\Http\Controllers\NoticeController as FrontendNoticeController;
use App\Http\Controllers\ResearchController as FrontendResearchController;
use App\Http\Controllers\FacultyController as FrontendFacultyController;
use App\Http\Controllers\OfficerController as FrontendOfficerController;

//Home Route
Route::get('/', [FrontendHomeController::class, 'home'])->name('welcome');

//Other Routes
Route::get('/undergraduate-program', function () {
    return view('admission/undergraduate');
});
Route::get('/graduate-program', function () {
    return view('admission/graduate');
});
Route::get('/faqs', function () {
    return view('admission/faqs');
});

//Contact Routes
Route::get('/contact', [FrontendOfficesController::class, 'officeContact'])->name('contact.index');
Route::get('/location', [FrontendOfficesController::class, 'officeLocation'])->name('contact.location');
Route::post('/contact-send', [FrontendContactController::class, 'sendMessage'])->name('contact.send');

//Departments Routes
Route::get('/department-cse', [DepartmentController::class, 'cse'])->name('department.cse');
Route::get('/department-eee', [DepartmentController::class, 'eee'])->name('department.eee');
Route::get('/department-food-engineering', [DepartmentController::class, 'food_eng'])->name('department.food_eng');
Route::get('/department-bba', [DepartmentController::class, 'bba'])->name('department.bba');
Route::get('/department-mba', [DepartmentController::class, 'mba'])->name('department.mba');
Route::get('/department-english', [DepartmentController::class, 'english'])->name('department.english');

//News Routes
Route::get('/news', [FrontendNewsController::class, 'index'])->name('news.archives');
Route::get('/news/{slug}', [FrontendNewsController::class, 'view'])->name('news.view');

//Galleries Routes
Route::get('/galleries', [FrontendGalleryController::class, 'index'])->name('galleries.galleries');


//Alumni Routes
Route::get('/alumni', [FrontendAlumniController::class, 'index'])->name('alumni.alumni');
Route::get('/alumni/{slug}', [FrontendAlumniController::class, 'view'])->name('alumni.view');

//Offices Routes
Route::get('/offices/vice-chancellor', [FrontendOfficesController::class, 'viceChancellor'])->name('offices.vice_chancellor');
Route::get('/offices/pro-vc', [FrontendOfficesController::class, 'proVc'])->name('offices.pro_vc');
Route::get('/offices/treasurer', [FrontendOfficesController::class, 'treasurer'])->name('offices.treasurer');
Route::get('/offices/registrar', [FrontendOfficesController::class, 'registrar'])->name('offices.registrar');
Route::get('/offices/controller_of_examinations', [FrontendOfficesController::class, 'controllerOfExaminations'])->name('offices.controller_of_examinations');
Route::get('/offices/director_of_accounts', [FrontendOfficesController::class, 'directorOfAccounts'])->name('offices.director_of_accounts');
Route::get('/offices/library', [FrontendOfficesController::class, 'library'])->name('offices.library');
Route::get('/offices/admissions', [FrontendOfficesController::class, 'admissions'])->name('offices.admissions');
Route::get('/offices/iqac', [FrontendOfficesController::class, 'iqac'])->name('offices.iqac');

//Notices Routes
Route::get('/notices', [FrontendNoticeController::class, 'index'])->name('notices.board');
Route::get('/notices/{slug}', [FrontendNoticeController::class, 'view'])->name('notices.view');

//Research Routes
Route::get('/research', [FrontendResearchController::class, 'index'])->name('research.archives');
Route::get('/research/{slug}', [FrontendResearchController::class, 'view'])->name('research.view');

Route::get('/faculties/{slug}', [FrontendFacultyController::class, 'view'])->name('faculties.view');
Route::get('/officers/{slug}', [FrontendOfficerController::class, 'view'])->name('officers.view');

// Load the frontend routes

// Load the admin routes

Route::middleware(['auth', 'verified'])->group(function () {
    // Dashboard Route
    Route::get('/admin', function () {
        return view('admin.home');
    })->name('dashboard');

    

    // Profile Management Routes
    Route::get('admin/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('admin/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('admin/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // News Management Routes


    // Offices Management Routes
    // User Management Routes
    Route::resource('/admin/users', AdminUserController::class);
    Route::resource('/admin/faculties', AdminFacultyController::class);
    Route::resource('/admin/offices', AdminOfficesController::class);
    Route::resource('/admin/alumni', AdminAlumniController::class);
    Route::resource('/admin/research', AdminResearchController::class);
    Route::resource('/admin/news', AdminNewsController::class);
    Route::resource('/admin/notices', AdminNoticeController::class);
    Route::resource('/admin/officers', AdminOfficersController::class);
    Route::resource('/admin/galleries', AdminGalleryController::class);

    
        // List all contact messages
        Route::get('admin/contact-messages', [ContactMessageController::class, 'index'])->name('contact-messages.index');
    
        // Show a single contact message
        Route::get('admin/contact-messages/{id}', [ContactMessageController::class, 'show'])->name('contact-messages.show');
    
        // Delete a contact message
        Route::delete('admin/contact-messages/{id}', [ContactMessageController::class, 'destroy'])->name('contact-messages.destroy');
    
        // Reply to a contact message
        Route::post('admin/contact-messages/{id}/reply', [ContactMessageController::class, 'reply'])->name('contact-messages.reply');
    
});




// Auth routes
require __DIR__.'/auth.php';
