<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Load the admin routes

Route::middleware(['auth', 'verified'])->prefix('admin')->group(function () {
    // Dashboard Route
    Route::get('/', function () {
        return view('admin.home');
    })->name('dashboard');

    

    // Profile Management Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // News Management Routes


    // Offices Management Routes
    // User Management Routes
    Route::resource('/users', UserController::class);
    Route::resource('/faculties', FacultyController::class);
    Route::resource('/offices', OfficesController::class);
    Route::resource('/alumni', AlumniController::class);
    Route::resource('/research', ResearchController::class);
    Route::resource('/news', NewsController::class);
    Route::resource('/notices', NoticeController::class);
    Route::resource('/officers', OfficersController::class);
    Route::resource('/galleries', GalleryController::class);

    
        // List all contact messages
        Route::get('/contact-messages', [ContactMessageController::class, 'index'])->name('contact-messages.index');
    
        // Show a single contact message
        Route::get('/contact-messages/{id}', [ContactMessageController::class, 'show'])->name('contact-messages.show');
    
        // Delete a contact message
        Route::delete('/contact-messages/{id}', [ContactMessageController::class, 'destroy'])->name('contact-messages.destroy');
    
        // Reply to a contact message
        Route::post('/contact-messages/{id}/reply', [ContactMessageController::class, 'reply'])->name('contact-messages.reply');
    
});