<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'এনপিআইইউবি')</title>

    <link rel="stylesheet" href="{{ asset('css/app.css') }}">

    <style>
        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            /* VERY IMPORTANT: do NOT use overflow:hidden here */
            overflow-y: auto;
        }

        .page-wrapper {
            flex: 1 0 auto; /* grow to take all remaining height */
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1 0 auto; /* this part scrolls if content is taller */
        }

        footer {
            flex-shrink: 0; /* footer stays at the bottom, but scrolls normally */
        }
    </style>
</head>
<body>

    <div class="page-wrapper">
        @include('partials.header')
        @include('partials.mobilehead')

        <main>
            @yield('content')
        </main>

        @include('partials.footer')
    </div>

</body>
</html>
