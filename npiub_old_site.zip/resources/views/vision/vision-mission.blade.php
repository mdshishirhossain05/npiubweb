@extends('layouts.default')

@section('title', 'Vision & Mission - NPIUB, North Pacific International University of Bangladesh')

@section('content')
<style>
/* Custom Styling (Optional) */
.vision-mission-section {
    background: #f8f9fa;
    padding: 60px 0;
}
.vision-mission-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    padding: 30px;
    transition: all 0.3s ease;
}
.vision-mission-card:hover {
    transform: translateY(-5px);
}
.vision-mission-icon {
    font-size: 2.5rem;
    color: #054D94;
    margin-bottom: 15px;
}
.vision-mission-title {
    color: #054D94;
    font-weight: 700;
    margin-bottom: 15px;
}
</style>

<section class="vision-mission-section">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="fw-bold vision-mission-title">Our Vision & Mission</h1>
            <p class="text-muted">
                Learn more about our commitment to excellence and the guiding principles that drive our institution.
            </p>
        </div>

        <div class="row g-4">
            <!-- Vision -->
            <div class="col-md-6">
                <div class="vision-mission-card h-100">
                    <div class="text-center">
                        <i class="bi bi-eye vision-mission-icon"></i>
                        <h4 class="vision-mission-title">Our Vision</h4>
                    </div>
                    <p class="text-muted">
                        To be a center of academic excellence and innovation in higher education—recognized nationally and globally for producing competent, ethical, and socially responsible graduates who will lead positive change in technology, industry, and society.
                    </p>
                </div>
            </div>

            <!-- Mission -->
            <div class="col-md-6">
                <div class="vision-mission-card h-100">
                    <div class="text-center">
                        <i class="bi bi-bullseye vision-mission-icon"></i>
                        <h4 class="vision-mission-title">Our Mission</h4>
                    </div>
                     <p class="text-muted">
                        To foster an environment of excellence in teaching, research, and innovation that empowers students with knowledge, technical competence, and ethical values. NPI University of Bangladesh is committed to developing skilled graduates who can contribute effectively to national development and global advancement through critical thinking, creativity, and lifelong learning.

                    </p>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <a href="{{ url('/') }}" class="btn btn-primary px-4 py-2 rounded-pill">
                Back to Home
            </a>
        </div>
    </div>
</section>
@endsection
