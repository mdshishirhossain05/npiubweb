@extends('layouts.default')

@section('title', 'সিন্ডিকেট - এনপিআইইউবি')

@section('content')

<section class="page-header py-5">
    <div class="container">
        <h1 class="mb-3">সিন্ডিকেট</h1>
        <p class="lead">
            এনপিআইইউবির সিন্ডিকেট হলো বিশ্ববিদ্যালয়ের প্রশাসনিক ও নীতিনির্ধারণী 
            সর্বোচ্চ নির্বাহী কমিটি।
        </p>
    </div>
</section>

<section class="py-4">
    <div class="container">

        <h2 class="h4 mb-3">সিন্ডিকেটের সম্মানিত সদস্যবৃন্দ</h2>

        <div class="table-wrapper shadow-sm bg-white p-3 rounded-3">

            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0 syndicate-table">
                    <thead class="table-light">
                        <tr>
                            <th class="text-center th-serial">ক্রম</th>
                            <th class="th-role">ভূমিকা</th>
                            <th class="th-name">নাম</th>
                            <th class="th-details">পদবি / পরিচিতি</th>
                        </tr>
                    </thead>

                    <tbody>

                        {{-- Row 1 --}}
                        <tr>
                            <td class="text-center">১</td>
                            <td>সভাপতি</td>
                            <td>প্রফেসর ড. মোঃ ফরহাদ হোসেন</td>
                            <td>উপাচার্য, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 2 --}}
                        <tr>
                            <td class="text-center">২</td>
                            <td>সদস্য</td>
                            <td>অধ্যাপক ড. মীর মাহফুজুল হক</td>
                            <td>ট্রেজারার, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 3 --}}
                        <tr>
                            <td class="text-center">৩</td>
                            <td>সদস্য</td>
                            <td>মোঃ মোশাররফ হোসেন</td>
                            <td>পরীক্ষা নিয়ন্ত্রক, উপাচার্য কর্তৃক মনোনীত, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 4 --}}
                        <tr>
                            <td class="text-center">৪</td>
                            <td>সদস্য</td>
                            <td>বীর মুক্তিযোদ্ধা প্রফেসর ড. ফরমুজুল হক</td>
                            <td>ডীন, ইঞ্জিনিয়ারিং অনুষদ, উপাচার্য কর্তৃক মনোনীত, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 5 --}}
                        <tr>
                            <td class="text-center">৫</td>
                            <td>সদস্য</td>
                            <td>সরকার কর্তৃক মনোনীত একজন সদস্য</td>
                            <td>সরকার মনোনীত সদস্য</td>
                        </tr>

                        {{-- Row 6 --}}
                        <tr>
                            <td class="text-center">৬</td>
                            <td>সদস্য</td>
                            <td>বীর মুক্তিযোদ্ধা মোঃ ইদ্রিস আলী</td>
                            <td>বোর্ড অব ট্রাস্টিজ কর্তৃক মনোনীত সদস্য, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 7 --}}
                        <tr>
                            <td class="text-center">৭</td>
                            <td>সদস্য</td>
                            <td>এফ. এম. এ. সালাম</td>
                            <td>বোর্ড অব ট্রাস্টিজ কর্তৃক মনোনীত সদস্য, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 8 --}}
                        <tr>
                            <td class="text-center">৮</td>
                            <td>সদস্য</td>
                            <td>ইঞ্জিঃ নির্মল চন্দ্র সিকদার</td>
                            <td>বোর্ড অব ট্রাস্টিজ কর্তৃক মনোনীত সদস্য, এনপিআইইউবি</td>
                        </tr>

                        {{-- Row 9 --}}
                        <tr>
                            <td class="text-center">৯</td>
                            <td>সদস্য</td>
                            <td>প্রফেসর ড. মোহাম্মদ আলমুজাদ্দিদ আলফেসানি</td>
                            <td>ইউজিসি কর্তৃক মনোনীত সদস্য</td>
                        </tr>

                        {{-- Row 10 --}}
                        <tr>
                            <td class="text-center">১০</td>
                            <td>সদস্য সচিব</td>
                            <td>মুহাম্মাদ আবদুল গফুর</td>
                            <td>রেজিস্ট্রার, এনপিআইইউবি</td>
                        </tr>

                    </tbody>
                </table>
            </div>

        </div>

    </div>
</section>

@endsection

@push('styles')
<style>
    .table-wrapper {
        border-radius: 12px;
        border: 1px solid #e5e7eb;
    }

    /* Desktop widths */
    .th-serial { width: 70px; }
    .th-role { width: 170px; }
    .th-name { width: 230px; }
    .th-details { width: 260px; }

    .table-bordered tbody tr:hover {
        background-color: #f0f7ff;
        transition: 0.2s ease-in-out;
    }

    /* Mobile responsive */
    @media (max-width: 768px) {

        .th-serial,
        .syndicate-table td:nth-child(1) {
            min-width: 80px !important;
        }

        .th-role,
        .syndicate-table td:nth-child(2) {
            min-width: 140px !important;
        }

        .th-name,
        .syndicate-table td:nth-child(3) {
            min-width: 200px !important;
        }

        .th-details,
        .syndicate-table td:nth-child(4) {
            min-width: 240px !important;
        }

        .syndicate-table td,
        .syndicate-table th {
            font-size: 0.95rem !important;
            padding: 0.65rem 0.75rem !important;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
        }
    }
</style>
@endpush
