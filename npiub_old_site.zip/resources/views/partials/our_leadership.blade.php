<section class="home-leadership py-5">
    <div class="container">

        {{-- Section Heading --}}
        <div class="text-center mb-5">
            <h2 class="leadership-title mb-2">Meet Our Leadership</h2>
            <p class="leadership-subtitle mb-3">
                Meet the dedicated individuals guiding our university towards a brighter future.
            </p>
            <div class="leadership-underline mx-auto"></div>
        </div>

        {{-- Leadership Cards --}}
        <div class="row justify-content-center g-4">

            {{-- Chairman --}}
            <div class="col-md-6 mb-4 mb-md-0">
                <div class="leadership-card h-100 text-center">

                    {{-- Image Circle --}}
                    <div class="leadership-avatar-wrapper mx-auto mb-4">
                        <div class="leadership-avatar-circle">
                            <img src="{{ asset('/images/ourleadership/1.2.md._shamsur_rahman.jpeg') }}"
                                 alt="Md. Shamsur Rahman"
                                 class="leader-photo">
                        </div>
                    </div>

                    {{-- Text --}}
                    <h5 class="leader-name mb-1">Md. Shamsur Rahman</h5>
                    <p class="leader-position mb-3">Chairman, Board of Trustees</p>

                    <p class="leader-quote mb-4">
                        "Guiding NPI University with vision, integrity, and a commitment to excellence."
                    </p>

                    <!--<a href="#" class="btn leadership-btn">View Profile</a>-->
                </div>
            </div>

            {{-- Vice Chancellor --}}
            <div class="col-md-6">
                <div class="leadership-card h-100 text-center">

                    {{-- Image Circle --}}
                    <div class="leadership-avatar-wrapper mx-auto mb-4">
                        <div class="leadership-avatar-circle">
                            <img src="{{ asset('images/ourleadership/prof-dr-md-forhad-hossain.jpg') }}"
                                 alt="Prof. Dr. Md. Forhad Hossain"
                                 class="leader-photo">

                        </div>
                    </div>

                    {{-- Text --}}
                    <h5 class="leader-name mb-1">Prof. Dr. Md. Forhad Hossain</h5>
                    <p class="leader-position mb-3">Vice Chancellor</p>

                    <p class="leader-quote mb-4">
                        "Empowering the next generation through education, innovation, and values."
                    </p>

                    <!--<a href="#" class="btn leadership-btn">View Profile</a>-->
                </div>
            </div>

        </div>
    </div>
</section>

{{-- ======================= STYLES ======================= --}}
<style>
    .home-leadership {
        background-color: #f6f8fb;
    }

    .leadership-title {
        font-weight: 700;
        color: #203a8f;
    }

    .leadership-subtitle {
        max-width: 620px;
        margin-left: auto;
        margin-right: auto;
        color: #6c757d;
        font-size: 0.98rem;
    }

    .leadership-underline {
        width: 80px;
        height: 3px;
        border-radius: 999px;
        background-color: #203a8f;
    }

    .leadership-card {
        background-color: #ffffff;
        border-radius: 24px;
        padding: 40px 30px;
        box-shadow: 0 12px 24px rgba(15, 35, 90, 0.05);
    }

    .leadership-avatar-wrapper {
        width: 180px;
    }

    .leadership-avatar-circle {
        width: 180px;
        height: 180px;
        border-radius: 50%;
        border: 4px solid #203a8f;
        padding: 4px;              /* small gap between border and image */
        background-color: #ffffff;  /* inner background same as card */
        overflow: hidden;
        margin: 0 auto;
    }

    .leader-photo {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        object-fit: cover;
        display: block;
    }

    .leader-name {
        font-size: 1.2rem;
        font-weight: 700;
        color: #1f2937;
    }

    .leader-position {
        font-size: 0.95rem;
        color: #3650a3;
        font-weight: 500;
    }

    .leader-quote {
        font-size: 0.95rem;
        color: #6b7280;
        min-height: 40px;
    }

    .leadership-btn {
        border-radius: 999px;
        padding: 10px 28px;
        font-weight: 600;
        background-color: #253b9a;
        color: #ffffff;
        border: none;
    }

    .leadership-btn:hover {
        background-color: #1c2f7a;
        color: #ffffff;
    }
</style>
