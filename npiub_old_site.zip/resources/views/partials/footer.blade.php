
  <style>
    
    footer {
     background-color: #ffffff;
background-image: url("https://www.transparenttextures.com/patterns/ag-square.png");
/* This is mostly intended for prototyping; please download the pattern and re-host for production environments. Thank you! */
      padding: 4rem 0;
    }
    
    footer h5{
      color: #054D94 !important;
    }

    .about_info{
      margin-right: 1rem;
    }


    /* Social Icons */
    .social-icons {
      list-style-type: none;
      padding: 0;
    }

    .social-icons li {
      display: inline-block;
      margin-right: 10px;
    }

    .social-icons li a {
      display: block;
      width: 40px; /* Adjust size as needed */
      height: 40px; /* Adjust size as needed */
      line-height: 40px; /* Center the icon vertically */
      text-align: center; /* Center the icon horizontally */
      background-color: #054D94; /* Background color of the round icon */
      color: #ffffff;
      border-radius: 50%; /* Make the icon round */
      transition: transform 0.3s ease; /* Add transition for zoom effect */
      
    }

    .social-icons li a:hover {
      transform: scale(1.2); /* Zoom effect on hover */
    }
    
    .footer-column-list{
        text-decoration: underline;
        color: #054D94;
    }
    
    .footer-icon{
        color: #054D94;
    }
    
    

    .btn-primary{
      background-color: #054D94;
    }

    .btn-secondary a{
      color: #ffffff;
    }

    footer span{
        display: flex;
        align-items: center;
        gap: 20px;
      } 

    .locations p{
      margin-bottom: 0.5rem;
    }



    .toggle-icon {
      display: none; /* Hide toggle icon by default */
    }

    
    @media (max-width: 767.98px) {
      .toggle-icon {
        display: inline-block; /* Display toggle icon only on smaller screens */
        cursor: pointer;
      }
      
    }
    /* Add border-bottom after headings in smaller screens */
    @media (max-width: 767.98px) {
      .footer-column-toggle {
        cursor: pointer;
        border-bottom: 1px solid #054D94;
        padding-bottom: 10px; /* Add some spacing below the heading */
        margin-bottom: 15px; /* Add additional margin below the heading */
        display: flex;
        justify-content: space-between;
        align-items: center;
        touch-action: manipulation;
      } 
    }
  </style>


  <!-- Footer -->
  <footer class="text-left">
    <div class="container text-left" id="accordion">
      <div class="row">
        <div class="col-md-4">
          <h5 class="footer-column-toggle">About NPIUB <i class="fa-regular fa-plus fa-lg toggle-icon"></i></h5>
          <div class="collapse">
            <p class="about_info" style="text-align: justify;">Welcome to your path to excellence in Manikganj. The only private university near Hemayetpur, Manikganj, Dhaka, offering Friday and Saturday classes for Working Professionals. Explore our Departments: CSE, EEE, Food Eng., Business, and English. <a href="#">Read more</a></p>

            <!-- Social Icons -->
            <ul class="list-inline social-icons">
              <li class="list-inline-item"><a href="#"><i class="fab fa-facebook fa-lg"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-twitter fa-lg"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-youtube fa-lg"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin fa-lg"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-3">
          <h5 class="footer-column-toggle">Admission <i class="fa-regular fa-plus fa-lg toggle-icon"></i></h5>
          <div class="collapse">
            <ul class="list-unstyled footer-column-list">
              <li><a href="{{ url('/undergraduate-program') }}">Undergraduate pro requirements</a></li>
              <li><a href="#">Brochure/Flyer</a></li>
              <li><a href="#">Financial Aid & Scholars</a></li>
              <li><a href="{{ url('/faqs') }}">Admission FAQs</a></li>
            </ul>
            <a href="{{ url('apply-admission') }}" class="btn btn-primary mb-4">Apply Admission</a>
          </div>
        </div>
        <div class="col-md-2">
          <h5 class="footer-column-toggle">Quick Links <i class="fa-regular fa-plus fa-lg toggle-icon"></i></h5>
          <div class="collapse">
            <ul class="list-unstyled footer-column-list">
              <li><a href="#">Forms & Downloads</a></li>
              <li><a href="#">Career of NPIUB</a></li>
              <li><a href="#">Online Services</a></li>
              <li><a href="#">Academic Calendar</a></li>
              <li><a href="#">Site Map</a></li>
              <li><a href="{{ url('/') }}" class="">Back to Home</a></li>
            </ul>
          </div>
        </div>
        
        <div class="col-md-3 locations">
          <h5 class="footer-column-toggle">Locations <i class="fa-regular fa-plus fa-lg toggle-icon"></i></h5>
          <div class="collapse">
            <ul class="list-unstyled ">
              <li>
                <span>
                  <p><i class="fa-duotone fa-location-dot fa-lg footer-icon"></i></p>
                  <p>495, East Basta, Singair,<br> Manikganj, Dhaka</p>
                </span>
              </li>
              <li>
                <span>
                  <p><i class="fa-duotone fa-map-location-dot fa-lg footer-icon"></i></p>
                  <p><a class="footer-column-list" href="{{ route('contact.location') }}">View in google map</a></p>
                </span>
              </li>
              <li>
                <span>
                  <p><i class="fa-duotone fa-address-book fa-lg footer-icon"></i></p>
                  <p><a class="footer-column-list" href="{{ route('contact.index') }}">Useful contact details</a></p>
                </span>
              </li>
              <li>
                <span>
                  <p><i class="fa-duotone fa-user-clock fa-lg footer-icon"></i></p>
                  <p>Mon & Tue: Closed <br>Wed - Sun: 8 AM-4 PM</p>
                </span>
              </li>
              <li>
                <span>
                  <p><i class="fa-duotone fa-envelope fa-lg footer-icon"></i></p>
                  <p><a class="footer-column-list" href="mailto:info@npiub.edu.bd">info@npiub.edu.bd</a></p>
                </span>
              </li>
              <li>
                <span>
                  <p><i class="fa-duotone fa-solid fa-user-headset fa-lg"></i></p>
                  <p><a href="tel:01969-992015">01969-992015</a> Hot-Line (24/7)</p>
                </span>
              </li>
              <li>
                <span>
                  <p><i class="fa-duotone fa-phone fa-lg footer-icon"></i></p>
                  <p><a href="tel:01703444111">01703-444111</a>, <a href="tel:01704444888">01704-444888</a></p>
                </span>
              </li>
            </ul>
          </div>
        </div>
        
      </div>
      
    </div>
  </footer>

  <section class="p-0">
    <div class="container-fluid text-center text-white p-3" style="background-color: #054D94;">
      <p class="m-0">&copy; 2025 NPI University of Bangladesh.</p>
    </div>
  </section>

  

  <!-- Custom JavaScript -->
  <script>
      $(document).ready(function(){
        // Toggle collapse/expand only on smaller screens
        $('footer .footer-column-toggle').click(function(){
          if ($(window).width() < 768) {
            $(this).next('.collapse').collapse('toggle');
            $(this).find('.toggle-icon').toggleClass('fa-plus fa-minus');
          }
        });
        // Show collapsed elements on larger screens
        $(window).on('resize', function() {
          if ($(window).width() >= 768) {
            $('footer .collapse').collapse('show');
          }
        }).resize(); // Trigger resize event on page load
      });
    </script>

    

</body>
</html>
