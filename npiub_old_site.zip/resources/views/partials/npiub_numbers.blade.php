
    <style>
        /*body {*/
        /*    background-color: #f0f4f8;*/
        /*}*/

        .counter-box {
            background: #ffffff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%; /* Ensure the box takes full height of the column */
        }

        .counter-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        .count {
            font-size: 3.2rem;
            font-weight: bold;
            color: #ff4500;
        }

        .counter-title {
            font-size: 1.2rem;
            font-weight: bold;
            margin-top: 10px;
            color: #054D94;
        }

        .icon {
            font-size: 40px;
            color: #054D94; /* Icon color */
            /* margin-bottom: 10px; */
        }

        .numbers-head{
          color: #054D94;
        }
    </style>

    <div class="section-numbers">
        <div class="container text-center my-5">
      <h2 class="numbers-head mb-5"><strong>NPIUB in Numbers</strong></h2>
        <div class="row d-flex align-items-stretch">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="counter-box">
                    <i class="bi bi-buildings-fill icon"></i> <!-- Icon for Founded -->
                    <div class="counter-title">Founded</div>
                    <span class="count" data-count="2015">2015</span>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="counter-box">
                    <i class="bi bi-building-fill-gear icon"></i> <!-- Icon for Faculties -->
                    <div class="counter-title">Faculties</div>
                    <span class="count" data-count="3">3</span>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="counter-box">
                    <i class="bi-people-fill icon"></i> <!-- Icon for Regular Students -->
                    <div class="counter-title">Regular Students</div>
                    <span class="count plus-sign" data-count="2000">0</span>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="counter-box">
                    <i class="bi bi-person-rolodex icon"></i> <!-- Icon for Faculty Members -->
                    <div class="counter-title">Faculty Members</div>
                    <span class="count plus-sign" data-count="50">0</span>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script>
        $(document).ready(function () {
            const counters = $('.count');
            const speed = 1000; // The lower the slower

            counters.each(function () {
                const $this = $(this);
                const target = +$this.attr('data-count');
                const hasPlus = $this.hasClass('plus-sign'); // Check if counter requires plus sign

                const updateCount = () => {
                    const count = +$this.text();
                    const inc = target / speed;

                    if (count < target) {
                        $this.text(Math.ceil(count + inc));
                        setTimeout(updateCount, 1);
                    } else {
                        $this.text(target + (hasPlus ? '+' : '')); // Add '+' if needed
                    }
                };

                updateCount();
            });
        });
    </script>

