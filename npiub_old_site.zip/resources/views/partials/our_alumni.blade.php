
  <style>
    /* Custom styles */

    #alumni{
        background-color: #f6f8fb;
        /*background-image: url("https://www.transparenttextures.com/patterns/dimension.png");*/
        padding: 2rem 0 0;


    }

    .swiper-container {
      position: relative; /* Ensure relative positioning for absolute positioning of pagination */
      /* border: 1px solid red; */
      padding: 5rem 1rem;
      overflow: hidden;
    }
    .swiper-pagination {
      position: absolute; /* Position the pagination dots */
      bottom: 2rem !important; /* Adjust as per your requirement */
      
    }
    
    
    .swiper-slide {
      /* padding: 0 10px; Adjust padding to maintain spacing */
    }

    .swiper-button-prev:after,
 .swiper-button-next:after {
   --swiper-navigation-size: 1rem;
 }


 .swiper-button-prev,
.swiper-button-next {
  background: rgba(0, 123, 255, 0.5); /* Reduced opacity */
  width: 2.8rem;
  height: 2.8rem;
  color: #fff; /* Text color of the buttons */
  border-radius: 50%; /* Make the buttons circular */
  cursor: pointer; /* Change cursor to pointer on hover */
  z-index: 10; /* Ensure buttons are above other elements */
  transition: background-color 0.3s; /* Smooth transition */
}

.swiper-button-prev:hover,
.swiper-button-next:hover {
  background: rgba(0, 123, 255, 1); /* Full opacity on hover */
}

    
    .swiper-button-prev {
      left: 5px; /* Position the previous button */
    }
    .swiper-button-next {
      right: 5px; /* Position the next button */
    }
    .swiper-slide {
      padding: 0 10px; /* Adjust padding to maintain spacing */
    }


    .card {
    position: relative;
    padding-top: 4rem;
        background-color: #054D94;
      border: none;
      border-top: 4px solid #007BFF;
      border-radius: 0 0rem .5rem .5rem;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      overflow: visible;
    }
    .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 30px 60px rgba(0, 0, 0, 0.2);
    }
    .card img {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
      object-fit: cover;
      transition: transform 0.3s ease;
      border-radius: 50%;
      max-width: 120px;
      margin: 0 auto;
      position: absolute;
      top: -4rem; /* Align top edge of image with 50% of card height */
        left: 50%; /* Align left edge of image with 50% of card width */
        transform: translateX(-50%); /* Center image */
   
    }
    .card:hover img {
      transform: scale(1.03) translateX(-50%);; /* Zoom effect on hover */
      
    }
    
    .card_shadow {
    width: 75%;
    height: 75%;
    background-color: #fff;
    border-radius: 50%;
    position: absolute;
    top: 1rem;
    left: 0;
    right: 0;
    margin-inline: auto;
    filter: blur(45px);
    /* z-index: -1; */
}
    .card-body {
      padding: 1rem;
      border-radius: 1rem 1rem 0.5rem 0.5rem;
      background-color: #fff;
      z-index: 1;
    }
    .card-name{
        font-weight: bold;
        color: #054D94;
    }

    .card-text{
        font-size: 0.7em;
    }

    .text-position{
        font-size: 0.7rem;
        
    }

    .alumni-head{
        font-weight: 700;
        color: #054d94;
    }

    
    
  </style>


    <section id="alumni" class=" text-dark">
        <h2 class="text-center alumni-head">Our Alumni</h2> <!-- Section Heading -->
        <div class="container-fluid"> 
            <div class="swiper-container">
                <div class="swiper-wrapper text-center">
                @php
                    $departmentNames = [
                        'cse' => 'CSE',
                        'eee' => 'EEE',
                        'food-eng' => 'Food Engineering',
                        'bba' => 'BBA',
                        'mba' => 'MBA',
                        'english' => 'B.A in English'
                    ];
                @endphp
                @foreach($latestAlumni as $alumni)
                <div class="swiper-slide">
                <a href="{{ route('alumni.view', $alumni->slug) }}" class="alumni-card-link text-decoration-none">
                        <div class="card">
                            <div class="card_shadow"></div>
                            <img src="{{ asset('storage/' . $alumni->image) }}" class="card-img-top" alt="Alumni Image">
                            <div class="card-body">
                                <h5 class="card-name">{{ $alumni->name }}</h5>
                                <p class="card-text small m-0">Batch: {{ $alumni->batch }}th - Graduation Year: {{ $alumni->graduation_year }}</p>
                                <p class="card-text small mb-2">Dept. of {{ $departmentNames[$alumni->department] ?? ucfirst($alumni->department) }}, NPIUB</p>
                                <p class="card-text small text-position">Current Position: {{ $alumni->current_position }}</p>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
                </div>
                <!-- Add pagination -->
                <div class="swiper-pagination"></div>
                <!-- Add navigation buttons -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
                
            </div>

            <div class="text-center">
            <a href="{{ url('/alumni') }}"><button class="btn btn-primary alumni-btn mb-5">Alumni Archives</button></a> <!-- Search Archives Button -->
        </div>
        </div>
    </section>

<script>
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 4,
        spaceBetween: 30,
        autoplay: {
          delay: 1000,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        loop: true, // Enable loop
        breakpoints: {
            992: {
                slidesPerView: 4,
                
            },
            768: {
                slidesPerView: 2,
                
            },
            0: {
                slidesPerView: 1,
                
            },
        },
    });

    // Adjust card heights
    function adjustCardHeights() {
        var cards = document.querySelectorAll('.swiper-slide .card');
        var maxHeight = 0;
        cards.forEach(function(card) {
            maxHeight = Math.max(maxHeight, card.offsetHeight);
        });
        cards.forEach(function(card) {
            card.style.height = maxHeight + 'px';
        });
    }
    adjustCardHeights();
</script>

