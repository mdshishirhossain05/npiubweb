

<style>
    .admission-section {
        padding: 3rem 0 4rem 0;
        background: linear-gradient(135deg, #f3f6fb 0%, #ffffff 40%, #f2f7ff 100%);
    }

    .admission-card {
        background: #ffffff;
        border-radius: 16px;
        padding: 2.5rem 1.5rem;
        box-shadow: 0 18px 45px rgba(15, 23, 42, 0.12);
        border: 1px solid #e5e7eb;
    }

    .admission-heading {
        font-size: 1.9rem;
        font-weight: 700;
        color: #054D94;
        letter-spacing: 0.03em;
        text-transform: uppercase;
    }

    .admission-subtext {
        max-width: 680px;
        margin: 0.5rem auto 0;
        color: #6b7280;
        font-size: 0.98rem;
    }

    /* Program selector row */
    .program-selector-box {
        border-radius: 14px;
        border: 1px solid #d0d7e1;
        background: linear-gradient(135deg, #f9fbff 0%, #eef3ff 40%, #ffffff 100%);
        padding: 1.3rem 1.5rem;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .program-selector-icon {
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background: #054D94;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-weight: 700;
        font-size: 1.1rem;
        flex-shrink: 0;
    }

    .program-selector-text {
        flex: 1 1 auto;
    }

    .program-selector-text h3 {
        font-size: 1rem;
        font-weight: 600;
        margin: 0;
        color: #111827;
    }

    .program-selector-text p {
        font-size: 0.9rem;
        margin: 0.15rem 0 0;
        color: #6b7280;
    }

    .program-selector-control {
        min-width: 320px;
        flex-shrink: 0;
    }

    /* Dropdown */
    .select-wrapper {
        position: relative;
        display: inline-block;
        width: 100%;
    }

    .program-select {
        width: 100%;
        border-radius: 999px;
        border: 1px solid #cbd5f0;
        padding: 0.6rem 2.6rem 0.6rem 1rem;
        font-size: 0.95rem;
        color: #111827;
        background: #ffffff;
        box-shadow: 0 4px 10px rgba(15, 23, 42, 0.06);
        outline: none;
        transition: all 0.15s ease;
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        cursor: pointer;
    }

    .program-select:focus {
        border-color: #054D94;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
    }

    .program-select option[value=""] {
        color: #9ca3af;
    }

    .select-wrapper::after {
        content: "";
        position: absolute;
        top: 50%;
        right: 18px;
        width: 0;
        height: 0;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        border-top: 7px solid #054D94;
        transform: translateY(-50%);
        pointer-events: none;
    }

    /* Content area */
    .program-content-wrapper {
        border-radius: 14px;
        border: 1px solid #d0d7e1;
        background-color: #ffffff;
        padding: 1.75rem 1.6rem;
    }

    .dept-head {
        color: #054D94;
        font-weight: 600;
    }

    .program-header {
        border-bottom: 1px solid #e5e7eb;
        padding-bottom: 0.75rem;
        margin-bottom: 1.2rem;
    }

    .program-highlight {
        font-size: 0.9rem;
        color: #6b7280;
    }

    /* Intro pane */
    .intro-pane {
        text-align: center;
    }

    .intro-pane h3 {
        font-size: 1.2rem;
        font-weight: 600;
        color: #054D94;
        margin-bottom: 0.75rem;
    }

    .intro-pane p {
        color: #4b5563;
        font-size: 0.95rem;
        max-width: 620px;
        margin: 0 auto 0.5rem;
    }

    .intro-pill-list {
        list-style: none;
        padding-left: 0;
        margin-top: 1rem;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 0.5rem;
    }

    .intro-pill-list li {
        background: #eef2ff;
        color: #4f46e5;
        border-radius: 999px;
        padding: 0.3rem 0.9rem;
        font-size: 0.85rem;
    }

    .program-pane {
        display: none;
    }

    .program-pane.active-pane {
        display: block;
    }

    @media (min-width: 768px) {
        .admission-card {
            padding: 2.8rem 2.5rem;
        }
        .admission-heading {
            font-size: 2.1rem;
        }
        .program-content-wrapper {
            padding: 2rem 2rem 1.8rem 2rem;
        }
    }

    @media (max-width: 576px) {
        .admission-heading {
            font-size: 1.6rem;
        }
        .program-selector-box {
            padding: 1rem 1.1rem;
        }
        .program-selector-control {
            min-width: 100%;
        }
    }
</style>

<section class="admission-section">
    <div class="container">
        <div class="admission-card">

            <div class="text-center mb-4">
                <h2 class="admission-heading">Graduate Program Requirements</h2>
                <p class="admission-subtext">
                    Explore admission requirements for graduate programs at NPI University of Bangladesh (NPIUB).
                    Use the selector below to choose a graduate program and view its detailed eligibility and requirements.
                </p>
            </div>

            {{-- Program selector (dropdown-style) --}}
            <div class="program-selector-box mb-3">
                <div class="program-selector-icon">
                    PG
                </div>

                <div class="program-selector-text">
                    <h3>Select a graduate program</h3>
                    <p>
                        Choose a program to view admission criteria, academic background requirements, and minimum grade thresholds.
                    </p>
                </div>

                <div class="program-selector-control">
                    <div class="select-wrapper">
                        <select id="gradProgramSelect" class="program-select">
                            <option value="">-- Select a graduate program --</option>
                            @foreach($programs as $key => $program)
                                <option value="{{ $key }}">{{ $program['title'] }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>

            {{-- Content box --}}
            <div class="program-content-wrapper">

                {{-- Intro shown initially --}}
                <div id="grad-program-intro" class="intro-pane">
                    <h3>Select a program to view detailed graduate admission requirements</h3>
                    <p>
                        Each graduate program at NPIUB has specific eligibility criteria, including prior academic background,
                        minimum CGPA, and other conditions. Once you select a program from the dropdown above, you will see
                        detailed information relevant to that program.
                    </p>
                    <p>
                        This helps you understand whether you meet the entry requirements and plan your postgraduate studies accordingly.
                    </p>
                    <ul class="intro-pill-list">
                        <li>Relevant Bachelor’s Degree</li>
                        <li>Minimum CGPA / Class Requirement</li>
                        <li>Subject / Major Requirements</li>
                        <li>Credit Structure & Duration</li>
                    </ul>
                </div>

                {{-- Program-specific panes --}}
                @foreach($programs as $key => $program)
                    <div
                        class="program-pane"
                        data-program="{{ $key }}"
                    >
                        <div class="program-header">
                            <h3 class="dept-head mb-1">{{ $program['title'] }}</h3>
                            @if(!empty($program['highlight']))
                                <p class="program-highlight mb-0">
                                    {{ $program['highlight'] }}
                                </p>
                            @endif
                        </div>

                        {{-- Department-specific graduate admission partial --}}
                        @include($program['partial'])
                    </div>
                @endforeach

            </div>

        </div>
    </div>
</section>

<script>
    // Graduate program selector logic
    (function () {
        const select = document.getElementById('gradProgramSelect');
        const introPane = document.getElementById('grad-program-intro');
        const panes = document.querySelectorAll('.program-pane');

        function showIntro() {
            if (introPane) {
                introPane.style.display = 'block';
            }
            panes.forEach(p => p.classList.remove('active-pane'));
        }

        function showProgram(key) {
            if (introPane) {
                introPane.style.display = 'none';
            }
            panes.forEach(p => {
                if (p.getAttribute('data-program') === key) {
                    p.classList.add('active-pane');
                } else {
                    p.classList.remove('active-pane');
                }
            });
        }

        if (select) {
            select.addEventListener('change', function () {
                const value = this.value;
                if (!value) {
                    showIntro();
                } else {
                    showProgram(value);
                }
            });
        }
    })();

    // Keep your scholarships height adjustment (if present in partials)
    $(document).ready(function() {
        var $scholarships = $(".scholarships");
        if ($scholarships.length) {
            var maxTableHeight = Math.max.apply(null, $scholarships.map(function () {
                return $(this).height();
            }).get());
            $scholarships.height(maxTableHeight);
        }
    });
</script>
