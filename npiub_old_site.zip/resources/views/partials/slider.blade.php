
  <style>
    /* Custom styles for slider */
    .carousel-item {
        width: 100%;
        object-fit: cover;
    }

    #homeSlider {
        padding: 0 0 4rem 0;
    }

    .carousel-indicators {
        position: absolute;
        bottom: -4.5rem;
        left: 0;
        right: 0;
        z-index: 1;
    }

    .carousel-indicators [data-bs-target] {
        background-color: #ddd;
    }

    .carousel-indicators .active {
        background-color: #007BFF;
    }

    .carousel-item img,
    .carousel-item iframe {
        width: 100%;
        height: 100%; /* Make images and videos fill the slide */
        object-fit: cover; /* Ensure images and videos cover the entire slide */
    }

    /* Custom styles for arrow buttons */
    .carousel-control-prev,
    .carousel-control-next {
        background: #007BFF;
        width: 2.8rem;
        height: 2.8rem;
        border-radius: 50%;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
    }

    .carousel-control-prev-icon,
    .carousel-control-next-icon {
        width: 1rem;
        height: 1rem;
    }

    .carousel-control-prev {
        left: 1rem; /* Adjust position to avoid overlapping */
    }

    .carousel-control-next {
        right: 1rem; /* Adjust position to avoid overlapping */
    }

    /* Custom styles for admission button */
    .admission-button {
        position: absolute;
        bottom: -20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 1;
        color: #fff !important;
        text-decoration:none !important;
    }
    
    .admission-button a{
        color: #fff !important;
        text-decoration:none !important;
    }
  </style>

    
<section id="homeSlider" class="bg-light">
    <div class="container-fluid p-0">
        <div id="carouselExampleIndicators" class="carousel slide">
            <div class="carousel-indicators">
                @foreach ($latestGallery as $index => $gallery)
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="{{ $index }}" class="{{ $index === 0 ? 'active' : '' }}" aria-current="true" aria-label="Slide {{ $index + 1 }}"></button>
                @endforeach
            </div>
            
            <button class="btn btn-primary admission-button "><a href="{{ url('apply-admission') }}" class="">Apply Admission</a></button>
            <!--<a href="{{ url('apply-admission') }}" class="btn btn-primary mb-4 admission-button">Apply Admission</a>-->
            

            <div class="carousel-inner">
                @foreach ($latestGallery as $index => $gallery)
                    <div class="carousel-item {{ $index === 0 ? 'active' : '' }}">
                        <img src="{{ asset('storage/' . $gallery->image) }}" class="d-block w-100" alt="Gallery Image {{ $index + 1 }}">
                    </div>
                @endforeach
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
</section>



