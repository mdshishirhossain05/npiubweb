
    <style>
        body {
            /* background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            color: #343a40;
            
            line-height: 1.6; */
        }

        .dept-head{
            color: #054D94;
        }
        .nav-tabs{
            border-bottom: none !important;
        }
        .nav-tabs .nav-link.active {
            background-color: #054D94;
            color: #ffffff;
            border-color: #054D94;
        }
        .nav-tabs .nav-link {
            color: #054D94;
            border: 1px solid transparent;
            border-radius: 0;
        }
        .tab-content {
            background-color: #ffffff;
            padding: 20px;
            /*border: 1px solid #dee2e6;*/
            border-top: none;
            border-radius: 0;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .tab-pane {
            display: none;
        }
        .tab-pane.active {
            display: block;
        }
        .tab-content p {
            margin-bottom: 1rem;
        }

    </style>

    <div class="container mt-5 mb-5">
        <div class="text-center mb-5">
            <h2 class="admission-heading">Undergraduate Program Requirements</h2>
            <!--<p class="lead text-muted">Discover your path to success with our tailored admission process.</p>-->
         </div>
          
        <ul class="nav nav-tabs" id="admissionTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="cse-tab" data-bs-toggle="tab" data-bs-target="#cse" type="button" role="tab" aria-controls="cse" aria-selected="true">CSE</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="eee-tab" data-bs-toggle="tab" data-bs-target="#eee" type="button" role="tab" aria-controls="eee" aria-selected="false">EEE</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="foodEng-tab" data-bs-toggle="tab" data-bs-target="#foodEng" type="button" role="tab" aria-controls="foodEng" aria-selected="false">Food Engineering</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="bba-tab" data-bs-toggle="tab" data-bs-target="#bba" type="button" role="tab" aria-controls="bba" aria-selected="false">BBA</button>
            </li>
            <!--<li class="nav-item" role="presentation">-->
            <!--    <button class="nav-link" id="mba-tab" data-bs-toggle="tab" data-bs-target="#mba" type="button" role="tab" aria-controls="mba" aria-selected="false">MBA</button>-->
            <!--</li>-->
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="english-tab" data-bs-toggle="tab" data-bs-target="#english" type="button" role="tab" aria-controls="english" aria-selected="false">English</button>
            </li>
        </ul>
        
        <div class="tab-content" id="admissionTabsContent">
            
            <!-- CSE Tab -->
            <div class="tab-pane active" id="cse" role="tabpanel" aria-labelledby="cse-tab">
                <div class="text-left mb-5">
                  <h3 class="dept-head">Computer Science & Engineering(CSE)</h3>
                </div>
                @include('departments.cse.admission')
            </div>
            
            <!-- EEE Tab -->
            <div class="tab-pane active" id="eee" role="tabpanel" aria-labelledby="eee-tab">
                <div class="text-left mb-5">
                  <h3 class="dept-head">Electrical and Electronic Engineering (EEE)</h3>
                </div>
                @include('departments.eee.admission')
            </div>
            
            <!-- foodEng Tab -->
            <div class="tab-pane active" id="foodEng" role="tabpanel" aria-labelledby="foodEng-tab">
                <div class="text-left mb-5">
                  <h3 class="dept-head">Food Engineering</h3>
                </div>
                @include('departments.food_eng.admission')
            </div>
            
            <!-- BBA Tab -->
            <div class="tab-pane active" id="bba" role="tabpanel" aria-labelledby="bba-tab">
                <div class="text-left mb-5">
                  <h3 class="dept-head">Bachelor of Business Administration (BBA)</h3>
                </div>
                @include('departments.bba.admission')
            </div>
            
            <!-- English Tab -->
            <div class="tab-pane active" id="english" role="tabpanel" aria-labelledby="english-tab">
                <div class="text-left mb-5">
                  <h3 class="dept-head">BA in English</h3>
                </div>
                @include('departments.english.admission')
            </div>
            
        </div>
        
    </div>

   
    <script>
        $(document).ready(function() {
          // Calculate and set the maximum height of all tables
          var maxTableHeight = Math.max.apply(null, $(".scholarships").map(function () {
            return $(this).height();
          }).get());
        
          $(".scholarships").height(maxTableHeight); // Set all tables to the maximum height
        });
    </script>
    
   

