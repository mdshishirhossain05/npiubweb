
  <style>
    .faq-item {
      margin-bottom: 1.5rem;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .faq-item .card{
        border: none;
        /* padding: 1rem; */
    }
    .faq-item .card-header {
      cursor: pointer;
      position: relative;
      padding-right: 40px; /* Space for the icons */
      border: none;
      
      
    }
    .faq-item .card-header .btn-link {
      color: #054D94;
      /* font-size: 1.5rem; */
      font-weight: 600;
      text-decoration: none;
      display: block;
      text-align: left !important;
    }
    .faq-item .card-header .btn-link:hover {
      text-decoration: none;
    }
    .faq-item .card-header .icon {
      position: absolute;
      top: 50%;
      right: 1.2rem;
      transform: translateY(-50%);
      font-size: 1.2em;
      color: #777;
    }

    .faq-heading{
      font-weight: 700;
      color: #054D94;
    }

    #accordionFAQ .collapse:not(.show) {
      display: none;
    }

    #showMoreBtn {
      background-color: #054D94;
      color: #fff;
      border: none;
      padding: 0.75rem 2rem;
      border-radius: .5rem;
      font-weight: 600;
      transition: background-color 0.3s ease;
    }

    #showMoreBtn:hover {
      background-color: #033564;
    }
  </style>


<div class="container pt-5 pb-5">
  <h2 class="text-center mb-4 faq-heading">Frequently Asked Questions (FAQs)</h2> 
  <div id="accordion" class="row">

    <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingOne">
              <h5 class="mb-0">
                
                <button class="btn btn-link" >
                  What are the admission fees?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
              <div class="card-body">
                The admission fee is BDT. 8000, regardless of the course.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingTwo">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  What are the total tuition/course fees?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
              <div class="card-body">
                The course fee varies depending on the course. <br><br>
                Here’s a breakdown: <br>
                B.Sc in CSE (4 Year) – BDT. 1,70,000/- <br>
                B.Sc in EEE (4 Year) – BDT. 1,70,000/- <br>
                B.Sc in Food Engineering (4 Year) – BDT. 1,70,000/- <br>
                BBA (Business Administration) (4 Year) – BDT. 1,25,000/- <br>
                MBA (Business Administration) (2 Year) – BDT. 60,000/- <br>
                B.A in English (4 Year) – BDT. 1,20,000/-
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingThree">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Are there any scholarships or financial aids?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
              <div class="card-body">
                Yes! Depending on your HSC or Diploma Engineering results, or by belonging to a special category, you may be granted a scholarships or grants.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingFour">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  How many semesters are there in total?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
              <div class="card-body">
                Regular (HSC) graduates will need to complete 8 semesters in total.<br>Diploma graduates will need to complete 7 semesters. Each semester is 6 months. There are two semesters per academic year.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingFive">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  What is the eligibility for admission?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
              <div class="card-body">
                Please Contact with Admission Office for clear guidlines.<br><br>
                <strong> Md.Juwel Rana </strong><br>
                Admission Officer, NPIUB<br>
                01703-444111(WhatsApp)<br>
                Email: admissionnpiub89@gmail.com<br>
                <br>
                <strong> Zahid Hasan </strong><br>
                Asst. Admission Officer,NPIUB<br>
                01765-274685, 01629- 996488<br>
                Email: jahidnn6@gmail.com
              </div>
            </div>
          </div>
        </div>
      </div>
  
  
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingSix">
              <h5 class="mb-0">
                <button class="btn btn-link">
                  Are there any additional fees/hidden charges?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
              <div class="card-body">
                No! there is no additional fees/hidden charges.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingSeven">
              <h5 class="mb-0">
                <button class="btn btn-link">
                  What documents do I need for admission?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordion">
              <div class="card-body">
                You’ll need the following documents:<br><br>
                (a) A photocopy of your National ID card (NID) or Birth Certificate.<br>
                (b) Photocopies of your HSC/Diploma & SSC/equivalent examination marksheet.<br>
                (c) Four copies of passport size photographs.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingEight">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Are there online classes?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordion">
              <div class="card-body">
                Currently, we do not host online classes.<br>However, class materials will usually be supplied online for those who can’t attend physically.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingNine">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Is attendance mandatory?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordion">
              <div class="card-body">
                Yes, there are marks on attendance.<br>In addition, it is vital that you attend classes regularly to properly understand the course.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingTen">
              <h5 class="mb-0">
                <button class="btn btn-link">
                  What facilities does the university provide?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordion">
              <div class="card-body">
                In addition to our well-maintained classrooms, we offer a library, a laboratory for physics and chemistry-related work, a computer laboratory, food laboratory, electrical laboratory and much more! The university also provides transportation (bus services) for remote students.
              </div>
            </div>
          </div>
        </div>
      </div>
  
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingEleven">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Are there any co-curricular activities?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-parent="#accordion">
              <div class="card-body">
                Yes, in addition to scheduled classes, we offer activities such as excursion, educational tourism and the ability work and contribute towards the development of your department; which will no doubt provide you with valuable real-world experience!
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingTwelve">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Where is the campus located?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-parent="#accordion">
              <div class="card-body">
                Our current campus is located at 495, East Basta, Singair, Manikganj, Dhaka.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingThirteen">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  What are the operating hours of the university throughout the week?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseThirteen" class="collapse" aria-labelledby="headingThirteen" data-parent="#accordion">
              <div class="card-body">
                The university is open from Wednesday to Sunday; from 8 AM to 4 PM.<br>We are closed on Monday and Tuesday.
              </div>
            </div>
          </div>
        </div>
      </div>
  
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingFourteen">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Is the university recognized by the University Grants Commission of Bangladesh?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseFourteen" class="collapse" aria-labelledby="headingFourteen" data-parent="#accordion">
              <div class="card-body">
                Yes, it is indeed recognized by University Grants Commission of Bangladesh.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingFifteen">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  How many students have studied here?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseFifteen" class="collapse" aria-labelledby="headingFifteen" data-parent="#accordion">
              <div class="card-body">
                So far, we have educated over 5000 students.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingSixteen">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  Do I need to understand English?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseSixteen" class="collapse" aria-labelledby="headingSixteen" data-parent="#accordion">
              <div class="card-body">
                While the instructors will hold classes in Bengali for the most part, the examinations will be held in English and you’d be required to submit your papers in said language.<br>Therefore, it is recommended that you possess a good grasp of the English knowledge, regardless of which course you choose to enroll into.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-12 mx-auto">
        <div class="faq-item">
          <div class="card">
            <div class="card-header" id="headingSeventeen">
              <h5 class="mb-0">
                <button class="btn btn-link" >
                  What are the job prospects?
                </button>
                <span class="icon">
                  <i class="fa-regular fa-plus"></i>
                </span>
              </h5>
            </div>
            <div id="collapseSeventeen" class="collapse" aria-labelledby="headingSeventeen" data-parent="#accordion">
              <div class="card-body">
                About 70 to 80 percent students get a job following graduation.
              </div>
            </div>
          </div>
        </div>
      </div>
      
    <!-- FAQ items here -->
  </div>
  <div class="text-center">
                <button id="see-more" class="btn btn-primary mt-3">See More</button>
                <button id="see-less" class="btn btn-secondary mt-3" style="display: none;">See Less</button>
            </div>
</div>


<script>
    $(document).ready(function() {
        // Initially hide all FAQ items after the 5th one
        $('.faq-item').slice(5).hide(); 

        // Show the next set of FAQs when 'See More' is clicked
        $('#see-more').click(function() {
            $('.faq-item').slice(5).slideDown();  // Show all hidden FAQs
            $('#see-more').hide();                // Hide 'See More' button
            $('#see-less').show();                // Show 'See Less' button
        });

        // Hide the additional FAQs when 'See Less' is clicked
        $('#see-less').click(function() {
            $('.faq-item').slice(5).slideUp();    // Hide FAQs after 5th item
            $('#see-more').show();                // Show 'See More' button
            $('#see-less').hide();                // Hide 'See Less' button
        });

        // Initially hide the 'See Less' button
        $('#see-less').hide();
    });
</script>



<script>
  $(document).ready(function(){
    $('.faq-item').click(function(){
      var collapse = $(this).find('.collapse');
      // Close all open collapse items except the clicked one and footer collapse items
      $('.collapse').not(collapse).not('footer .collapse').collapse('hide');
      collapse.collapse('toggle'); // Toggle the clicked item's collapse
      $('.icon i').not($(this).find('.icon i')).removeClass('fa-minus').addClass('fa-plus'); // Reset all icons to plus except the clicked one
      $(this).find('.icon i').toggleClass('fa-plus fa-minus'); // Toggle icon for the clicked item
    });
  });
</script>
