<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'NPIUB, North Pacific International University of Bangladesh')</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('images/logo/logo_npiub.ico') }}">
    <link rel="icon" type="image/x-icon" href="{{ asset('images/logo/logo_npiub.ico') }}">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.2/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.css">
     <!-- Fancybox CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-table@1.22.6/dist/bootstrap-table.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=6684098fa88bfa0019b9372b&product=inline-share-buttons&source=platform" async="async"></script>
    

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-TLWBMKM6');</script>
    <!-- End Google Tag Manager -->

<style>

  #header {
    position: relative;
    display: block;
    z-index: 55;
  }

  #header #header-top {
    position: relative;
    display: block;
    padding: 0;
    background: #054D94;
    color: #FFF;
  }

  #header #nav-bar .logo {
    position: absolute;
    bottom: 0;
    left: 4% !important;
    transform: translateY(0%);
    padding: 1rem;
    background: #ffffff;
    z-index: 9999;
    max-width: 115px;
    height: auto;
    
  }

  a {
    color: inherit;
    text-decoration: none;
    transition: all .2s ease-in;
  }

  #header #header-top .top-nav {
    position: relative;
    display: block;
    margin-left: auto; 
    margin-right: auto; 
  }


  .top-nav {
    background-color: #054D94;
    color: #fff !important;
    padding: 0.5rem;
    text-decoration: none !important;
  }

  .nav-bar {
    background-color: #fff;

  } 

  .top-nav h1 {
    margin: 0;
  }

  .top-nav a {
    text-decoration:none;
    color: #fff;
  }

  .main-nav {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }


  #header #nav-bar {
    
    display: block;
    padding: 0;
    background: #fff;
    z-index: 4;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); 
  }

  
  #header.fixed {
    position: fixed;
    top: 0;
    width: 100%;
    background: #ffffff;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    height: auto;
    
  }

  #header.fixed #header-top {
    display: none; 
  }


  #header.fixed #nav-bar .logo {

    padding: 0.5rem;
    max-width: 100%;
    transition: max-width 0.5s ease; 
  }


  /* Add styles for hiding header and nav items on smaller screens */
  @media (max-width: 992px) {
    #header #header-top,
    #header #nav-bar {
      display: none;
    }

    #header.fixed #header-top,
    #header.fixed #nav-bar {
      display: block;
    }
  }


  .dropdown-trigger.active {
    color: #054D94;
  }

  /* Your existing CSS styles */

  img {
    max-width: 100%;
  }


  .dropdown {
    display: flex;
    justify-content: space-between;
    position: relative;
    z-index: 1; 
  }

  .dropdown-trigger {
    padding: 0.75rem;
    color: #054D94;
    text-decoration: none;
  }


  .dropdown-content {
    position: absolute;
    top: 100%;
    display: none;
    text-align: left;
    background-color: #fff;
    padding: 1rem;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    width: auto; 
    text-wrap: nowrap;
  }

  /* Add larger square before the dropdown content */
  .dropdown-content::before {
    content: "\25A0"; 
    font-size: 2rem; 
    color: #054D94; 
    position: absolute;
    top: -15px;
    left: 20px;
    transform: translateY(-50%); 
    transform: rotate(45deg);
    z-index: -1;
  }

  .dropdown-content a {
    display: block;
    padding: 0.5rem 1rem;
    color: #054D94;
    text-decoration: none;
    transition: background-color 0.3s ease; effect */
  }

  .dropdown-content a:hover {
    background-color: #eee;
  }

  /* Show dropdown content on hover */
  .dropdown:hover .dropdown-content {
    display: block;
  }

</style>
  </head>

  <body>
      
     <div id="header">
        <div id="header-top" class="scrolled">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="top-nav text-center">
                            <a href="{{ $pageUrl ?? url('/') }}" title="">
                                <h1 class="fs-3">{{ $pageTitle ?? 'NPI University of Bangladesh' }}</h1>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
        <div id="nav-bar">
            <div class="container">
                <div class="row">
                    <div class="col-12 align-items-center justify-content-between">
                        <div class="logo" id="logo">
                            <a href="{{ url('/') }}" title="Home">
                                <img src="{{ asset('images/logo/logo_npiub.png') }}" alt="NPIUB Logo">
                            </a>
                        </div>
                        
    
                        <div class="d-flex justify-content-between align-items-center">
                            
                            <div></div>
                            <!--<div></div>-->
                            
                            <div class="main-nav">
                            
                            @php
                                $dropdowns = [
                                    'About' => [
                                        ['title' => 'Vision & Mission', 'url' => '/vision-mission'],
                                        ['title' => 'Academic Council', 'url' => route('academic_council')],
                                        ['title' => 'Syndicate', 'url' => route('syndicate')],
                                        ['title' => 'Board of Trustees', 'url' => '/board-of-trustees'],
                                        ['title' => 'Location', 'url' => route('contact.location')],
                                        ['title' => 'Contact Us', 'url' => route('contact.index')],
                                    ],
                                    'Academic' => [
                                        ['title' => 'Computer Science and Engineering (CSE)', 'url' => route('department.cse')],
                                        ['title' => 'Electrical and Electronics Engineering (EEE)', 'url' => route('department.eee')],
                                        ['title' => 'Food Engineering', 'url' => route('department.food_eng')],
                                        ['title' => 'Bachelor of Business Administration (BBA)', 'url' => route('department.bba')],
                                        ['title' => 'Master of Business Administration (MBA)', 'url' => route('department.mba')],
                                        ['title' => 'B.A in English', 'url' => route('department.english')],
                                        ['title' => 'News and Events', 'url' => route('news.archives')],
                                        ['title' => 'Galleries', 'url' => route('galleries.galleries')],
                                        
                                        ['title' => 'Alumni', 'url' => route('alumni.alumni')],
                                        
                                        ['title' => 'Academic Calendar', 'url' => '#'],
                                    ],
                                    'Admissions' => [
                                        ['title' => 'Undergraduate Program Requirements', 'url' => url('/undergraduate-program')],
                                        ['title' => 'Graduate Program Requirements', 'url' => url('/graduate-program')],
                                        ['title' => 'Brochure / Flyer', 'url' => '#'],
                                        ['title' => 'Financial Aid & Scholarships', 'url' => '#'],
                                        ['title' => 'Credits Transfer Guidelines', 'url' => '#'],
                                        ['title' => 'Tuition & Other Fees', 'url' => '#'],
                                        ['title' => 'Admission FAQs', 'url' => url('/faqs')],
                                        ['title' => 'Admission Contact', 'url' => '#'],
                                    ],
                                    'Offices' => [
                                        ['title' => 'Office of the Vice-Chancellor', 'url' => route('offices.vice_chancellor')],
                                        ['title' => 'Office of the Pro-VC', 'url' => route('offices.pro_vc')],
                                        ['title' => 'Office of the Treasurer', 'url' => route('offices.treasurer')],
                                        ['title' => 'Office of the Registrar', 'url' => route('offices.registrar')],
                                        ['title' => 'Office of the Controller of Examinations', 'url' => route('offices.controller_of_examinations')],
                                        ['title' => 'Office of the Director of Accounts', 'url' => route('offices.director_of_accounts')],
                                        ['title' => 'Library', 'url' => route('offices.library')],
                                        ['title' => 'Admissions', 'url' => route('offices.admissions')],
                                        ['title' => 'IQAC', 'url' => route('offices.iqac')],
                                    ],
                                    'Research' => [
                                        ['title' => 'Explore Research', 'url' => 'research'],
                                    ],
                                    'Quick Links' => [
                                        ['title' => 'Forms and Downloads', 'url' => '#'],
                                        ['title' => 'Notices', 'url' => route('notices.board')],
                                        ['title' => 'Student Portal', 'url' => 'https://npiub.pipilikasoft.com/'],
                                        ['title' => 'Career at NPIUB', 'url' => '#'],
                                        ['title' => 'Location', 'url' => route('contact.location')],
                                        ['title' => 'Contact Us', 'url' => route('contact.index')],
                                    ],
                                ];
                            @endphp
    
                            @foreach ($dropdowns as $title => $links)
                                <div class="dropdown">
                                    <a href="#{{ strtolower(str_replace(' ', '-', $title)) }}" class="dropdown-trigger fs-5">{{ $title }}</a>
                                    <div class="dropdown-content">
                                        @foreach ($links as $link)
                                            <a href="{{ $link['url'] }}">{{ $link['title'] }}</a>
                                        @endforeach
                                    </div>
                                </div>
                            @endforeach
                            
                        
                        </div>
                        
                        <div class="d-flex gap-3">
                            <div class="">
                                <a href="https://npiub.pipilikasoft.com/" class="btn btn-secondary btn-sm border" role="button" aria-pressed="true">i-EMS</a>
                                
                            </div>
                            
                            <!--<div class="">-->
                            <!--    <a href="https://convocation.npiub.edu.bd/" class="btn btn-primary btn-sm border" role="button" aria-pressed="true">Convocation</a>-->
                                
                            <!--</div>-->
                        </div>
                        
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <script>
        $(document).ready(function () {
            var $header = $("#header");
            var $logo = $("#logo");
    
            $(window).on("scroll", function () {
                var screenWidth = $(window).width();
    
                if (screenWidth > 992) {
                    if ($(this).scrollTop() > 0) {
                        $header.addClass("fixed");
                        $logo.css({
                            "max-width": "56px",
                            "left": "4%",
                            "bottom": "0",
                            "transform": "translateY(0%)"
                        });
                    } else {
                        $header.removeClass("fixed");
                        $logo.css({
                            "max-width": "115px",
                            "height": "auto",
                            "bottom": "0",
                            "left": "4%",
                            "transform": "translateY(0%)"
                        });
                    }
                } else {
                    // Hide header and logo on smaller screens
                    $header.hide();
                    $logo.hide();
                }
            });
        });
    </script>
    
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/11.0.5/swiper-bundle.min.js"></script>
    <!-- Fancybox JS -->
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-table@1.22.6/dist/bootstrap-table.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    