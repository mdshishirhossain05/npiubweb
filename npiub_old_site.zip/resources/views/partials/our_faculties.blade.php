<section class="home-faculties py-5">
    <div class="container py-5">

        {{-- Section Heading --}}
        <div class="text-center mb-5">
            <h2 class="faculties-title mb-2">Our Academic Faculties</h2>
            <p class="faculties-subtitle mb-3">
                The core of our academic excellence and diverse learning opportunities.
            </p>
            <div class="faculties-underline mx-auto"></div>
        </div>

        {{-- Filter Row --}}
        <div class="row justify-content-center">
            <div class="col-12 col-xl-10">
                <div class="row g-3 align-items-center justify-content-center faculties-filter-row">

                    {{-- Label --}}
                    <div class="col-12 col-md-auto text-md-end mb-1 mb-md-0">
                        <span class="faculties-filter-label">Filter by:</span>
                    </div>

                    {{-- Select Faculty --}}
                    <div class="col-12 col-md-6 col-lg-4">
                        <select id="facultySelect" class="form-select faculties-select">
                            <option value="" selected disabled>Select Faculty</option>
                            <option value="science_engineering">Faculty of Science &amp; Engineering</option>
                            <option value="business">Faculty of Business Studies</option>
                            <option value="arts_social">Faculty of Arts &amp; Social Sciences</option>
                        </select>
                        <div id="facultyError" class="faculties-error d-none">
                            Please select Faculty first
                        </div>
                    </div>

                    {{-- Select Department --}}
                    <div class="col-12 col-md-6 col-lg-4">
                        <select id="departmentSelect" class="form-select faculties-select" disabled>
                            <option value="" selected disabled>Select Department</option>
                        </select>
                        <div id="departmentError" class="faculties-error d-none">
                            Please select Department first
                        </div>
                    </div>

                    {{-- Go Button --}}
                    <div class="col-12 col-md-auto">
                        <button
                            type="button"
                            id="facultiesGoBtn"
                            class="btn faculties-go-btn w-100 w-md-auto"
                        >
                            Go
                        </button>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>

{{-- ======================= STYLES ======================= --}}
<style>
    .home-faculties {
        background-color: #ffffff;
    }

    .faculties-title {
        font-weight: 700;
        color: #2b3f86;
    }

    .faculties-subtitle {
        max-width: 700px;
        margin-left: auto;
        margin-right: auto;
        color: #6c757d;
        font-size: 0.98rem;
    }

    .faculties-underline {
        width: 80px;
        height: 3px;
        border-radius: 999px;
        background-color: #2b3f86;
    }

    .faculties-filter-row {
        margin-top: 10px;
    }

    .faculties-filter-label {
        font-weight: 600;
        color: #374151;
        font-size: 0.98rem;
        white-space: nowrap;
    }

    .faculties-select {
        border-radius: 999px;
        padding-left: 18px;
        padding-right: 40px;
        height: 46px;
        font-size: 0.95rem;
        border-color: #d1d5db;
        color: #374151;
        transition:
            border-color 0.15s ease,
            box-shadow 0.15s ease,
            background-color 0.15s ease;
        background-color: #ffffff;
        max-width: 100%;
    }

    .faculties-select:disabled {
        background-color: #f3f4f6;
        color: #9ca3af;
        cursor: not-allowed;
    }

    .faculties-select:focus {
        border-color: #2b3f86;
        box-shadow: 0 0 0 0.15rem rgba(43, 63, 134, 0.15);
    }

    /* Error state */
    .faculties-select.is-invalid {
        border-color: #dc2626;
        box-shadow: 0 0 0 0.12rem rgba(220, 38, 38, 0.18);
    }

    .faculties-error {
        font-size: 0.8rem;
        color: #dc2626;
        margin-top: 4px;
    }

    .d-none {
        display: none !important;
    }

    .faculties-go-btn {
        border-radius: 999px;
        padding: 10px 32px;
        font-weight: 600;
        background-color: #253b9a;
        color: #ffffff;
        border: none;
        transition:
            background-color 0.15s ease,
            transform 0.1s ease,
            box-shadow 0.1s ease;
    }

    .faculties-go-btn:hover {
        background-color: #1f2f78;
        color: #ffffff;
        box-shadow: 0 8px 18px rgba(31, 47, 120, 0.25);
    }

    .faculties-go-btn:active {
        transform: scale(0.97);
        box-shadow: 0 4px 10px rgba(31, 47, 120, 0.2);
    }
</style>

{{-- ======================= SCRIPT ======================= --}}
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const facultySelect     = document.getElementById('facultySelect');
        const departmentSelect  = document.getElementById('departmentSelect');
        const goBtn             = document.getElementById('facultiesGoBtn');
        const facultyErrorEl    = document.getElementById('facultyError');
        const departmentErrorEl = document.getElementById('departmentError');

        // Faculty -> departments (simple object, O(1) lookup)
        const facultyDepartments = {
            science_engineering: [
                {
                    value: 'cse',
                    text: 'Department of Computer Science & Engineering',
                    url: "{{ url('/departments/cse') }}"
                },
                {
                    value: 'eee',
                    text: 'Department of Electrical & Electronic Engineering',
                    url: "{{ url('/departments/eee') }}"
                },
                {
                    value: 'fe',
                    text: 'Department of Food Engineering',
                    url: "{{ url('/departments/food-engineering') }}"
                },
            ],
            business: [
                {
                    value: 'bba',
                    text: 'Bachelor of Business Administration (BBA)',
                    url: "{{ url('/departments/bba') }}"
                },
                {
                    value: 'mba',
                    text: 'Master of Business Administration (MBA)',
                    url: "{{ url('/departments/mba') }}"
                },
            ],
            arts_social: [
                {
                    value: 'english',
                    text: 'Department of English',
                    url: "{{ url('/departments/english') }}"
                },
            ],
        };

        const setDepartmentDisabled = (disabled) => {
            departmentSelect.disabled = disabled;
        };

        const resetErrors = () => {
            facultySelect.classList.remove('is-invalid');
            departmentSelect.classList.remove('is-invalid');
            facultyErrorEl.classList.add('d-none');
            departmentErrorEl.classList.add('d-none');
        };

        const resetDepartmentSelect = () => {
            departmentSelect.innerHTML = '';
            const placeholder = document.createElement('option');
            placeholder.value = '';
            placeholder.textContent = 'Select Department';
            placeholder.disabled = true;
            placeholder.selected = true;
            departmentSelect.appendChild(placeholder);
        };

        const populateDepartments = (facultyKey) => {
            resetDepartmentSelect();

            const departments = facultyDepartments[facultyKey] || [];

            if (!departments.length) {
                setDepartmentDisabled(true);
                return;
            }

            const fragment = document.createDocumentFragment();

            departments.forEach(({ value, text, url }) => {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = text;
                opt.dataset.url = url;
                fragment.appendChild(opt);
            });

            departmentSelect.appendChild(fragment);
            setDepartmentDisabled(false);
        };

        // Initial state
        setDepartmentDisabled(true);

        // When faculty changes
        facultySelect.addEventListener('change', (event) => {
            const facultyKey = event.target.value;
            resetErrors();
            populateDepartments(facultyKey);
        });

        // When department changes
        departmentSelect.addEventListener('change', () => {
            resetErrors();
        });

        // Go click -> validate then redirect
        goBtn.addEventListener('click', () => {
            resetErrors();

            const facultyValue    = facultySelect.value;
            const departmentValue = departmentSelect.value;

            // 1) Validate faculty
            if (!facultyValue) {
                facultySelect.classList.add('is-invalid');
                facultyErrorEl.classList.remove('d-none');
                return;
            }

            // 2) Validate department
            if (!departmentValue) {
                departmentSelect.classList.add('is-invalid');
                departmentErrorEl.classList.remove('d-none');
                return;
            }

            // 3) Redirect
            const selectedOption = departmentSelect.selectedOptions[0];
            const url = selectedOption?.dataset.url;

            if (url) {
                window.location.href = url;
            }
        });
    });
</script>
