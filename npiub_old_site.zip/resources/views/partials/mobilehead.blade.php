

    <style>
      
       .mobile-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #ffffff;
            padding: 1rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

      img.sidebar-toggle {
        max-width: 60px;
      }
      
       .sidebar-title {
            color: #054D94;
            font-weight: 600;
            font-size: 1.5rem;
        }
        
         .sidebar {
            background-color: #054D94;
            color: white;
            overflow: hidden;
            transition: max-height 0.3s ease-in-out;
            max-height: 0;
            z-index: 3;
        }

      .sidebar.expanded {
            max-height: 100vh;
        }

      .hamburger-icon,
      .close-icon {
        color: #054D94;
        cursor: pointer;
        
      }

       .main-item {
            cursor: pointer;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2); 
        }
        
         .main-item a {
            text-decoration: none;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 1.5rem;
            transition: background-color 0.3s;
        }
        
         .main-item a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
      

      .collapse-arrow {
        transition: transform 0.3s ease-in-out;
      }
      
      .sub-items {
        overflow: hidden;
        max-height: 0;
        transition: max-height 0.3s ease-in-out;
        background-color: #fff;
      }
      
        .sub-items a {
            color: #054D94;
            padding: 0.5rem 1.5rem;
            display: block;
            transition: background-color 0.3s;
        }
      
       .sub-items a:hover {
            background-color: rgba(0, 0, 0, 0.1);
        }

      .main-item.expanded .collapse-arrow {
        transform: rotate(180deg);
      }

      .main-item.expanded .sub-items {
        max-height: 100vh;
      }

      @media only screen and (max-width: 768px) {
        .container {
          overflow-x: hidden;
        }
      }

      @media only screen and (min-width: 992px) {
        .sidebar-toggle,
        .sidebar {
          display: none;
        }
      }
    </style>

    <div class="mobile">
      <div class="sidebar-toggle mobile-heading p-4">
        <a href="{{ url('/') }}">
          <img class="sidebar-toggle" src="{{ asset('images/logo/logo_npiub.png') }}" alt="NPIUB Logo" title="Home">
        </a>
        <!--<h1 class="sidebar-toggle fs-4 p-2">{!! $mobileTitle ?? 'NPIUB' !!}</h1>-->
        <div class="d-flex gap-3">
            <div class="">
                <a href="https://npiub.pipilikasoft.com/" class="btn btn-secondary btn-sm border" role="button" aria-pressed="true">i-EMS</a>
                
            </div>
            
            <!--<div class="">-->
            <!--    <a href="https://convocation.npiub.edu.bd/" class="btn btn-primary btn-sm border" role="button" aria-pressed="true">Convocation</a>-->
                
            <!--</div>-->
        </div>
        
        
        
        <div class="sidebar-toggle fs-2" onclick="toggleMenu()"><i class="fa-regular fa-bars"></i></div>
      </div>
      
      <nav class="sidebar collapsed">
        <div class="sidebar-items fs-5">
          <!-- Sidebar items with main categories and sub-links -->
          <div class="main-item" onclick="toggleSubItems(this)">
            <a href="#about">About<span class="collapse-arrow"><i class="fas fa-chevron-down"></i></span></a>
            <div class="sub-items fs-6">
              <a href="{{ url('/vision-mission') }}">Vision & Mission</a>
              <!--<a href="#">Accreditation</a>-->
              <a href="{{ url('/academic-council') }}">Academic Council</a>
              <a href="{{ url('/syndicate') }}">Syndicate</a>
              <a href="{{ url('/board-of-trustees') }}">Board of Trustees</a>
              <!--<a href="#">Students' Organization</a>-->
              <a href="{{ route('contact.location') }}">Location</a>
              <a href="{{ route('contact.index') }}">Contact Us</a>
            </div>
          </div>
          
          <div class="main-item" onclick="toggleSubItems(this)">
            <a href="#academic" class="collapsed">Academic<span class="collapse-arrow"><i class="fas fa-chevron-down"></i></span></a>
            <div class="sub-items fs-6">
              <a href="{{ route('department.cse') }}">Computer Science and Engineering (CSE)</a>
              <a href="{{ route('department.eee') }}">Electrical and Electronics Engineering (EEE)</a>
              <a href="{{ route('department.food_eng') }}">Food Engineering</a>
              <a href="{{ route('department.bba') }}">Bachelor of Business Administration (BBA)</a>
              <a href="{{ route('department.mba') }}">Master of Business Administration (MBA)</a>
              <a href="{{ route('department.english') }}">B.A in English</a>
              <a href="{{ route('news.archives') }}">News and Events</a>
              <a href="{{ route('galleries.galleries') }}">Galleries</a>
              <!--<a href="#">Central Library</a>-->
             <a href="{{ route('alumni.alumni') }}">Alumni</a>
              <!--<a href="#">Computer Science Club</a>-->
              <a href="#">Academic Calendar</a>
            </div>
          </div>
          
          <div class="main-item" onclick="toggleSubItems(this)">
            <a href="#academic" class="collapsed">Admission<span class="collapse-arrow"><i class="fas fa-chevron-down"></i></span></a>
            <div class="sub-items fs-6">
              <a href="{{ url('/undergraduate-program') }}">Undergraduate Program Requirements</a>
              <a href="{{ url('/graduate-program') }}">Graduate Program Requirements</a>
              <!--<a href="#">Brochure / Flyer</a>-->
              <!--<a href="#">Admission Checklist & Documents</a>-->
              <a href="#">Financial Aid & Scholarships</a>
              <a href="#">Credits Transfer Guidelines</a>
              <a href="#">Tuition & Other Fees</a>
              <a href="{{ url('/faqs') }}">Admission FAQs</a>
              <a href="#">Admission Contact</a>
            </div>
          </div>
          
          <div class="main-item" onclick="toggleSubItems(this)">
            <a href="#academic" class="collapsed">Offices<span class="collapse-arrow"><i class="fas fa-chevron-down"></i></span></a>
            <div class="sub-items fs-6">
              <a href="{{ route('offices.vice_chancellor') }}">Office of the Vice-Chancellor</a>
              <a href="{{ route('offices.pro_vc') }}">Office of the Pro-VC</a>
              <a href="{{ route('offices.treasurer') }}">Office of the Treasurer</a>
              <a href="{{ route('offices.registrar') }}">Office of the Registrar</a>
              <a href="{{ route('offices.controller_of_examinations') }}">Office of the Controller of Examinations</a>
              <a href="{{ route('offices.director_of_accounts') }}">Office of the Director of Accounts</a>
              <a href="{{ route('offices.library') }}">Library</a>
              <a href="{{ route('offices.admissions') }}">Admissions</a>
              <a href="{{ route('offices.iqac') }}">IQAC</a>
            </div>
          </div>
          
          <div class="main-item" onclick="toggleSubItems(this)">
            <a href="#academic" class="collapsed">Research<span class="collapse-arrow"><i class="fas fa-chevron-down"></i></span></a>
            <div class="sub-items fs-6">
              <a href="/research">Explore Research</a>
              <!--<a href="#">Innovation</a>-->
              <!--<a href="#">Funded Projects</a>-->
              <!--<a href="#">NPIUB Research Center</a>-->
              <!--<a href="#">Research Achievements</a>-->
            </div>
          </div>

          <div class="main-item" onclick="toggleSubItems(this)">
            <a href="#academic" class="collapsed">Quick Links<span class="collapse-arrow"><i class="fas fa-chevron-down"></i></span></a>
            <div class="sub-items fs-6">
               <a href="#">Forms and Downloads</a>
                  <a href="{{ route('notices.board') }}">Notices</a>
                  <a href="https://npiub.pipilikasoft.com/">Student Portal</a>
                  <a href="#">Career at NPIUB</a>
                  <a href="{{ route('contact.location') }}">Location</a>
                  <a href="{{ route('contact.index') }}">Contact Us</a>
            </div>
          </div>
          
          <!-- Repeat the structure above for each main-item -->
          
          <!-- Additional main items as needed -->
        </div>
      </nav>
    </div>

    <script defer>
      function toggleMenu() {
        const sidebar = document.querySelector('.sidebar');
        const sidebarToggleIcon = document.querySelector('.sidebar-toggle i');

        sidebar.classList.toggle('expanded');
        sidebarToggleIcon.classList.toggle('fa-bars');
        sidebarToggleIcon.classList.toggle('fa-times');
      }

      function toggleSubItems(element) {
        const allMainItems = document.querySelectorAll('.main-item');

        allMainItems.forEach(item => {
          if (item !== element) item.classList.remove('expanded');
        });

        element.classList.toggle('expanded');
      }
    </script>


