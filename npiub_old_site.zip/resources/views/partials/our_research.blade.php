
  <style>
    /* Custom styles */
    
     #research{
        /*background-color: #ffffff;*/
        background: linear-gradient(to right, #1d3557, #054D94) !important;
      /*background-image: url("https://www.transparenttextures.com/patterns/dimension.png");*/
      padding: 2rem 0;
    }

    .research-container {
      position: relative; /* Ensure relative positioning for absolute positioning of pagination */
      /* border: 1px solid red; */
      padding: 4rem 1rem !important;
      overflow: hidden;
    }
    .research-pagination {
      position: absolute; /* Position the pagination dots */
      bottom: 2rem !important; /* Adjust as per your requirement */
    }
    .swiper-slide {
      /* padding: 0 10px; Adjust padding to maintain spacing */
      height: 100%;
    }

    .swiper-button-prev:after,
 .swiper-button-next:after {
   --swiper-navigation-size: 1rem;
 }

 .swiper-button-prev,
 .swiper-button-next {
  background: rgba(0, 123, 255, 0.5); /* Reduced opacity */
  width: 2.8rem;
  height: 2.8rem;
  color: #fff; /* Text color of the buttons */
  border-radius: 50%; /* Make the buttons circular */
  cursor: pointer; /* Change cursor to pointer on hover */
  z-index: 10; /* Ensure buttons are above other elements */
  transition: background-color 0.3s; /* Smooth transition */
}

.swiper-button-prev:hover,
.swiper-button-next:hover {
  background: rgba(0, 123, 255, 1); /* Full opacity on hover */
}

    .swiper-button-prev {
      left: 5px; /* Position the previous button */
    }
    .swiper-button-next {
      right: 5px; /* Position the next button */
    }
    .swiper-slide {
      padding: 0 10px; /* Adjust padding to maintain spacing */
      
    }

    .research-card {
      background: #fff;
      border: none;
      border-top: 4px solid #007BFF;
      border-radius: 0 0 .5rem .5rem;
      overflow: hidden;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      /* display: flex;
    flex-direction: column;
    justify-content: space-between; */
    height: 100%; /* Ensure the card takes up the full height */
    }
    .research-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 30px 60px rgba(0, 0, 0, 0.2);
    }
    .research-card img {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
      object-fit: cover;
      transition: transform 0.3s ease;
      width: 100%;
    height: auto;
    aspect-ratio: 16/9; /* Set a fixed aspect ratio */
    }
    .research-card:hover img {
      transform: scale(1.05);
    }
    .card-title {
      display: -webkit-box;
      -webkit-line-clamp: 2; /* Limit to 2 lines */
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      /* Optional: add additional styling as needed */
    }
    .card-text {
      font-size: 18px;
      line-height: 1.6;
      color: #666;
    }
    .research-head {
      font-weight: 700;
      /*color: #054D94;*/
      color: #fff;
    }
    .swiper-container{
        max-width: 1400px;
      margin: 0 auto;
    }
    
  </style>
</head>
<body>
    <section id="research" class="bg-white text-white">
    <div class="container-fluid">
        <h2 class="text-center research-head">Explore Our Research</h2> <!-- Section Heading -->
        <div class="swiper-container research-container">
            <div class="swiper-wrapper">
                @foreach($latestResearch as $research)
                <div class="swiper-slide">
                    <a href="{{ route('research.view', $research->slug) }}" class="research-card-link text-decoration-none">
                        <div class="research-card">
                            <img src="{{ asset('storage/'.$research->image) }}" class="card-img-top" alt="Research Image">
                            <div class="card-body p-3 bg-white">
                                <h6 class="card-title mb-2 text-decoration-underline ">{{ $research->title }}</h6>
                                <p class="card-date small m-0 text-muted">{{ $research->created_at->format('F j, Y') }}</p>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
            <!-- Add pagination -->
            <div class="swiper-pagination research-pagination"></div>
            <!-- Add navigation buttons -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
        <div class="text-center">
            <a href="{{ route('research.archives') }}"><button class="btn btn-primary research-btn">Research Archives</button></a> <!-- Search Archives Button -->
        </div>
    </div>
</section>

<script>
    var swiper = new Swiper('.research-container', {
        slidesPerView: 4,
        spaceBetween: 30,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        loop: true, // Enable loop
        breakpoints: {
            992: {
                slidesPerView: 4,
                
            },
            768: {
                slidesPerView: 2,
                
            },
            0: {
                slidesPerView: 1,
                
            },
        },
    });

    // Adjust card heights
    function adjustCardHeights() {
        var cards = document.querySelectorAll('.swiper-slide .research-card');
        var maxHeight = 0;
        cards.forEach(function(card) {
            maxHeight = Math.max(maxHeight, card.offsetHeight);
        });
        cards.forEach(function(card) {
            card.style.height = maxHeight + 'px';
        });
    }
    adjustCardHeights();
</script>

<!-- <script>
        $(document).ready(function () {
            $('.card-title').each(function () {
                var title = $(this);
                if (title.text().length > 50) {
                    title.text(title.text().substring(0, 55) + '...');
                }
            });
        });
    </script> -->


