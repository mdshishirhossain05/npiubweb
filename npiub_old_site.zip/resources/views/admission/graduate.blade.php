@extends('layouts.default')

@section('title', 'Graduate program requirements - NPIUB, North Pacific International University of Bangladesh')

@section('content')

@include('partials.graduate')
@endsection