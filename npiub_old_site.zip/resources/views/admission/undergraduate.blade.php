@extends('layouts.default')

@section('title', 'Undergraduate program requirements - NPIUB, North Pacific International University of Bangladesh')

@section('content')

@include('partials.undergraduate')
@endsection