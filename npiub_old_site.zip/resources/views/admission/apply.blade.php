@extends('layouts.default')

@section('title', 'Join Our University - NPIUB, North Pacific International University of Bangladesh')

@section('content')
<!-- Hero Section -->
<section id="hero" class="text-center text-white py-5" style="background-image: url('/images/admission-banner.jpg'); background-size: cover; background-color: #054D94;">
    <div class="container">
        <h1 class="display-4">Join Our University</h1>
        <p class="lead">Your future starts here. Explore our admissions process and become part of our academic family.</p>
        <a href="http://student.127.0.0.1:8000/login" class="btn btn-primary btn-lg mt-4">Apply Now</a>

    </div>
</section>
<!-- Programs Offered Section -->
<section id="programs" class="py-5">
    <div class="container">
        <h2 class="text-center mb-5">Programs We Offer</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <img src="/images/home_slider/apply-admission-2.jpg" class="card-img-top" alt="Computer Science and Engineering">
                    <div class="card-body">
                        <h5 class="card-title">Computer Science and Engineering (CSE)</h5>
                        <p class="card-text">Explore the fundamentals of computer science and engineering.</p>
                        <a href="#" class="btn btn-outline-primary">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <img src="/images/home_slider/apply-admission-2.jpg" class="card-img-top" alt="Electrical and Electronics Engineering">
                    <div class="card-body">
                        <h5 class="card-title">Electrical and Electronics Engineering (EEE)</h5>
                        <p class="card-text">Delve into the world of electrical systems and electronics.</p>
                        <a href="#" class="btn btn-outline-primary">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <img src="/images/home_slider/apply-admission-2.jpg" class="card-img-top" alt="Food Engineering">
                    <div class="card-body">
                        <h5 class="card-title">Food Engineering</h5>
                        <p class="card-text">Learn about food processing, preservation, and safety.</p>
                        <a href="#" class="btn btn-outline-primary">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <img src="/images/home_slider/apply-admission-2.jpg" class="card-img-top" alt="Bachelor of Business Administration">
                    <div class="card-body">
                        <h5 class="card-title">Bachelor of Business Administration (BBA)</h5>
                        <p class="card-text">Prepare for a successful career in business management.</p>
                        <a href="#" class="btn btn-outline-primary">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <img src="/images/home_slider/apply-admission-2.jpg" class="card-img-top" alt="Master of Business Administration">
                    <div class="card-body">
                        <h5 class="card-title">Master of Business Administration (MBA)</h5>
                        <p class="card-text">Enhance your leadership and management skills with an MBA.</p>
                        <a href="#" class="btn btn-outline-primary">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <img src="/images/home_slider/apply-admission-2.jpg" class="card-img-top" alt="B.A in English">
                    <div class="card-body">
                        <h5 class="card-title">B.A in English</h5>
                        <p class="card-text">Engage in literature, language, and cultural studies.</p>
                        <a href="#" class="btn btn-outline-primary">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Why Choose Us Section -->
<!-- Why Choose Us Section -->
<section id="why-choose-us" class="bg-light py-5">
    <div class="container">
        <h2 class="text-center mb-4">Why Choose Us</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="media">
                    <i class="bi bi-award-fill display-4 text-primary me-3"></i>
                    <div class="media-body">
                        <h5 class="mt-0">Top-Ranked University</h5>
                        <p class="">We are ranked among the top universities globally, offering world-class education and facilities.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="media">
                    <i class="bi bi-lightbulb-fill display-4 text-primary me-3"></i>
                    <div class="media-body">
                        <h5 class="mt-0">Innovative Learning</h5>
                        <p>Our innovative teaching methods ensure that you are equipped with real-world skills for future success.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="media">
                    <i class="bi bi-globe display-4 text-primary me-3"></i>
                    <div class="media-body">
                        <h5 class="mt-0">Global Opportunities</h5>
                        <p>We provide opportunities for international exposure through exchange programs and internships.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- FAQ Section -->
@include('partials.faqs')

<!-- Contact Information Section -->


<style>
    h2{
      font-weight: 700;
      color: #054D94;
    }
</style>

@endsection
