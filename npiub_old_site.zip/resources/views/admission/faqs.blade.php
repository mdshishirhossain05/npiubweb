@extends('layouts.default')

@section('title', 'FAQs - NPIUB, North Pacific International University of Bangladesh')

@section('content')

@include('partials.faqs')
@endsection