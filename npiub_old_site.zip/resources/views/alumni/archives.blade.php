@extends('layouts.default')

@section('title', 'Alumni Archives - NPIUB, North Pacific International University of Bangladesh')

@section('content')

@include('alumni.alumnus')
@endsection