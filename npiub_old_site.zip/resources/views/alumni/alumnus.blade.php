
    <style>
    /* Custom styles */
    .departments{
        z-index: 2 !important;
    }
    .dropdown-menu {
            width: 100%;
            border: none;
            border-radius: 0.25rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            --bs-dropdown-padding-y: 0;
            
        }
        .dropdown-item {
            padding: .8rem !important;
            transition: background-color 0.3s, color 0.3s;
          
        }
        .dropdown-item:hover {
            background-color: #054D94;
            color: white;
        }
        .dropdown-toggle::after {
            transition: transform 0.3s;
        }
        .dropdown-toggle.collapsed::after {
            /* transform: rotate(180deg); */
        }
    .card {
    position: relative;
    padding-top: 4rem;
    background-color: #054D94 !important;
    border: none !important;
    border-top: 4px solid #007BFF;
    border-radius: 0 0rem .5rem .5rem !important;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    overflow: visible;
    /* z-index: 1; */
    /*height: 100%;*/
    margin-bottom: 4rem;
}

.card:hover {
    transform: translateY(-10px);
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.2);
}

.card img {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    object-fit: cover;
    transition: transform 0.3s ease;
    border-radius: 50%;
    max-width: 120px;
    margin: 0 auto;
    position: absolute;
    top: -4rem; /* Adjust if needed */
    left: 50%; /* Adjust if needed */
    transform: translateX(-50%);
}

.card:hover img {
    transform: scale(1.03) translateX(-50%);
}

.card_shadow {
    width: 75%;
    height: 75%;
    background-color: #fff;
    border-radius: 50%;
    position: absolute;
    top: 1rem;
    left: 0;
    right: 0;
    margin-inline: auto;
    filter: blur(45px);
}

.card-body {
    padding: 1rem;
    border-radius: 1rem 1rem 0.5rem 0.5rem;
    background-color: #fff;
    z-index: 1;
}

.card-name {
    font-weight: bold;
    color: #054D94;
}

.card-text {
    font-size: 0.75em !important;
}

.text-position {
    font-size: 0.7rem;
}

.alumni-head {
    font-weight: 700;
    color: #054d94;
}

.dropdown-search{
    margin-bottom: 6rem;
}



    </style>

    <section id="alumni-archives" class="bg-light py-5 ">
        <div class="container">
            <h2 class="text-center alumni-head mb-4">Explore Our Alumni</h2>
            <div class="row justify-content-start dropdown-search">
            <div class="col-md-6">
                    <div class="dropdown departments">
                        <button class="btn btn-outline-primary dropdown-toggle w-100 d-flex justify-content-between align-items-center btn-dropdown position" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            {{ $departments[$department] ?? 'Select Department' }}
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            @foreach($departments as $key => $dept)
                                <li><a class="dropdown-item" href="{{ route('alumni.alumni', ['department' => $key]) }}" {{ $key === $department ? 'aria-current="true"' : '' }}>
                                    {{ $dept }}
                                </a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <form action="{{ route('alumni.alumni') }}" method="GET" class="d-flex">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search Alumni..." value="{{ request('search') }}">
                        <input type="hidden" name="department" value="{{ $department }}">
                        <button type="submit" class="btn btn-primary ">Search</button>
                    </form>
                </div>
            </div>

            <div id="alumniContainer" class="row">
                @php
                    $departmentNames = [
                        'cse' => 'CSE',
                        'eee' => 'EEE',
                        'food-eng' => 'Food Engineering',
                        'bba' => 'BBA',
                        'mba' => 'MBA',
                        'english' => 'B.A in English'
                    ];
                @endphp

                @php
                    function ordinal($number) {
                        $ends = ['th','st','nd','rd','th','th','th','th','th','th'];
                        if ((($number % 100) >= 11) && (($number % 100) <= 13)) {
                            return $number . 'th';
                        } else {
                            return $number . $ends[$number % 10];
                        }
                    }
                @endphp


                    @forelse ($alumni as $item)
                        <div class="alumnicard col-md-3 mb-4">
                            <a href="{{ route('alumni.view', $item->slug) }}" class="alumni-card-link text-decoration-none">
                                <div class="card">
                                    <div class="card_shadow"></div>
                                    <img src="{{ asset('storage/' . $item->image) }}" class="card-img-top" alt="Alumni Image">
                                    <div class="card-body text-center">
                                        <h5 class="card-name">{{ $item->name }}</h5>
                                        <p class="card-text small m-0"><strong>Batch:</strong> {{ ordinal($item->batch) }} - <strong>Graduation Year:</strong> {{ $item->graduation_year }}</p>
                                        <p class="card-text small mb-2">Dept. of {{ $departmentNames[$item->department] ?? ucfirst($item->department) }}, NPIUB</p>
                                        <p class="card-text small text-position "><strong>Current Position:</strong> {{ $item->current_position }}</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        @empty
                <div class="col-12">
                    <p id="emptyMessage" class="text-center">No alumni records found.</p>
                </div>
              @endforelse
            </div>


             <!-- Pagination Links -->
       <div class="container mb-5">
            {{ $alumni->appends(['search' => request()->query('search')])->links('pagination::bootstrap-5') }}
        </div>

        </div>
    </section>


    <script>
        // Adjust card heights
    function adjustCardHeights() {
        var cards = document.querySelectorAll('.card');
        var maxHeight = 0;
        cards.forEach(function(card) {
            maxHeight = Math.max(maxHeight, card.offsetHeight);
        });
        cards.forEach(function(card) {
            card.style.height = maxHeight + 'px';
        });
    }
    adjustCardHeights();
    </script>




    