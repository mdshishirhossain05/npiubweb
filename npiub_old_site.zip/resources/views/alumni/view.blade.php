@extends('layouts.default')

@section('title', $alumnus->name . ' - Alumni Details - NPIUB, North Pacific International University of Bangladesh')


@section('content')
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }
        .breadcrumb {
            background-color: transparent;
            margin-bottom: 30px;
        }
        .alumni-container {
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
        }
        .alumni-header {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .alumni-header img {
            border-radius: 50%;
            width: 120px;
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
        }
        .alumni-header h1 {
            font-size: 24px;
            color: #004085;
            margin: 0;
        }
        .alumni-meta {
            font-size: 14px;
            color: #6c757d;
        }
        .alumni-meta strong {
            color: #333;
        }
        .alumni-content {
            font-size: 16px;
            line-height: 1.6;
        }
        .alumni-content h2 {
            font-size: 22px;
            color: #004085;
            margin-top: 20px;
        }
        .alumni-content p {
            margin-bottom: 20px;
        }
        .btn-primary {
            background-color: #004085;
            border-color: #004085;
        }
        .btn-primary:hover {
            background-color: #003066;
            border-color: #003066;
        }

        .social {
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        }
        
        .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration:none;
        }
        
        .social a i {
        color: #054D94;
        font-size: 16px;
        margin: 0 2px;
        }
        
       .social a:hover {
        background: #054D94;
        }
        
        .social a:hover i {
        color: #fff;
        }
        
        .social a+a {
        margin-left: 8px;
        }

        .alumni-header p{
            margin-bottom: 0.3rem !important;
        }

        @media (max-width: 767px) {
    .alumni-header {
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    .alumni-header img {
        margin-bottom: 20px;
        margin-right: 0;
    }
    .social {
        justify-content: center;
    }
}

    </style>


<div class="container pt-5 pb-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item"><a href="/alumni">Alumni</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ $alumnus->name }}</li>
        </ol>
    </nav>
    
    @php
        $departmentNames = [
            'cse' => 'Computer Science and Engineering (CSE)',
            'eee' => 'Electrical and Electronics Engineering (EEE)',
            'food-eng' => 'Food Engineering',
            'bba' => 'Bachelor of Business Administration (BBA)',
            'mba' => 'Master of Business Administration (MBA)',
            'english' => 'B.A in English'
        ];
    @endphp
    
    @php
        function ordinal($number) {
            $ends = ['th','st','nd','rd','th','th','th','th','th','th'];
            if ((($number % 100) >= 11) && (($number % 100) <= 13)) {
                return $number . 'th';
            } else {
                return $number . $ends[$number % 10];
            }
        }
    @endphp
    
     

    <!-- Alumni Container -->
    <div class="alumni-container">
        <div class="alumni-header">
            <img src="{{ asset('storage/' . $alumnus->image) }}" alt="Alumni Image">
            <div>
                <h1 class="alumni-name mb-3"><b>{{ $alumnus->name }}</b></h1>
                <div class="alumni-meta">
                <p><strong>Department:</strong> {{ $departmentNames[$alumnus->department] ?? ucfirst($alumnus->department) }}, NPIUB</p>
                    <p><strong>Batch:</strong> {{  ordinal($alumnus->batch) }}</p>
                    <p><strong>Graduation Year:</strong> {{ $alumnus->graduation_year }}</p>
                    <p><strong>Current Position:</strong> {{ $alumnus->current_position }}</p>
                <div class="social mt-3">
                    <a href="{{ $alumnus->facebook }}"><i class="fab fa-facebook"></i></a>
                    <a href="mailto:{{ $alumnus->email }}"><i class="fas fa-envelope"></i></a>
                    <a href="{{ $alumnus->linkedin }}"><i class="fab fa-linkedin"></i></a>
                    <a href="{{ $alumnus->whatsapp }}"> <i class="fab fa-whatsapp"></i> </a>
                  </div>
                </div>
            </div>
        </div>
        

        <div class="alumni-content">
            <h2>Biography</h2>
            <p>{{ $alumnus->bio }}</p>
        </div>
    </div>
</div>

@endsection

    