<style>
    body {
      /*background-color: #f8f9fa;*/
    }
    #contactOffice{
        background-color: #f1f1f1
    }
    .offices{
      max-width: 900px !important;
    }

    .office-details {
        padding: 10px 0;
    }

    .office-name {
        font-size: 1.1rem;
        font-weight: 600;
        color: #054D94;
        margin-bottom: 3px;
    }

    .office-position,
    .office-type {
        font-size: 0.95rem;
        color: #333;
        border-bottom: 1px solid #054D94;
        display: inline-block;
        margin-bottom: 6px;
    }

    .office-contact {
        margin-top: 8px;
        color: #054D94;
        font-size: 0.95rem;
    }

    .social {
        margin-top: 8px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
    }
        
    .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration: none;
    }
        
    .social a i {
        color: #054D94;
        font-size: 14px;
        margin: 0 2px;
    }
        
    .social a:hover {
        background: #054D94;
    }
        
    .social a:hover i {
        color: #fff;
    }
        
    .social a + a {
        margin-left: 6px;
    }

    .office-item {
      margin-bottom: 1rem;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 6px;
      overflow: hidden;
    }

    .office-item .card-header {
      cursor: pointer;
      position: relative;
      padding-right: 40px; /* Space for the icons */
      background: #f3f7fb;
    }
    .office-item .card-header .btn-link {
      color: #292525;
      font-weight: 600;
      text-decoration: none;
      display: block;
    }
    .office-item .card-header .btn-link:hover {
      text-decoration: none;
    }
    .office-item .card-header .icon {
      position: absolute;
      top: 50%;
      right: 2rem;
      transform: translateY(-50%);
      font-size: 1.1em;
      color: #054D94;
    }

    .office-heading{
      font-weight: 700;
      color: #054D94;
    }

    .card, .card-header{
      border: none !important;
    }

    /* Each member card inside accordion */
    .office-member {
        background: #ffffff;
        border-radius: 6px;
        padding: 12px 16px;
        margin-bottom: 10px;
        border: 1px solid #e4e7ee;
        position: relative;
    }

    /* Soft separator between members (except last one) */
    .office-member:not(:last-child)::after {
        content: "";
        position: absolute;
        left: 0;
        right: 0;
        bottom: -6px;
        border-bottom: 1px dashed #d4d7e0;
        opacity: 0.8;
    }

    /* Badge for head of office (priority 0) */
    .head-badge {
        display: inline-block;
        font-size: 0.75rem;
        padding: 2px 8px;
        border-radius: 999px;
        background: #054D94;
        color: #fff;
        margin-left: 8px;
    }

    @media (max-width: 575.98px) {
        .office-member {
            padding: 10px 12px;
        }
        .office-name {
            font-size: 1rem;
        }
    }
</style>

<div id="contactOffice" class="pt-5 pb-5">
    <div class="container offices">
        <h2 class="text-center mb-4 office-heading">Office Contacts Directory</h2> 
        <div id="accordionOffice" class="row">
            <div class="col-md-12 mx-auto">

                {{-- OUTER LOOP: each office TYPE --}}
                @foreach($types as $type)
                    <div class="office-item">
                        <div class="card bg-light">
                            <div class="card-header" id="heading-{{ $loop->index }}">
                                <h5 class="mb-0 d-flex justify-content-between align-items-center">
                                    <button class="btn btn-link" type="button">
                                        Office of the {{ $type->type }}
                                    </button>
                                    <span class="icon">
                                        <i class="fa-regular fa-plus"></i>
                                    </span>
                                </h5>
                            </div>

                            {{-- use simple jQuery show/hide instead of Bootstrap collapse JS --}}
                            <div id="collapse-{{ $loop->index }}" 
                                 class="office-collapse" 
                                 style="display:none;">
                                <div class="card-body">
                                    <div class="row">
                                        {{-- INNER LOOP: all offices under this type --}}
                                        @foreach($offices->where('type', $type->type) as $office)
                                            <div class="col-md-12">
                                                <div class="office-member">
                                                    <div class="office-details">
                                                        <h3 class="office-name">
                                                            {{ $office->name }}
                                                            @if(isset($office->priority) && $office->priority === 0)
                                                                <span class="head-badge">Head of Office</span>
                                                            @endif
                                                        </h3>
                                                        <p class="office-position pb-2">{{ $office->position }}</p>
                                                        <div class="office-contact">
                                                            @if($office->contact)
                                                                <i class="fa-solid fa-phone"></i>
                                                                <strong>Contact:</strong>
                                                                <a href="tel:{{ $office->contact }}">{{ $office->contact }}</a>
                                                            @endif
                                                        </div>
                                                        <div class="office-contact social mt-2">
                                                            @if($office->facebook)
                                                                <a href="{{ $office->facebook }}"><i class="fab fa-facebook"></i></a>
                                                            @endif
                                                            @if($office->email)
                                                                <a href="mailto:{{ $office->email }}"><i class="fas fa-envelope"></i></a>
                                                            @endif
                                                            @if($office->linkedin)
                                                                <a href="{{ $office->linkedin }}"><i class="fab fa-linkedin"></i></a>
                                                            @endif
                                                            @if($office->whatsapp)
                                                                <a href="https://wa.me/{{ $office->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach

            </div>
        </div>
    </div>
</div>

<script>
    // make sure jQuery is included in your layout
    $(document).ready(function(){
        $('.office-item .card-header').on('click', function(){

            var $item   = $(this).closest('.office-item');
            var $panel  = $item.find('.office-collapse');

            // close others
            $('.office-item .office-collapse').not($panel).slideUp();
            $('.office-item .icon i').not($item.find('.icon i'))
                .removeClass('fa-minus')
                .addClass('fa-plus');

            // toggle this one
            $panel.slideToggle();
            $item.find('.icon i').toggleClass('fa-plus fa-minus');
        });
    });
</script>
