@extends('layouts.default')

@section('title', 'Contact Us - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('contact.directory')
    @include('contact.send')
@endsection

