
  <style>
    body {
      /*background-color: #f8f9fa;*/
    }

    .contacts {
      max-width: 900px !important;
      margin: 50px auto;
      padding: 2rem;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      position: relative;
      
    }
    .address, .phone, .email {
      margin-bottom: 20px;
      text-align: center;
      font-weight: 400;

    }
    .topic {
      
      font-weight: 700;
      color: #054D94;
    }
    .text-one, .text-two {
      
      color: #666;
    }
    .topic-text {
      font-size: 2rem;
      font-weight: 700;
      color: #333;
      margin-bottom: 20px;
    }
    .contact-form input[type="text"], 
    .contact-form input[type="email"], 
    .contact-form input[type="tel"], 
    .contact-form textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-bottom: 20px;
      transition: border-color 0.3s;
    }
    .contact-form input[type="text"]:focus, 
    .contact-form input[type="email"]:focus, 
    .contact-form input[type="tel"]:focus, 
    .contact-form textarea:focus {
      outline: none;
      border-color: #3e2093;
    }
    .contact-form textarea {
      resize: none;
    }
    
    

    

    /* Social Icons */
    .social a{
        text-decoration:none;
        border-radius: 50%;
    }
    .social-icons {
      list-style-type: none;
      padding: 0;
      margin: 0 auto;
    }

    .social-icons li {
      display: inline-block;
      gap: 1rem;
      margin-bottom: 1rem;

      
    }



    .social-icons li a {
      display: block;
      width: 30px !important; /* Adjust size as needed */
      height: 30px !important; /* Adjust size as needed */
      line-height: 30px !important; /* Center the icon vertically */
      text-align: center; /* Center the icon horizontally */
      background-color: #054D94; /* Background color of the round icon */
      color: #ffffff;
      border-radius: 50%; /* Make the icon round */
      transition: transform 0.3s ease; /* Add transition for zoom effect */
      
    }

    .social-icons li a:hover {
      transform: scale(1.2); /* Zoom effect on hover */
    }

    .follow-us-heading{
      font-weight: 700;
    }

    .container .left-side::before {
      content: "";
      position: absolute;
      height: 80%;
      width: 2px;  
      top: 50%;
      left: 32%; 
      background: #ddd;
      transform: translateY(-50%);
      
    }

    @media screen and (max-width: 767px) {
      .container .left-side::before {
        height: 2px;
        width: 80%;
        right: auto;
        left: 50%;
        top: 50%;
        transform: translateX(-50%) rotate(180deg);
      }
    }

  </style>

  
  <div class="container contacts">


    <div class="row">
      <div class="col-md-4 p-4 justify-content-center">
        <div class="left-side">
          <div class="address details align">
            <i class="fa-duotone fa-location-dot fa-lg"></i>
            <div class="topic">Address</div>
            <div class="text-one">495, East Basta, Singair, Manikganj, Dhaka</div>
            <div class="text-one"><a href="">View in google map</a></div>
          </div>
          <div class="phone details">
            <i class="fa-duotone fa-phone fa-lg"></i>
            <div class="topic">Phone</div>
            <div class="text-one"><a href="tel:01703-444111">01703-444111</a></div>
            <div class="text-two"><a href="tel:+880 1704-444888">01704-444888</a></div>
          </div>
          <div class="phone details">
            <i class="fa-duotone fa-solid fa-user-headset fa-lg"></i>
            <div class="topic">Hot-Line (24/7)</div>
            <div class="text-one"><a href="tel:01969-992015">01969-992015</a></div>
          </div>
          <div class="email details">
            <i class="fa-duotone fa-envelope fa-lg"></i>
            <div class="topic">Email</div>
            <div class="text-one"><a href="mailto:info@npiub.edu.bd">info@npiub.edu.bd</a></div>
          </div>

          <div class="follow-us text-center">
            <h5 class="follow-us-heading p-2">Follow Us</h5>
            <ul class="list-inline social-icons">
              <li class="list-inline-item"><a href="#"><i class="fab fa-facebook fa-sm"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-twitter fa-sm"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-youtube fa-sm"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin fa-sm"></i></a></li>
              <li class="list-inline-item"><a href="#"><i class="fab fa-instagram fa-sm"></i></a></li>
            </ul>
          </div>
          
        </div>     
      </div>

      <div class="col-md-8 p-4 text-center">
        <div class="right-side ml-5">

        @if(session('success'))
    <div class="alert alert-success m-3">
        {{ session('success') }}
    </div>
@endif

          <div class="topic-text">Send us a message</div>
          <form class="contact-form" action="{{ route('contact.send') }}" method="POST">
            @csrf
            <div class="form-group">
                <input type="text" class="form-control" name="name" placeholder="Enter your name" required>
            </div>
            <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <input type="tel" class="form-control" name="phone" placeholder="Enter your phone number" required>
            </div>
            <div class="form-group">
                <textarea class="form-control" name="message" rows="2" placeholder="Enter a brief description of your question" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Send Message</button>

            
        </form>

      </div>

      </div>
        
    </div>
  </div>

