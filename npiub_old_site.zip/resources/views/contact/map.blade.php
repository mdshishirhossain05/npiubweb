
    <style>
        /* body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            color: #343a40;
            font-size: 1rem;
            line-height: 1.6;
        }
         */
        .full-width-map {
            width: 100%;
            height: 500px;
            overflow: hidden;
            position: relative;
        }
        .full-width-map iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>

    <div class="">
        <div class="full-width-map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.3166802626547!2d90.22440001167632!3d23.8073354864976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755eb94fbd2b0ff%3A0x59f53688aacf51b1!2sNPI%20University%20of%20Bangladesh!5e0!3m2!1sen!2sbd!4v1718016168813!5m2!1sen!2sbd" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
