@extends('layouts.default')

@section('title', 'Location - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('contact.map')
    @include('contact.send')
@endsection
