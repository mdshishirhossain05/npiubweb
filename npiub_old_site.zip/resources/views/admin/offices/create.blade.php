{{-- resources/views/admin/offices/create.blade.php --}}
@extends('adminlte::page')

@section('title', 'Add Office')

@section('content_header')
    <h1>Add Office</h1>
@stop

@section('content')
<div class="card">
    <div class="card-body">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
            </div>
        @endif

        <form action="{{ route('offices.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <!-- Office Type -->
            <div class="form-group">
                <label for="type">Office Type</label>
                <select name="type" id="type" class="form-control" required>
                    <option value="">Select Office Type</option>
                    @foreach($officeTypes as $key => $value)
                        <option value="{{ $key }}" {{ old('type') == $key ? 'selected' : '' }}>{{ $value }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Basics -->
            <div class="form-group">
                <label for="name">Name <small class="text-muted">(e.g., Prof. John Doe)</small></label>
                <input type="text" name="name" id="name" class="form-control" value="{{ old('name') }}" required>
            </div>

            <div class="form-group">
                <label for="position">Position <small class="text-muted">(e.g., Vice Chancellor)</small></label>
                <input type="text" name="position" id="position" class="form-control" value="{{ old('position') }}" required>
            </div>

            <!-- ✅ Priority Field -->
            <div class="form-group">
                <label for="priority">Display Priority</label>
                <input type="number" name="priority" id="priority" class="form-control"
                       value="{{ old('priority', 1) }}" min="0" max="10">
                <small class="text-muted">
                    Lower number shows first.  
                    <strong>0 = Head of the Office</strong> (e.g., Registrar, VC, Treasurer).  
                    <br>1+ = Assistants or other members.
                </small>
            </div>

            <div class="form-group">
                <label for="contact">Contact <small class="text-muted">(phone or extension)</small></label>
                <input type="text" name="contact" id="contact" class="form-control" value="{{ old('contact') }}">
            </div>

            <div class="form-group">
                <label for="email">Email </label>
                <input type="email" name="email" id="email" class="form-control" value="{{ old('email') }}">
            </div>

            <div class="form-group">
                <label for="biography">Biography</label>
                <textarea name="biography" id="biography" class="form-control" rows="5" placeholder="Short bio...">{{ old('biography') }}</textarea>
                <small class="text-muted">Line breaks will be preserved on the public page.</small>
            </div>

            <!-- Degrees toggle -->
            <div class="form-group">
                <label>Want to add Degrees?</label><br>
                <label><input type="radio" name="add_degrees" value="yes" id="add_degrees_yes"> Yes</label>
                <label class="ml-2"><input type="radio" name="add_degrees" value="no" id="add_degrees_no" checked> No</label>
            </div>

            <!-- Degrees section -->
            <div id="degreesSection" style="display:none;">
                <label class="d-block">Degrees</label>
                <small class="text-muted d-block mb-2">
                    Enter each degree using these three fields: <strong>Degree Name</strong>, <strong>Institution / University</strong>, <strong>Details</strong> (e.g., Result, Department, Years).
                </small>

                <div id="degreeGroup">
                    <div class="degree-item border rounded p-2 mb-2">
                        <input type="text" name="degrees[0][degree_name]" class="form-control mb-2"
                               placeholder="Degree Name (e.g., Doctor of Philosophy)">
                        <input type="text" name="degrees[0][degree_university]" class="form-control mb-2"
                               placeholder="Institution / University (e.g., The Institute of Statistical Mathematics, Tokyo, Japan)">
                        <textarea name="degrees[0][degree_details]" class="form-control mb-2" rows="3"
                                  placeholder="Details (e.g., The Graduate University for Advanced Studies&#10;Result: Awarded (Department...)&#10;1992–1995)"></textarea>

                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
                            <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Research toggle -->
            <div class="form-group mt-3">
                <label>Want to add Research?</label><br>
                <label><input type="radio" name="add_research" value="yes" id="add_research_yes"> Yes</label>
                <label class="ml-2"><input type="radio" name="add_research" value="no" id="add_research_no" checked> No</label>
            </div>

            <!-- Research section -->
            <div id="researchSection" style="display:none;">
                <label class="d-block">Research</label>
                <small class="text-muted d-block mb-2">
                    Each item has a <strong>Title</strong> (linked), a <strong>URL</strong>, and a short <strong>Description</strong>. The public page will show a “Read more” button linking to the same URL.
                </small>

                <div id="researchGroup">
                    <div class="research-item border rounded p-2 mb-2">
                        <div class="d-flex mb-2">
                            <input type="text" name="research_interests[0][title]" class="form-control mr-2" placeholder="Research Title">
                            <input type="url" name="research_interests[0][url]" class="form-control" placeholder="https://example.com">
                        </div>
                        <textarea name="research_interests[0][description]" class="form-control mb-2" rows="3"
                                  placeholder="Short description (1–3 lines)"></textarea>

                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
                            <button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Social -->
            <div class="form-group">
                <label for="facebook">Facebook</label>
                <input type="url" name="facebook" id="facebook" class="form-control" value="{{ old('facebook') }}">
            </div>
            <div class="form-group">
                <label for="linkedin">LinkedIn</label>
                <input type="url" name="linkedin" id="linkedin" class="form-control" value="{{ old('linkedin') }}">
            </div>
            <div class="form-group">
                <label for="whatsapp">WhatsApp</label>
                <input type="text" name="whatsapp" id="whatsapp" class="form-control" value="{{ old('whatsapp') }}">
            </div>

            <!-- Image -->
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" name="image" id="image" class="form-control-file">
            </div>

            <button type="submit" class="btn btn-success">Add Office</button>
        </form>
    </div>
</div>
@stop

@section('js')
<script>
// --- Toggle sections
const degYes = document.getElementById('add_degrees_yes');
const degNo  = document.getElementById('add_degrees_no');
const resYes = document.getElementById('add_research_yes');
const resNo  = document.getElementById('add_research_no');

degYes.addEventListener('click', () => document.getElementById('degreesSection').style.display = 'block');
degNo .addEventListener('click', () => document.getElementById('degreesSection').style.display = 'none');
resYes.addEventListener('click', () => document.getElementById('researchSection').style.display = 'block');
resNo .addEventListener('click', () => document.getElementById('researchSection').style.display = 'none');

// --- Helpers to maintain "Add More" on first row only
function refreshAddButton(groupSelector, itemClass, btnId, makeBtnHtml) {
    const group = document.querySelector(groupSelector);
    if (!group) return;
    const items = group.querySelectorAll(itemClass);

    items.forEach((item, idx) => {
        const existing = item.querySelector('#' + btnId);
        if (idx === 0) {
            if (!existing) {
                const el = document.createElement('div');
                el.innerHTML = makeBtnHtml;
                item.querySelector('.d-flex.gap-2, .d-flex').appendChild(el.firstElementChild);
            }
        } else {
            if (existing) existing.remove();
        }
    });
}

document.addEventListener('click', function(e) {
    // Degrees: Add
    if (e.target && e.target.id === 'addDegreeBtn') {
        const group = document.getElementById('degreeGroup');
        const index = group.querySelectorAll('.degree-item').length;
        const wrap = document.createElement('div');
        wrap.className = 'degree-item border rounded p-2 mb-2';
        wrap.innerHTML = `
            <input type="text" name="degrees[${index}][degree_name]" class="form-control mb-2" placeholder="Degree Name (e.g., Doctor of Philosophy)">
            <input type="text" name="degrees[${index}][degree_university]" class="form-control mb-2" placeholder="Institution / University (e.g., The Institute of Statistical Mathematics, Tokyo, Japan)">
            <textarea name="degrees[${index}][degree_details]" class="form-control mb-2" rows="3" placeholder="Details (e.g., The Graduate University for Advanced Studies&#10;Result: Awarded (Department...)&#10;1992–1995)"></textarea>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
            </div>
        `;
        group.appendChild(wrap);
        refreshAddButton('#degreeGroup', '.degree-item', 'addDegreeBtn', `<button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>`);
    }

    // Degrees: Remove
    if (e.target && e.target.classList.contains('removeDegreeBtn')) {
        const group = document.getElementById('degreeGroup');
        e.target.closest('.degree-item').remove();
        if (group.querySelectorAll('.degree-item').length === 0) {
            const wrap = document.createElement('div');
            wrap.className = 'degree-item border rounded p-2 mb-2';
            wrap.innerHTML = `
                <input type="text" name="degrees[0][degree_name]" class="form-control mb-2" placeholder="Degree Name (e.g., Doctor of Philosophy)">
                <input type="text" name="degrees[0][degree_university]" class="form-control mb-2" placeholder="Institution / University (e.g., The Institute of Statistical Mathematics, Tokyo, Japan)">
                <textarea name="degrees[0][degree_details]" class="form-control mb-2" rows="3" placeholder="Details (e.g., The Graduate University for Advanced Studies&#10;Result: Awarded (Department...)&#10;1992–1995)"></textarea>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
                    <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>
                </div>
            `;
            group.appendChild(wrap);
        } else {
            refreshAddButton('#degreeGroup', '.degree-item', 'addDegreeBtn', `<button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>`);
        }
    }

    // Research: Add
    if (e.target && e.target.id === 'addResearchBtn') {
        const group = document.getElementById('researchGroup');
        const index = group.querySelectorAll('.research-item').length;
        const wrap = document.createElement('div');
        wrap.className = 'research-item border rounded p-2 mb-2';
        wrap.innerHTML = `
            <div class="d-flex mb-2">
                <input type="text" name="research_interests[${index}][title]" class="form-control mr-2" placeholder="Research Title">
                <input type="url" name="research_interests[${index}][url]" class="form-control" placeholder="https://example.com">
            </div>
            <textarea name="research_interests[${index}][description]" class="form-control mb-2" rows="3" placeholder="Short description (1–3 lines)"></textarea>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
            </div>
        `;
        group.appendChild(wrap);
        refreshAddButton('#researchGroup', '.research-item', 'addResearchBtn', `<button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>`);
    }

    // Research: Remove
    if (e.target && e.target.classList.contains('removeResearchBtn')) {
        const group = document.getElementById('researchGroup');
        e.target.closest('.research-item').remove();
        if (group.querySelectorAll('.research-item').length === 0) {
            const wrap = document.createElement('div');
            wrap.className = 'research-item border rounded p-2 mb-2';
            wrap.innerHTML = `
                <div class="d-flex mb-2">
                    <input type="text" name="research_interests[0][title]" class="form-control mr-2" placeholder="Research Title">
                    <input type="url" name="research_interests[0][url]" class="form-control" placeholder="https://example.com">
                </div>
                <textarea name="research_interests[0][description]" class="form-control mb-2" rows="3" placeholder="Short description (1–3 lines)"></textarea>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
                    <button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>
                </div>
            `;
            group.appendChild(wrap);
        } else {
            refreshAddButton('#researchGroup', '.research-item', 'addResearchBtn', `<button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>`);
        }
    }
});
</script>
@stop
