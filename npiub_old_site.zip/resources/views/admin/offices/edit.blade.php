{{-- resources/views/admin/offices/edit.blade.php --}}
@extends('adminlte::page')

@section('title', 'Edit Office')

@section('content_header')
    <h1>Edit Office</h1>
@stop

@section('content')
<div class="card">
    <div class="card-body">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
            </div>
        @endif

        <form action="{{ route('offices.update', $office->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Office Type -->
            <div class="form-group">
                <label for="type">Office Type</label>
                <select name="type" id="type" class="form-control" required>
                    <option value="">Select Office Type</option>
                    @foreach($officeTypes as $key => $value)
                        <option value="{{ $key }}" {{ $office->type == $key ? 'selected' : '' }}>{{ $value }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Basics -->
            <div class="form-group">
                <label for="name">Name <small class="text-muted">(e.g., Prof. John Doe)</small></label>
                <input type="text" name="name" id="name" class="form-control" value="{{ old('name', $office->name) }}" required>
            </div>

            <div class="form-group">
                <label for="position">Position <small class="text-muted">(e.g., Vice Chancellor)</small></label>
                <input type="text" name="position" id="position" class="form-control" value="{{ old('position', $office->position) }}" required>
            </div>

            <!-- ✅ Priority Field -->
            <div class="form-group">
                <label for="priority">Display Priority</label>
                <input type="number" name="priority" id="priority" class="form-control"
                       value="{{ old('priority', $office->priority ?? 1) }}" min="0" max="10">
                <small class="text-muted">
                    Lower number shows first.  
                    <strong>0 = Head of the Office</strong> (e.g., Registrar, VC, Treasurer).  
                    <br>1+ = Assistants or other members.
                </small>
            </div>

            <div class="form-group">
                <label for="contact">Contact</label>
                <input type="text" name="contact" id="contact" class="form-control" value="{{ old('contact', $office->contact) }}">
            </div>

            <div class="form-group">
                <label for="email">Email </label>
                <input type="email" name="email" id="email" class="form-control" value="{{ old('email', $office->email) }}">
            </div>

            <div class="form-group">
                <label for="biography">Biography</label>
                <textarea name="biography" id="biography" class="form-control" rows="5">{{ old('biography', $office->biography) }}</textarea>
                <small class="text-muted">Line breaks will be preserved on the public page.</small>
            </div>

            <!-- Degrees toggle -->
            <div class="form-group">
                <label>Want to add Degrees?</label><br>
                @php $hasDegrees = is_array($office->degrees) && count($office->degrees) > 0; @endphp
                <label><input type="radio" name="add_degrees" value="yes" id="add_degrees_yes" {{ $hasDegrees ? 'checked' : '' }}> Yes</label>
                <label class="ml-2"><input type="radio" name="add_degrees" value="no" id="add_degrees_no" {{ !$hasDegrees ? 'checked' : '' }}> No</label>
            </div>

            <div id="degreesSection" style="{{ $hasDegrees ? '' : 'display:none;' }}">
                <label class="d-block">Degrees</label>
                <small class="text-muted d-block mb-2">
                    Enter each degree using these three fields: <strong>Degree Name</strong>, <strong>Institution / University</strong>, <strong>Details</strong>.
                </small>

                <div id="degreeGroup">
                    @php $degrees = old('degrees', $office->degrees ?? []); @endphp
                    @forelse($degrees as $i => $deg)
                        <div class="degree-item border rounded p-2 mb-2">
                            <input type="text" name="degrees[{{ $i }}][degree_name]" class="form-control mb-2"
                                   value="{{ $deg['degree_name'] ?? '' }}" placeholder="Degree Name (e.g., Doctor of Philosophy)">
                            <input type="text" name="degrees[{{ $i }}][degree_university]" class="form-control mb-2"
                                   value="{{ $deg['degree_university'] ?? '' }}" placeholder="Institution / University">
                            <textarea name="degrees[{{ $i }}][degree_details]" class="form-control mb-2" rows="3"
                                      placeholder="Details (Department, Result, Years)">{{ $deg['degree_details'] ?? '' }}</textarea>

                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
                                @if ($i === 0)
                                    <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>
                                @endif
                            </div>
                        </div>
                    @empty
                        <div class="degree-item border rounded p-2 mb-2">
                            <input type="text" name="degrees[0][degree_name]" class="form-control mb-2" placeholder="Degree Name">
                            <input type="text" name="degrees[0][degree_university]" class="form-control mb-2" placeholder="Institution / University">
                            <textarea name="degrees[0][degree_details]" class="form-control mb-2" rows="3" placeholder="Details (Result, Department, Years)"></textarea>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
                                <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>
                            </div>
                        </div>
                    @endforelse
                </div>
            </div>

            <!-- Research toggle -->
            <div class="form-group mt-3">
                <label>Want to add Research?</label><br>
                @php $hasResearch = is_array($office->research_interests) && count($office->research_interests) > 0; @endphp
                <label><input type="radio" name="add_research" value="yes" id="add_research_yes" {{ $hasResearch ? 'checked' : '' }}> Yes</label>
                <label class="ml-2"><input type="radio" name="add_research" value="no" id="add_research_no" {{ !$hasResearch ? 'checked' : '' }}> No</label>
            </div>

            <div id="researchSection" style="{{ $hasResearch ? '' : 'display:none;' }}">
                <label class="d-block">Research</label>
                <small class="text-muted d-block mb-2">
                    Each item has a <strong>Title</strong>, a <strong>URL</strong>, and a short <strong>Description</strong>.
                </small>

                <div id="researchGroup">
                    @php $research = old('research_interests', $office->research_interests ?? []); @endphp
                    @forelse($research as $i => $r)
                        <div class="research-item border rounded p-2 mb-2">
                            <div class="d-flex mb-2">
                                <input type="text" name="research_interests[{{ $i }}][title]" class="form-control mr-2"
                                       value="{{ $r['title'] ?? '' }}" placeholder="Research Title">
                                <input type="url" name="research_interests[{{ $i }}][url]" class="form-control"
                                       value="{{ $r['url'] ?? '' }}" placeholder="https://example.com">
                            </div>
                            <textarea name="research_interests[{{ $i }}][description]" class="form-control mb-2" rows="3"
                                      placeholder="Short description (1–3 lines)">{{ $r['description'] ?? '' }}</textarea>

                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
                                @if ($i === 0)
                                    <button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>
                                @endif
                            </div>
                        </div>
                    @empty
                        <div class="research-item border rounded p-2 mb-2">
                            <div class="d-flex mb-2">
                                <input type="text" name="research_interests[0][title]" class="form-control mr-2" placeholder="Research Title">
                                <input type="url" name="research_interests[0][url]" class="form-control" placeholder="https://example.com">
                            </div>
                            <textarea name="research_interests[0][description]" class="form-control mb-2" rows="3" placeholder="Short description (1–3 lines)"></textarea>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
                                <button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>
                            </div>
                        </div>
                    @endforelse
                </div>
            </div>

            <!-- Social -->
            <div class="form-group">
                <label for="facebook">Facebook</label>
                <input type="url" name="facebook" id="facebook" class="form-control" value="{{ old('facebook', $office->facebook) }}">
            </div>
            <div class="form-group">
                <label for="linkedin">LinkedIn</label>
                <input type="url" name="linkedin" id="linkedin" class="form-control" value="{{ old('linkedin', $office->linkedin) }}">
            </div>
            <div class="form-group">
                <label for="whatsapp">WhatsApp</label>
                <input type="text" name="whatsapp" id="whatsapp" class="form-control" value="{{ old('whatsapp', $office->whatsapp) }}">
            </div>

            <!-- Image -->
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" name="image" id="image" class="form-control-file">
                @if ($office->image)
                    <img src="{{ asset('storage/' . $office->image) }}" alt="{{ $office->name }}" class="img-thumbnail mt-2" style="width: 150px;">
                @endif
                <small class="form-text text-muted">Leave blank to keep current image.</small>
            </div>

            <button type="submit" class="btn btn-success">Update Office</button>
        </form>
    </div>
</div>
@stop

@section('js')
<script>
// === Toggle Sections
document.getElementById('add_degrees_yes').addEventListener('click', () => {
    document.getElementById('degreesSection').style.display = 'block';
});
document.getElementById('add_degrees_no').addEventListener('click', () => {
    document.getElementById('degreesSection').style.display = 'none';
});
document.getElementById('add_research_yes').addEventListener('click', () => {
    document.getElementById('researchSection').style.display = 'block';
});
document.getElementById('add_research_no').addEventListener('click', () => {
    document.getElementById('researchSection').style.display = 'none';
});

// === Dynamic Add/Remove ===
function refreshAddButton(groupSelector, itemClass, btnId, makeBtnHtml) {
    const group = document.querySelector(groupSelector);
    if (!group) return;
    const items = group.querySelectorAll(itemClass);
    items.forEach((item, idx) => {
        const existing = item.querySelector('#' + btnId);
        if (idx === 0) {
            if (!existing) {
                const el = document.createElement('div');
                el.innerHTML = makeBtnHtml;
                item.querySelector('.d-flex.gap-2, .d-flex').appendChild(el.firstElementChild);
            }
        } else {
            if (existing) existing.remove();
        }
    });
}

document.addEventListener('click', function(e) {
    // Add/Remove Degrees
    if (e.target && e.target.id === 'addDegreeBtn') {
        const group = document.getElementById('degreeGroup');
        const index = group.querySelectorAll('.degree-item').length;
        const wrap = document.createElement('div');
        wrap.className = 'degree-item border rounded p-2 mb-2';
        wrap.innerHTML = `
            <input type="text" name="degrees[${index}][degree_name]" class="form-control mb-2" placeholder="Degree Name">
            <input type="text" name="degrees[${index}][degree_university]" class="form-control mb-2" placeholder="Institution / University">
            <textarea name="degrees[${index}][degree_details]" class="form-control mb-2" rows="3" placeholder="Details (Department, Result, Years)"></textarea>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
            </div>
        `;
        group.appendChild(wrap);
        refreshAddButton('#degreeGroup', '.degree-item', 'addDegreeBtn', `<button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>`);
    }

    if (e.target && e.target.classList.contains('removeDegreeBtn')) {
        const group = document.getElementById('degreeGroup');
        e.target.closest('.degree-item').remove();
        if (group.querySelectorAll('.degree-item').length === 0) {
            const wrap = document.createElement('div');
            wrap.className = 'degree-item border rounded p-2 mb-2';
            wrap.innerHTML = `
                <input type="text" name="degrees[0][degree_name]" class="form-control mb-2" placeholder="Degree Name">
                <input type="text" name="degrees[0][degree_university]" class="form-control mb-2" placeholder="Institution / University">
                <textarea name="degrees[0][degree_details]" class="form-control mb-2" rows="3" placeholder="Details (Department, Result, Years)"></textarea>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-danger removeDegreeBtn">Remove</button>
                    <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>
                </div>
            `;
            group.appendChild(wrap);
        } else {
            refreshAddButton('#degreeGroup', '.degree-item', 'addDegreeBtn', `<button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>`);
        }
    }

    // Add/Remove Research
    if (e.target && e.target.id === 'addResearchBtn') {
        const group = document.getElementById('researchGroup');
        const index = group.querySelectorAll('.research-item').length;
        const wrap = document.createElement('div');
        wrap.className = 'research-item border rounded p-2 mb-2';
        wrap.innerHTML = `
            <div class="d-flex mb-2">
                <input type="text" name="research_interests[${index}][title]" class="form-control mr-2" placeholder="Research Title">
                <input type="url" name="research_interests[${index}][url]" class="form-control" placeholder="https://example.com">
            </div>
            <textarea name="research_interests[${index}][description]" class="form-control mb-2" rows="3" placeholder="Short description (1–3 lines)"></textarea>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
            </div>
        `;
        group.appendChild(wrap);
        refreshAddButton('#researchGroup', '.research-item', 'addResearchBtn', `<button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>`);
    }

    if (e.target && e.target.classList.contains('removeResearchBtn')) {
        const group = document.getElementById('researchGroup');
        e.target.closest('.research-item').remove();
        if (group.querySelectorAll('.research-item').length === 0) {
            const wrap = document.createElement('div');
            wrap.className = 'research-item border rounded p-2 mb-2';
            wrap.innerHTML = `
                <div class="d-flex mb-2">
                    <input type="text" name="research_interests[0][title]" class="form-control mr-2" placeholder="Research Title">
                    <input type="url" name="research_interests[0][url]" class="form-control" placeholder="https://example.com">
                </div>
                <textarea name="research_interests[0][description]" class="form-control mb-2" rows="3" placeholder="Short description (1–3 lines)"></textarea>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-danger removeResearchBtn">Remove</button>
                    <button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>
                </div>
            `;
            group.appendChild(wrap);
        } else {
            refreshAddButton('#researchGroup', '.research-item', 'addResearchBtn', `<button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add More</button>`);
        }
    }
});
</script>
@stop
