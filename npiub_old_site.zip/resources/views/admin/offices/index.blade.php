@extends('adminlte::page')

@section('title', 'Offices')

@section('content_header')
    <h1>Offices</h1>
@stop

@section('content')

@if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <div class="card">
        <div class="card-header">
            <a href="{{ route('offices.create') }}" class="btn btn-primary">Add Office</a>
        </div>
        <div class="card-body">
            <table id="officesTable" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Office Type</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($offices as $office)
                        <tr>
                            <td>{{ $office->type }}</td>
                            <td>{{ $office->name }}</td>
                            <td>{{ $office->contact }}</td>
                            <td>{{ $office->email }}</td>
                            <td>
                                <!-- <a href="{{ route('offices.show', $office->id) }}" class="btn btn-info btn-sm">View</a> -->
                                <a href="{{ route('offices.edit', $office->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                <form action="{{ route('offices.destroy', $office->id) }}" method="POST" style="display:inline-block;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this office?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@stop

@section('js')
<script>
    $(document).ready(function() {
        $('#officesTable').DataTable();
    });
</script>
@stop
