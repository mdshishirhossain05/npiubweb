@extends('adminlte::page')

@section('title', 'Edit Officer')

@section('content_header')
    <h1>Edit Officer</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">

            <!-- Display Validation Errors -->
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('officers.update', $officer->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- Department Dropdown -->
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" class="form-control" required>
                        <option value="">Select Department</option>
                        @foreach($departments as $short => $full)
                            <option value="{{ $short }}" {{ $officer->department == $short ? 'selected' : '' }}>
                                {{ $full }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" value="{{ old('name', $officer->name) }}" required>
                </div>

                <div class="form-group">
                    <label for="position">Position</label>
                    <input type="text" name="position" class="form-control" value="{{ old('position', $officer->position) }}" required>
                </div>

                <div class="form-group">
                    <label for="contact">Contact</label>
                    <input type="text" name="contact" class="form-control" value="{{ old('contact', $officer->contact) }}" required>
                </div>

                <!-- Degrees Section -->
                <div class="form-group">
                    <label>Degrees</label>
                    <div id="degreeGroup">
                        @php
                            $degrees = old('degrees', $officer->degrees);
                            $degrees = is_array($degrees) ? $degrees : json_decode($degrees, true);
                        @endphp

                        @if($degrees && count($degrees) > 0)
                            @foreach($degrees as $index => $degree)
                                <div class="degree-item d-flex mt-2">
                                    <input type="text" name="degrees[{{ $index }}][degree_name]" class="form-control mr-2" value="{{ $degree['degree_name'] }}" placeholder="Degree Name" required>
                                    <input type="text" name="degrees[{{ $index }}][degree_university]" class="form-control" value="{{ $degree['degree_university'] }}" placeholder="University" required>
                                    <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
                                </div>
                            @endforeach
                        @else
                            <div class="degree-item d-flex mt-2">
                                <input type="text" name="degrees[0][degree_name]" class="form-control mr-2" placeholder="Degree Name" required>
                                <input type="text" name="degrees[0][degree_university]" class="form-control" placeholder="University" required>
                                <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
                            </div>
                        @endif
                    </div>

                    <button type="button" class="btn btn-success mt-2" id="addDegreeBtn">Add More</button>
                </div>

                <div class="form-group">
                    <label for="biography">Biography</label>
                    <textarea name="biography" class="form-control" rows="5">{{ old('biography', $officer->biography) }}</textarea>
                </div>

                <div class="form-group">
                    <label for="facebook">Facebook</label>
                    <input type="url" name="facebook" class="form-control" value="{{ old('facebook', $officer->facebook) }}">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email', $officer->email) }}" required>
                </div>

                <div class="form-group">
                    <label for="linkedin">LinkedIn</label>
                    <input type="url" name="linkedin" class="form-control" value="{{ old('linkedin', $officer->linkedin) }}">
                </div>

                <div class="form-group">
                    <label for="whatsapp">WhatsApp</label>
                    <input type="text" name="whatsapp" class="form-control" value="{{ old('whatsapp', $officer->whatsapp) }}">
                </div>

                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" class="form-control-file">
                    @if ($officer->image)
                        <img src="{{ asset('storage/' . $officer->image) }}" alt="{{ $officer->name }}" class="img-thumbnail mt-2" style="width: 150px;">
                    @endif
                </div>

                <button type="submit" class="btn btn-primary">Update Officer</button>
            </form>
        </div>
    </div>
@stop

@section('js')
<script>
    document.getElementById('addDegreeBtn').addEventListener('click', function() {
        let degreeGroup = document.getElementById('degreeGroup');
        let index = degreeGroup.querySelectorAll('.degree-item').length;
        let newDegreeItem = document.createElement('div');
        newDegreeItem.className = 'degree-item d-flex mt-2';
        newDegreeItem.innerHTML = `
            <input type="text" name="degrees[${index}][degree_name]" class="form-control mr-2" placeholder="Degree Name" required>
            <input type="text" name="degrees[${index}][degree_university]" class="form-control" placeholder="University" required>
            <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
        `;
        degreeGroup.appendChild(newDegreeItem);

        newDegreeItem.querySelector('.removeDegreeBtn').addEventListener('click', function() {
            degreeGroup.removeChild(newDegreeItem);
        });
    });

    // JavaScript for removing degrees if needed
    document.querySelectorAll('.removeDegreeBtn').forEach(function(button) {
        button.addEventListener('click', function() {
            let degreeGroup = document.getElementById('degreeGroup');
            degreeGroup.removeChild(this.closest('.degree-item'));
        });
    });
</script>
@stop
