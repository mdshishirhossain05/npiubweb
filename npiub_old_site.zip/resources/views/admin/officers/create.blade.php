@extends('adminlte::page')

@section('title', 'Add Officer')

@section('content_header')
    <h1>Add Officer</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">

            <!-- Display Validation Errors -->
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('officers.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <!-- Department Dropdown -->
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" class="form-control" required>
                        <option value="">Select Department</option>
                        @foreach($departments as $short => $full)
                            <option value="{{ $short }}">
                                {{ $full }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- Name -->
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
                </div>

                <!-- Position -->
                <div class="form-group">
                    <label for="position">Position</label>
                    <input type="text" name="position" class="form-control" value="{{ old('position') }}" required>
                </div>

                <!-- Contact -->
                <div class="form-group">
                    <label for="contact">Contact</label>
                    <input type="text" name="contact" class="form-control" value="{{ old('contact') }}" required>
                </div>

                <!-- Degrees Section -->
                <div class="form-group">
                    <label>Degrees</label>
                    <div id="degreeGroup">
                        <div class="degree-item d-flex">
                            <input type="text" name="degrees[0][degree_name]" class="form-control mr-2" placeholder="Degree Name" required>
                            <input type="text" name="degrees[0][degree_university]" class="form-control" placeholder="University, Year" required>
                            <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add More</button>
                        </div>
                    </div>
                </div>

                <!-- Biography -->
                <div class="form-group">
                    <label for="biography">Biography</label>
                    <textarea name="biography" class="form-control" rows="5">{{ old('biography') }}</textarea>
                </div>

                <!-- Social Links -->
                <div class="form-group">
                    <label for="facebook">Facebook</label>
                    <input type="url" name="facebook" class="form-control" value="{{ old('facebook') }}">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
                </div>

                <div class="form-group">
                    <label for="linkedin">LinkedIn</label>
                    <input type="url" name="linkedin" class="form-control" value="{{ old('linkedin') }}">
                </div>

                <div class="form-group">
                    <label for="whatsapp">WhatsApp</label>
                    <input type="text" name="whatsapp" class="form-control" value="{{ old('whatsapp') }}">
                </div>

                <!-- Image -->
                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" class="form-control-file">
                </div>

                <button type="submit" class="btn btn-success">Add Officer</button>
            </form>
        </div>
    </div>
@stop

@section('js')
<script>
    document.getElementById('addDegreeBtn').addEventListener('click', function() {
        let degreeGroup = document.getElementById('degreeGroup');
        let index = degreeGroup.querySelectorAll('.degree-item').length;
        let newDegreeItem = document.createElement('div');
        newDegreeItem.className = 'degree-item d-flex mt-2';
        newDegreeItem.innerHTML = `
            <input type="text" name="degrees[${index}][degree_name]" class="form-control mr-2" placeholder="Degree Name" required>
            <input type="text" name="degrees[${index}][degree_university]" class="form-control" placeholder="University" required>
            <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
        `;
        degreeGroup.appendChild(newDegreeItem);

        // Add event listener to the remove button
        newDegreeItem.querySelector('.removeDegreeBtn').addEventListener('click', function() {
            degreeGroup.removeChild(newDegreeItem);
        });
    });
</script>
@stop
