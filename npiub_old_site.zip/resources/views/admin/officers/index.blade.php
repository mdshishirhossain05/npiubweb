@extends('adminlte::page')

@section('title', 'Officers')

@section('content_header')
    <h1>Officers</h1>
@stop

@section('content')

@if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <div class="card">
        <div class="card-header">
            <a href="{{ route('officers.create') }}" class="btn btn-primary">Add Officer</a>
        </div>
        <div class="card-body">
            <table id="officersTable" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Contact</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($officers as $officer)
                        <tr>
                            <td>{{ $officer->department }}</td>
                            <td>{{ $officer->name }}</td>
                            <td>{{ $officer->position }}</td>
                            <td>{{ $officer->contact }}</td>
                            <td>
                                <!-- <a href="{{ route('officers.show', $officer->id) }}" class="btn btn-info btn-sm">View</a> -->
                                <a href="{{ route('officers.edit', $officer->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                <form action="{{ route('officers.destroy', $officer->id) }}" method="POST" style="display:inline-block;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this officer?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@stop

@section('js')
<script>
    $(document).ready(function() {
        $('#officersTable').DataTable();
    });
</script>
@stop
