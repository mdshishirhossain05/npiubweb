@extends('adminlte::page')

@section('title', 'Add Alumni')

@section('content_header')
    <h1>Create New Alumni</h1>
@stop

@section('content')
    <div class="box">
        <!-- <div class="box-header with-border">
            <h3 class="box-title">Create New Alumni</h3>
        </div> -->

        <!-- Display Validation Errors -->
        @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        <div class="box-body">
            <form action="{{ route('alumni.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" required>
                </div>

                <div class="form-group">
                    <label for="department">Department</label>
                    <select class="form-control" id="department" name="department" required>
                        <option value="cse">Computer Science and Engineering (CSE)</option>
                        <option value="eee">Electrical and Electronics Engineering (EEE)</option>
                        <option value="food-eng">Food Engineering</option>
                        <option value="bba">Bachelor of Business Administration (BBA)</option>
                        <option value="mba">Master of Business Administration (MBA)</option>
                        <option value="english">B.A in English</option>
                        <!-- Add more departments as needed -->
                    </select>
                </div>

                <div class="form-group">
                    <label for="batch">Batch</label>
                    <input type="text" class="form-control" id="batch" name="batch" placeholder="Enter batch" required>
                </div>

                <div class="form-group">
                    <label for="graduation_year">Graduation Year</label>
                    <input type="number" class="form-control" id="graduation_year" name="graduation_year" placeholder="Enter graduation year" required>
                </div>

                <div class="form-group">
                    <label for="current_position">Current Position</label>
                    <input type="text" class="form-control" id="current_position" name="current_position" placeholder="Enter current position">
                </div>

                <div class="form-group">
                    <label for="bio">Bio</label>
                    <textarea class="form-control" id="bio" name="bio" rows="3" placeholder="Enter bio"></textarea>
                </div>

                <div class="form-group">
                    <label for="facebook">Facebook</label>
                    <input type="url" class="form-control" id="facebook" name="facebook" placeholder="https://facebook.com/username">
                </div>

                <div class="form-group">
                    <label for="linkedin">LinkedIn</label>
                    <input type="url" class="form-control" id="linkedin" name="linkedin" placeholder="https://linkedin.com/in/username">
                </div>

                <div class="form-group">
                    <label for="whatsapp">WhatsApp</label>
                    <input type="text" class="form-control" id="whatsapp" name="whatsapp" placeholder="+123456789">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter email address">
                </div>

                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" class="form-control-file" id="image" name="image">
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
@stop
