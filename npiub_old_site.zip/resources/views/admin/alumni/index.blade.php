@extends('adminlte::page')

@section('title', 'Alumni Management')

@section('content_header')
    <h1>Alumni Management</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">List of Alumni</h3>
            <div class="card-tools">
                <a href="{{ route('alumni.create') }}" class="btn btn-primary">Add New Alumni</a>
            </div>
        </div>
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
        <div class="card-body">
            <table id="alumniTable" class="table table-striped table-bordered table-hover ">
                <thead>
                    <tr>
                        <!-- <th>ID</th> -->
                        <th>Name</th>
                        <th>Department</th>
                        <th>Batch</th>
                        <th>Graduation Year</th>
                        <th>Current Position</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($alumni as $alumnus)
                        <tr>
                            <!-- <td>{{ $alumnus->id }}</td> -->
                            <td>{{ $alumnus->name }}</td>
                            <td>{{ $alumnus->department }}</td>
                            <td>{{ $alumnus->batch }}</td>
                            <td>{{ $alumnus->graduation_year }}</td>
                            <td>{{ $alumnus->current_position }}</td>
                            <td>
                              <a href="{{ route('alumni.show', $alumnus->slug) }}" class="btn btn-info btn-sm">View</a>
                                <a href="{{ route('alumni.edit', $alumnus->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                <form action="{{ route('alumni.destroy', $alumnus->id) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <!-- Pagination Links -->
        <div class="container">
            {{ $alumni->links('pagination::bootstrap-5') }}
        </div>
    </div>
@stop

@section('js')
    <script>
        $(function () {
            $('#alumniTable').DataTable();
        });
    </script>
@stop

@section('css')
    <style>
        .table thead th {
            vertical-align: top !important;
        }
    </style>
@stop


