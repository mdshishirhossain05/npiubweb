@extends('adminlte::page')

@section('title', 'Edit Alumni')

@section('content_header')
    <h1>Edit Alumni</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Alumni</h3>
        </div>
        <!-- Display Validation Errors -->
        @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        <div class="card-body">
            <form action="{{ route('alumni.update', $alumnus->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="{{ old('name', $alumnus->name) }}" required>
                </div>

                <div class="form-group">
                    <label for="department">Department</label>
                    <select class="form-control" id="department" name="department" required>
                        
                        <option value="cse" {{ $alumnus->department == 'cse' ? 'selected' : '' }}>Computer Science and Engineering (CSE)</option>
                        <option value="eee" {{ $alumnus->department == 'eee' ? 'selected' : '' }}>Electrical and Electronics Engineering (EEE)</option>
                        <option value="food-eng" {{ $alumnus->department == 'food-eng' ? 'selected' : '' }}>Food Engineering</option>
                        <option value="bba" {{ $alumnus->department == 'bba' ? 'selected' : '' }}>Bachelor of Business Administration (BBA)</option>
                        <option value="mba" {{ $alumnus->department == 'mba' ? 'selected' : '' }}>Master of Business Administration (MBA)</option>
                        <option value="english" {{ $alumnus->department == 'english' ? 'selected' : '' }}>B.A in English</option>
                        <!-- Add more departments as needed -->
                    </select>
                </div>

                <!-- <div class="form-group">
                    <label for="department">Department</label>
                    <input type="text" class="form-control" id="department" name="department" value="{{ old('department', $alumnus->department) }}" required>
                </div> -->

                <div class="form-group">
                    <label for="batch">Batch</label>
                    <input type="text" class="form-control" id="batch" name="batch" value="{{ old('batch', $alumnus->batch) }}" required>
                </div>

                <div class="form-group">
                    <label for="graduation_year">Graduation Year</label>
                    <input type="number" class="form-control" id="graduation_year" name="graduation_year" value="{{ old('graduation_year', $alumnus->graduation_year) }}" required>
                </div>

                <div class="form-group">
                    <label for="current_position">Current Position</label>
                    <input type="text" class="form-control" id="current_position" name="current_position" value="{{ old('current_position', $alumnus->current_position) }}">
                </div>

                <div class="form-group">
                    <label for="bio">Bio</label>
                    <textarea class="form-control" id="bio" name="bio">{{ old('bio', $alumnus->bio) }}</textarea>
                </div>

                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" class="form-control" id="image" name="image">
                    @if ($alumnus->image)
                        <img src="{{ asset('storage/' . $alumnus->image) }}" alt="Alumni Image" width="100">
                    @endif
                </div>

                <div class="form-group">
                    <label for="facebook">Facebook</label>
                    <input type="text" class="form-control" id="facebook" name="facebook" value="{{ old('facebook', $alumnus->facebook) }}">
                </div>

                <div class="form-group">
                    <label for="linkedin">LinkedIn</label>
                    <input type="text" class="form-control" id="linkedin" name="linkedin" value="{{ old('linkedin', $alumnus->linkedin) }}">
                </div>

                <div class="form-group">
                    <label for="whatsapp">WhatsApp</label>
                    <input type="text" class="form-control" id="whatsapp" name="whatsapp" value="{{ old('whatsapp', $alumnus->whatsapp) }}">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email', $alumnus->email) }}">
                </div>

                <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure?')">Update Alumni</button>
            </form>
        </div>
    </div>
@stop
