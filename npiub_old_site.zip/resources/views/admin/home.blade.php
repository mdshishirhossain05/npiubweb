@extends('adminlte::page')

@section('title', 'Dashboard')


@php
    $unreadCount = \App\Models\ContactMessage::whereNull('read_at')->count();
@endphp

@section('content_header')
    <h1>Dashboard</h1>
    <div>
        Unread Messages: <span class="badge badge-warning">{{ $unreadCount }}</span>
    </div>
@endsection

@section('content')
    <p>Welcome to your dashboard!</p>

    
    <!-- Other content -->
@endsection
