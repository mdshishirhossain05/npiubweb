@extends('adminlte::page')

@section('title', 'Edit Research')

@section('content_header')
    <h1>Edit Research</h1>
@stop

@section('content')
 <!-- Display Validation Errors -->
 @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
    <form action="{{ route('research.update', $research->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="title" value="{{ $research->title }}" required>
        </div>
        <div class="form-group">
            <label for="content">Content</label>
            <textarea class="form-control" id="content" name="content" rows="5" required>{{ $research->content }}</textarea>
        </div>
        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control" id="image" name="image">
            @if ($research->image)
                <img src="{{ asset('storage/' . $research->image) }}" alt="Current Image" class="img-thumbnail mt-2" width="150">
            @endif
        </div>
        <div class="form-group">
            <label for="author_name">Author Name</label>
            <input type="text" class="form-control" id="author_name" name="author_name" value="{{ $research->author_name }}" required>
        </div>
        <div class="form-group">
            <label for="author_image">Author Image</label>
            <input type="file" class="form-control" id="author_image" name="author_image">
            @if ($research->author_image)
                <img src="{{ asset('storage/' . $research->author_image) }}" alt="Current Author Image" class="img-thumbnail mt-2" width="150">
            @endif
        </div>
        <div class="form-group">
            <label for="author_info">Author Info</label>
            <textarea class="form-control" id="author_info" name="author_info" rows="3" required>{{ $research->author_info }}</textarea>
        </div>
        <div class="form-group">
            <label for="published_at">Published Date</label>
            <input type="date" class="form-control" id="published_at" name="published_at" value="{{ $research->published_at->format('Y-m-d') }}" required>
        </div>
        <div class="form-group">
            <label for="category">Category</label>
            <select class="form-control" id="category" name="category" required>
                <option value="all" {{ $research->category == 'all' ? 'selected' : '' }}>All Departments</option>
                <option value="cse" {{ $research->category == 'cse' ? 'selected' : '' }}>Computer Science and Engineering (CSE)</option>
                <option value="eee" {{ $research->category == 'eee' ? 'selected' : '' }}>Electrical and Electronics Engineering (EEE)</option>
                <option value="food-eng" {{ $research->category == 'food-eng' ? 'selected' : '' }}>Food Engineering</option>
                <option value="bba" {{ $research->category == 'bba' ? 'selected' : '' }}>Bachelor of Business Administration (BBA)</option>
                <option value="mba" {{ $research->category == 'mba' ? 'selected' : '' }}>Master of Business Administration (MBA)</option>
                <option value="english" {{ $research->category == 'english' ? 'selected' : '' }}>B.A in English</option>
                <!-- Add more categories as needed -->
            </select>
        </div>
        <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure?')">Update</button>
    </form>
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
@stop
