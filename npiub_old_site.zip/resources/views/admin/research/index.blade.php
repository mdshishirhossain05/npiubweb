@extends('adminlte::page')

@section('title', 'Research Management')

@section('content_header')
    <h1>Research Management</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">List of Research</h3>
            <div class="card-tools">
                <a href="{{ route('research.create') }}" class="btn btn-primary mb-3">Add New Research</a>   
            </div>
        </div>
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
        <div class="card-body">
        <table class="table table-bordered table-striped table-hover">
        <thead>
            <tr>
                <th>Title</th>
                <th>Author</th>
                <th>Department</th>
                <th>Published Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($research as $item)
                <tr>
                    <td>{{ $item->title }}</td>
                    <td>{{ $item->author_name }}</td>
                    <td>{{ $item->category }}</td>
                    <td>{{ $item->published_at->format('F j, Y') }}</td>
                    <td>
                        <a href="{{ route('research.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('research.destroy', $item->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
        </div>
        <!-- Pagination Links -->
        <div class="container">
            {{ $research->links('pagination::bootstrap-5') }}
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
@stop





