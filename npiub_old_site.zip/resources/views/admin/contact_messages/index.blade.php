@extends('adminlte::page')

@section('title', 'Contact Messages')

@php
    // Count unread messages
    $unreadCount = \App\Models\ContactMessage::whereNull('read_at')->count();
@endphp

@section('content_header')
    <h1>Contact Messages</h1>

    <div>
        Unread Messages: <span class="badge badge-warning">{{ $unreadCount }}</span>
    </div>
    
@endsection

@section('content')
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <div class="row">
    <div class="col-md-12">
    <form action="{{ route('contact-messages.index') }}" method="GET" class="d-flex">
            <input type="text" name="search" class="form-control search-input" placeholder="Search by name or email or message..." value="{{ request('search') }}">
            <button type="submit" class="btn btn-primary search-button">Search</button>
        </form>
    </div>
</div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">All Messages</h3>
        </div>
        <div class="card-body">
            
        <table class="table table-striped table-hover table-bordered"
                    data-toggle="table"
                    data-show-toggle="true"
                    data-show-columns="true"

                >
                <thead>
                    <tr>
                        <th>Name</th>
                        <th data-visible="false">Email</th>
                        <th data-visible="false">Phone</th>
                        <th>Message</th>
                        <th>Received At</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($messages as $message)
                        <tr>
                            <td>{{ $message->name }}</td>
                            <td>{{ $message->email }}</td>
                            <td>{{ $message->phone }}</td>
                            <td>{{ Str::limit($message->message, 50) }}</td>
                            <td>{{ $message->created_at->format('d M Y, H:i') }}</td>
                            <td>
                                @if($message->read_at)
                                    <span class="badge badge-success">Read</span>
                                @else
                                    <span class="badge badge-warning">Unread</span>
                                @endif
                            </td>
                            <td>
                                <a href="{{ route('contact-messages.show', $message->id) }}" class="btn btn-info btn-sm">View</a>
                                <form action="{{ route('contact-messages.destroy', $message->id) }}" method="POST" style="display:inline-block;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this message?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <!-- Pagination Links -->
        <div class="container">
            {{ $messages->appends(['search' => request()->query('search')])->links('pagination::bootstrap-5') }}
        </div>

    </div>
@endsection


@section('js')
    <!-- Include Bootstrap Table CSS/JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-table/dist/bootstrap-table.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-table/dist/bootstrap-table.min.js"></script>
@endsection

<style>

        .search-button{
            margin-left: .5rem !important;
        }
    
    
</style>