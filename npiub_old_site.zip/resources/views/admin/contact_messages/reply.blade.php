<!-- resources/views/admin/contact_messages/reply.blade.php -->
@extends('adminlte::page')

@section('content')
<div class="container">
    <h1>Reply to Message</h1>
    <form action="{{ route('contact_messages.show', $message->id) }}" method="POST">
        @csrf
        <div class="form-group">
            <textarea name="reply" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send Reply</button>
    </form>


@endsection
