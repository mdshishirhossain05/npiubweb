@extends('adminlte::page')

@section('title', 'View Message')

@section('content_header')
    <h1>View Message</h1>
@stop



@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">{{ $message->subject }}</h3>
        </div>
        <div class="card-body">
            <p><strong>Name:</strong> {{ $message->name }}</p>
            <p><strong>Email:</strong> {{ $message->email }}</p>
            <p><strong>Phone:</strong> {{ $message->phone }}</p>
            <p><strong>Message:</strong> {{ $message->message }}</p>
        </div>
    </div>

    @if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

@if (session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
@endif

<div class="card mt-3">
    <div class="card-header">
        <h3 class="card-title">Reply to Message</h3>
    </div>
    <div class="card-body">
        <form action="{{ route('contact-messages.reply', $message->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="reply_message">Your Reply</label>
                <textarea name="reply_message" id="reply_message" class="form-control" rows="5" required></textarea>
            </div>
            <div class="form-group">
                <label for="attachment">Attachment (optional)</label>
                <input type="file" name="attachment" class="form-control" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.xlsx,.txt">
            </div>
            <button type="submit" class="btn btn-primary">Send Reply</button>
        </form>
    </div>
</div>

@stop
