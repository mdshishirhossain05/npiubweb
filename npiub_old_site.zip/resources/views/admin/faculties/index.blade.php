
@extends('adminlte::page')

@section('title', 'Faculties Management')

@section('content_header')
    <h1>Faculties Management</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">List of Faculties</h3>
            <div class="card-tools">
                <a href="{{ route('faculties.create') }}" class="btn btn-primary">Add New Faculties</a>
            </div>
        </div>
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
        <div class="card-body">
        <table id="facultiesTable" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <!-- <th>ID</th> -->
                        <th>Department</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Contact</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($faculties as $faculty)
                        <tr>
                            <!-- <td>{{ $faculty->id }}</td> -->
                            <td>{{ ($faculty->department) }}</td>
                            <td>{{ $faculty->name }}</td>
                            <td>{{ $faculty->position }}</td>
                            <td>{{ $faculty->contact }}</td>
                            <td>
                                <!--<a href="{{ route('faculties.show', $faculty->id) }}" class="btn btn-info btn-sm">View</a>-->
                                <a href="{{ route('faculties.edit', $faculty->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                <form action="{{ route('faculties.destroy', $faculty->id) }}" method="POST" style="display:inline-block;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this faculty?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <!-- Pagination Links -->
        <div class="container">
            {{ $faculties->links('pagination::bootstrap-5') }}
        </div>
    </div>
@stop

@section('js')
<script>
    $(document).ready(function() {
        $('#facultiesTable').DataTable();
    });
</script>
@stop

@section('css')
    <style>
        .table thead th {
            vertical-align: top !important;
        }
    </style>
@stop



