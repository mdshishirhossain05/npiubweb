@extends('adminlte::page')

@section('title', 'Add Faculty')

@section('content_header')
    <h1>Add Faculty</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">

            {{-- Validation Errors --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('faculties.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                {{-- Department --}}
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" class="form-control" required>
                        <option value="">Select Department</option>
                        @foreach($departments as $short => $full)
                            <option value="{{ $short }}">{{ $full }}</option>
                        @endforeach
                    </select>
                </div>

                {{-- Name --}}
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" required value="{{ old('name') }}">
                </div>

                {{-- Position --}}
                <div class="form-group">
                    <label>Position</label>
                    <input type="text" name="position" class="form-control" required value="{{ old('position') }}">
                </div>

                {{-- Contact --}}
                <div class="form-group">
                    <label>Contact</label>
                    <input type="text" name="contact" class="form-control" required value="{{ old('contact') }}">
                </div>


                {{-- PRIORITY --}}
                <div class="form-group">
                    <label>Priority (0 = Highest)</label>
                    <input type="number" name="priority" class="form-control" min="0" max="10"
                           value="{{ old('priority', 1) }}">
                </div>


                {{-- Degrees --}}
                <div class="form-group">
                    <label>Degrees</label>

                    <div id="degreeGroup">
                        <div class="degree-item d-flex mb-2">
                            <input type="text" name="degrees[0][degree_name]" class="form-control mr-2"
                                   placeholder="Degree Name (e.g., B.Sc in CSE)">
                            <input type="text" name="degrees[0][degree_university]" class="form-control mr-2"
                                   placeholder="University (e.g., DUET)">
                            <input type="text" name="degrees[0][degree_details]" class="form-control"
                                   placeholder="Details (optional)">
                            <button type="button" class="btn btn-success ml-2" id="addDegreeBtn">Add</button>
                        </div>
                    </div>
                </div>


                {{-- Research Interests --}}
                <div class="form-group">
                    <label>Research Interests</label>

                    <div id="researchGroup">
                        <div class="research-item d-flex mb-2">
                            <input type="text" name="research_interests[0][title]" class="form-control mr-2"
                                   placeholder="Research Title (e.g., Machine Learning)">
                            <input type="url" name="research_interests[0][url]" class="form-control mr-2"
                                   placeholder="Research URL (optional)">
                            <input type="text" name="research_interests[0][description]" class="form-control"
                                   placeholder="Description (optional)">
                            <button type="button" class="btn btn-success ml-2" id="addResearchBtn">Add</button>
                        </div>
                    </div>
                </div>


                {{-- Biography --}}
                <div class="form-group">
                    <label>Biography</label>
                    <textarea name="biography" class="form-control" rows="5" required>{{ old('biography') }}</textarea>
                </div>

                {{-- Facebook --}}
                <div class="form-group">
                    <label>Facebook</label>
                    <input type="url" name="facebook" class="form-control" value="{{ old('facebook') }}">
                </div>

                {{-- Email --}}
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" required value="{{ old('email') }}">
                </div>

                {{-- LinkedIn --}}
                <div class="form-group">
                    <label>LinkedIn</label>
                    <input type="url" name="linkedin" class="form-control" value="{{ old('linkedin') }}">
                </div>

                {{-- WhatsApp --}}
                <div class="form-group">
                    <label>WhatsApp</label>
                    <input type="text" name="whatsapp" class="form-control" value="{{ old('whatsapp') }}">
                </div>

                {{-- Image --}}
                <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" class="form-control-file">
                </div>

                <button type="submit" class="btn btn-success">Add Faculty</button>

            </form>
        </div>
    </div>
@stop


@section('js')
<script>
    //
    // ADD DEGREE FIELDS
    //
    document.getElementById('addDegreeBtn').addEventListener('click', function() {
        let degreeGroup = document.getElementById('degreeGroup');
        let index = degreeGroup.querySelectorAll('.degree-item').length;

        let newItem = document.createElement('div');
        newItem.className = 'degree-item d-flex mt-2';

        newItem.innerHTML = `
            <input type="text" name="degrees[${index}][degree_name]" class="form-control mr-2" placeholder="Degree Name">
            <input type="text" name="degrees[${index}][degree_university]" class="form-control mr-2" placeholder="University">
            <input type="text" name="degrees[${index}][degree_details]" class="form-control" placeholder="Details">
            <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
        `;

        degreeGroup.appendChild(newItem);

        newItem.querySelector('.removeDegreeBtn').addEventListener('click', () => {
            newItem.remove();
        });
    });


    //
    // ADD RESEARCH FIELDS
    //
    document.getElementById('addResearchBtn').addEventListener('click', function() {
        let researchGroup = document.getElementById('researchGroup');
        let index = researchGroup.querySelectorAll('.research-item').length;

        let newItem = document.createElement('div');
        newItem.className = 'research-item d-flex mt-2';

        newItem.innerHTML = `
            <input type="text" name="research_interests[${index}][title]" class="form-control mr-2" placeholder="Research Title">
            <input type="url" name="research_interests[${index}][url]" class="form-control mr-2" placeholder="Research URL">
            <input type="text" name="research_interests[${index}][description]" class="form-control" placeholder="Description">
            <button type="button" class="btn btn-danger ml-2 removeResearchBtn">Remove</button>
        `;

        researchGroup.appendChild(newItem);

        newItem.querySelector('.removeResearchBtn').addEventListener('click', () => {
            newItem.remove();
        });
    });
</script>
@stop
