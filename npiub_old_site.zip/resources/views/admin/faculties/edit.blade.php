@extends('adminlte::page')

@section('title', 'Edit Faculty')

@section('content_header')
    <h1>Edit Faculty</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">

            {{-- Display Validation Errors --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('faculties.update', $faculty->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                {{-- Department Dropdown --}}
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" class="form-control" required>
                        <option value="">Select Department</option>
                        @foreach($departments as $short => $full)
                            <option value="{{ $short }}" {{ $faculty->department == $short ? 'selected' : '' }}>
                                {{ $full }}
                            </option>
                        @endforeach
                    </select>
                </div>

                {{-- Name --}}
                <div class="form-group">
                    <label for="name">Name</label>
                    <input
                        type="text"
                        name="name"
                        class="form-control"
                        value="{{ old('name', $faculty->name) }}"
                        required
                    >
                </div>

                {{-- Position --}}
                <div class="form-group">
                    <label for="position">Position</label>
                    <input
                        type="text"
                        name="position"
                        class="form-control"
                        value="{{ old('position', $faculty->position) }}"
                        required
                    >
                </div>

                {{-- Contact --}}
                <div class="form-group">
                    <label for="contact">Contact</label>
                    <input
                        type="text"
                        name="contact"
                        class="form-control"
                        value="{{ old('contact', $faculty->contact) }}"
                        required
                    >
                </div>

                {{-- Priority (optional, matches controller/model) --}}
                <div class="form-group">
                    <label for="priority">Priority (0 = Highest)</label>
                    <input
                        type="number"
                        name="priority"
                        class="form-control"
                        min="0"
                        max="10"
                        value="{{ old('priority', $faculty->priority) }}"
                    >
                    <small class="text-muted">Lower number appears first. Use 0 for Head/HOD.</small>
                </div>

                {{-- Degrees Section --}}
                <div class="form-group">
                    <label>Degrees</label>
                    <small class="text-muted d-block mb-2">
                        Degree Name, Institution/University, and optional details.
                    </small>

                    <div id="degreeGroup">
                        @php
                            // 1. Load from old() if validation failed, otherwise from model
                            $degrees = old('degrees', $faculty->degrees);

                            // 2. If it's JSON string, decode
                            if (is_string($degrees)) {
                                $decoded = json_decode($degrees, true);
                                $degrees = is_array($decoded) ? $decoded : [];
                            }

                            // 3. Ensure it's an array
                            if (!is_array($degrees)) {
                                $degrees = [];
                            }

                            // 4. BACKWARD COMPAT: convert simple strings to structured arrays
                            foreach ($degrees as $i => $deg) {
                                if (!is_array($deg)) {
                                    // Old format: "BSc in CSE"
                                    $degrees[$i] = [
                                        'degree_name'       => $deg,
                                        'degree_university' => '',
                                        'degree_details'    => '',
                                    ];
                                } else {
                                    $degrees[$i]['degree_name']       = $deg['degree_name']       ?? '';
                                    $degrees[$i]['degree_university'] = $deg['degree_university'] ?? '';
                                    $degrees[$i]['degree_details']    = $deg['degree_details']    ?? '';
                                }
                            }
                        @endphp

                        @if(count($degrees) > 0)
                            @foreach($degrees as $index => $degree)
                                <div class="degree-item d-flex mt-2">
                                    <input
                                        type="text"
                                        name="degrees[{{ $index }}][degree_name]"
                                        class="form-control mr-2"
                                        value="{{ $degree['degree_name'] ?? '' }}"
                                        placeholder="Degree Name"
                                    >
                                    <input
                                        type="text"
                                        name="degrees[{{ $index }}][degree_university]"
                                        class="form-control mr-2"
                                        value="{{ $degree['degree_university'] ?? '' }}"
                                        placeholder="University"
                                    >
                                    <input
                                        type="text"
                                        name="degrees[{{ $index }}][degree_details]"
                                        class="form-control"
                                        value="{{ $degree['degree_details'] ?? '' }}"
                                        placeholder="Details (optional)"
                                    >
                                    <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
                                </div>
                            @endforeach
                        @else
                            {{-- No degrees yet: show one empty row --}}
                            <div class="degree-item d-flex mt-2">
                                <input
                                    type="text"
                                    name="degrees[0][degree_name]"
                                    class="form-control mr-2"
                                    placeholder="Degree Name"
                                >
                                <input
                                    type="text"
                                    name="degrees[0][degree_university]"
                                    class="form-control mr-2"
                                    placeholder="University"
                                >
                                <input
                                    type="text"
                                    name="degrees[0][degree_details]"
                                    class="form-control"
                                    placeholder="Details (optional)"
                                >
                                <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
                            </div>
                        @endif
                    </div>

                    <button type="button" class="btn btn-success mt-2" id="addDegreeBtn">Add More</button>
                </div>

                {{-- Research Interests Section --}}
                <div class="form-group">
                    <label>Research Areas</label>
                    <small class="text-muted d-block mb-2">
                        Title, optional URL, and a short description.
                    </small>

                    <div id="researchGroup">
                        @php
                            // 1. Load old() or model
                            $researchInterests = old('research_interests', $faculty->research_interests);

                            // 2. If JSON string, decode
                            if (is_string($researchInterests)) {
                                $decoded = json_decode($researchInterests, true);
                                $researchInterests = is_array($decoded) ? $decoded : [];
                            }

                            // 3. Ensure it's an array
                            if (!is_array($researchInterests)) {
                                $researchInterests = [];
                            }

                            // 4. BACKWARD COMPAT:
                            //    - if value is string: treat as title
                            //    - if array: normalize keys
                            foreach ($researchInterests as $i => $research) {
                                if (!is_array($research)) {
                                    $researchInterests[$i] = [
                                        'title'       => $research,
                                        'url'         => '',
                                        'description' => '',
                                    ];
                                } else {
                                    $researchInterests[$i]['title']       = $research['title']       ?? '';
                                    $researchInterests[$i]['url']         = $research['url']         ?? '';
                                    $researchInterests[$i]['description'] = $research['description'] ?? '';
                                }
                            }
                        @endphp

                        @if(count($researchInterests) > 0)
                            @foreach($researchInterests as $index => $research)
                                <div class="research-item d-flex mt-2">
                                    <input
                                        type="text"
                                        name="research_interests[{{ $index }}][title]"
                                        class="form-control mr-2"
                                        value="{{ $research['title'] ?? '' }}"
                                        placeholder="Research Title"
                                    >
                                    <input
                                        type="url"
                                        name="research_interests[{{ $index }}][url]"
                                        class="form-control mr-2"
                                        value="{{ $research['url'] ?? '' }}"
                                        placeholder="URL (optional)"
                                    >
                                    <input
                                        type="text"
                                        name="research_interests[{{ $index }}][description]"
                                        class="form-control"
                                        value="{{ $research['description'] ?? '' }}"
                                        placeholder="Short description (optional)"
                                    >
                                    <button type="button" class="btn btn-danger ml-2 removeResearchBtn">Remove</button>
                                </div>
                            @endforeach
                        @else
                            {{-- No research yet: show one empty row --}}
                            <div class="research-item d-flex mt-2">
                                <input
                                    type="text"
                                    name="research_interests[0][title]"
                                    class="form-control mr-2"
                                    placeholder="Research Title"
                                >
                                <input
                                    type="url"
                                    name="research_interests[0][url]"
                                    class="form-control mr-2"
                                    placeholder="URL (optional)"
                                >
                                <input
                                    type="text"
                                    name="research_interests[0][description]"
                                    class="form-control"
                                    placeholder="Short description (optional)"
                                >
                                <button type="button" class="btn btn-danger ml-2 removeResearchBtn">Remove</button>
                            </div>
                        @endif
                    </div>

                    <button type="button" class="btn btn.success mt-2" id="addResearchBtn">Add More</button>
                </div>

                {{-- Biography --}}
                <div class="form-group">
                    <label for="biography">Biography</label>
                    <textarea
                        name="biography"
                        class="form-control"
                        rows="5"
                        required
                    >{{ old('biography', $faculty->biography) }}</textarea>
                </div>

                {{-- Social Links --}}
                <div class="form-group">
                    <label for="facebook">Facebook</label>
                    <input
                        type="url"
                        name="facebook"
                        class="form-control"
                        value="{{ old('facebook', $faculty->facebook) }}"
                    >
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input
                        type="email"
                        name="email"
                        class="form-control"
                        value="{{ old('email', $faculty->email) }}"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="linkedin">LinkedIn</label>
                    <input
                        type="url"
                        name="linkedin"
                        class="form-control"
                        value="{{ old('linkedin', $faculty->linkedin) }}"
                    >
                </div>

                <div class="form-group">
                    <label for="whatsapp">WhatsApp</label>
                    <input
                        type="text"
                        name="whatsapp"
                        class="form-control"
                        value="{{ old('whatsapp', $faculty->whatsapp) }}"
                    >
                </div>

                {{-- Image --}}
                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" class="form-control-file">
                    @if ($faculty->image)
                        <img
                            src="{{ asset('storage/' . $faculty->image) }}"
                            alt="{{ $faculty->name }}"
                            class="img-thumbnail mt-2"
                            style="width: 150px;"
                        >
                    @endif
                    <small class="text-muted d-block">Leave blank to keep current image.</small>
                </div>

                <button type="submit" class="btn btn-primary">Update Faculty</button>
            </form>
        </div>
    </div>
@stop

@section('js')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add more degrees
    document.getElementById('addDegreeBtn').addEventListener('click', function() {
        let degreeGroup = document.getElementById('degreeGroup');
        let index = degreeGroup.querySelectorAll('.degree-item').length;

        let newDegreeItem = document.createElement('div');
        newDegreeItem.className = 'degree-item d-flex mt-2';
        newDegreeItem.innerHTML = `
            <input type="text" name="degrees[${index}][degree_name]" class="form-control mr-2" placeholder="Degree Name">
            <input type="text" name="degrees[${index}][degree_university]" class="form-control mr-2" placeholder="University">
            <input type="text" name="degrees[${index}][degree_details]" class="form-control" placeholder="Details (optional)">
            <button type="button" class="btn btn-danger ml-2 removeDegreeBtn">Remove</button>
        `;
        degreeGroup.appendChild(newDegreeItem);
    });

    // Add more research areas
    document.getElementById('addResearchBtn').addEventListener('click', function() {
        let researchGroup = document.getElementById('researchGroup');
        let index = researchGroup.querySelectorAll('.research-item').length;

        let newResearchItem = document.createElement('div');
        newResearchItem.className = 'research-item d-flex mt-2';
        newResearchItem.innerHTML = `
            <input type="text" name="research_interests[${index}][title]" class="form-control mr-2" placeholder="Research Title">
            <input type="url" name="research_interests[${index}][url]" class="form-control mr-2" placeholder="URL (optional)">
            <input type="text" name="research_interests[${index}][description]" class="form-control" placeholder="Short description (optional)">
            <button type="button" class="btn btn-danger ml-2 removeResearchBtn">Remove</button>
        `;
        researchGroup.appendChild(newResearchItem);
    });

    // Remove degree via event delegation
    document.getElementById('degreeGroup').addEventListener('click', function(event) {
        if (event.target.classList.contains('removeDegreeBtn')) {
            event.target.closest('.degree-item').remove();
        }
    });

    // Remove research via event delegation
    document.getElementById('researchGroup').addEventListener('click', function(event) {
        if (event.target.classList.contains('removeResearchBtn')) {
            event.target.closest('.research-item').remove();
        }
    });
});
</script>
@stop
