@extends('adminlte::page')

@section('title', 'Galleries Management')

@section('content_header')
    <h1>Galleries Management</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">List of Galleries</h3>
            <div class="card-tools">
                 <a href="{{ route('galleries.create') }}" class="btn btn-primary">Add New Gallery</a>
            </div>
        </div>
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
        <div class="card-body">
        <table class="table table-striped table-bordered table-hover">
        <thead>
            <tr>
                <th>Department</th>
                <th>Title</th>
                <th>Description</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($galleries as $gallery)
                <tr>
                    <td>{{ strtoupper($gallery->department) }}</td>
                    <td>{{ $gallery->title }}</td>
                    <td>{{ $gallery->description }}</td>
                    <td>
                        @if ($gallery->image)
                            <img src="{{ asset('storage/' . $gallery->image) }}" alt="{{ $gallery->title }}" width="100">
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('galleries.edit', $gallery) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('galleries.destroy', $gallery->id) }}" method="POST" style="display:inline-block;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this message?');">Delete</button>
                                </form>
                        
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
        </div>
        <!-- Pagination Links -->
        <div class="container">
            {{ $galleries->links('pagination::bootstrap-5') }}
        </div>
    </div>
@stop

@section('js')
    <script>
        $(function () {
            $('#alumniTable').DataTable();
        });
    </script>
@stop

@section('css')
    <style>
        .table thead th {
            vertical-align: top !important;
        }
    </style>
@stop


