@extends('adminlte::page')

@section('content')


    <div class="card mt-3">
        <div class="card-header">
            <h1 class="card-title">Add New Gallery</h1>
        </div>

        <!-- Display Validation Errors -->
        @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

        <div class="card-body">
        <form action="{{ route('galleries.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" name="title" id="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <label for="department">Department</label>
            <select class="form-control" id="department" name="department" required>
                <option value="all">All Departments</option>
                <option value="cse">Computer Science and Engineering (CSE)</option>
                <option value="eee">Electrical and Electronics Engineering (EEE)</option>
                <option value="food-eng">Food Engineering</option>
                <option value="bba">Bachelor of Business Administration (BBA)</option>
                <option value="mba">Master of Business Administration (MBA)</option>
                <option value="english">B.A in English</option>
                <option value="home">Home Slider</option>
                <!-- Add more departments as needed -->
            </select>
        </div>

        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" name="image" id="image" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
        </div>
    </div>

@endsection
