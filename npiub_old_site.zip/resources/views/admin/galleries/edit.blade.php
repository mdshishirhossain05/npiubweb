@extends('adminlte::page')

@section('content')

    <div class="card mt-3">
        <div class="card-header">
            <h1 class="card-title">Edit Gallery</h1>
        </div>

         <!-- Display Validation Errors -->
         @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

        <div class="card-body">
            <form action="{{ route('galleries.update', $gallery->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" id="title" class="form-control" value="{{ old('title', $gallery->title) }}" required>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" class="form-control">{{ old('description', $gallery->description) }}</textarea>
                </div>

                <div class="form-group">
                    <label for="department">Department</label>
                    <select class="form-control" id="department" name="department" required>
                        <option value="all" {{ $gallery->department == 'all' ? 'selected' : '' }}>All Departments</option>
                        <option value="cse" {{ $gallery->department == 'cse' ? 'selected' : '' }}>Computer Science and Engineering (CSE)</option>
                        <option value="eee" {{ $gallery->department == 'eee' ? 'selected' : '' }}>Electrical and Electronics Engineering (EEE)</option>
                        <option value="food-eng" {{ $gallery->department == 'food-eng' ? 'selected' : '' }}>Food Engineering</option>
                        <option value="bba" {{ $gallery->department == 'bba' ? 'selected' : '' }}>Bachelor of Business Administration (BBA)</option>
                        <option value="mba" {{ $gallery->department == 'mba' ? 'selected' : '' }}>Master of Business Administration (MBA)</option>
                        <option value="english" {{ $gallery->department == 'english' ? 'selected' : '' }}>B.A in English</option>
                        <option value="home" {{ $gallery->department == 'home' ? 'selected' : '' }}>Home Slider</option>
                        <!-- Add more departments as needed -->
                    </select>
                </div>

                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" id="image" class="form-control">
                    @if($gallery->image)
                        <img src="{{ asset('storage/' . $gallery->image) }}" alt="Gallery Image" class="img-thumbnail mt-2" style="max-height: 150px;">
                    @endif
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>

@endsection
