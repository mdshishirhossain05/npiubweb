@extends('adminlte::page')

@section('title', 'Edit Notices')

@section('content')
<div class="container mt-5">
    <h2>Edit Notice</h2>
     <!-- Display Validation Errors -->
     @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
    <form action="{{ route('notices.update', $notice->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        
        <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" id="title" name="title" value="{{ old('title', $notice->title) }}" required>
            @error('title')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" rows="3" required>{{ old('description', $notice->description) }}</textarea>
            @error('description')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="published_by" class="form-label">Published By</label>
            <input type="text" class="form-control" id="published_by" name="published_by" value="{{ old('published_by', $notice->published_by) }}" required>
            @error('published_by')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            <select class="form-control" id="category" name="category" required>
                <option value="all" {{ old('category', $notice->category) == 'all' ? 'selected' : '' }}>General Notices</option>
                <option value="cse" {{ old('category', $notice->category) == 'cse' ? 'selected' : '' }}>Computer Science and Engineering (CSE)</option>
                <option value="eee" {{ old('category', $notice->category) == 'eee' ? 'selected' : '' }}>Electrical and Electronics Engineering (EEE)</option>
                <option value="food-eng" {{ old('category', $notice->category) == 'food-eng' ? 'selected' : '' }}>Food Engineering</option>
                <option value="bba" {{ old('category', $notice->category) == 'bba' ? 'selected' : '' }}>Bachelor of Business Administration (BBA)</option>
                <option value="mba" {{ old('category', $notice->category) == 'mba' ? 'selected' : '' }}>Master of Business Administration (MBA)</option>
                <option value="english" {{ old('category', $notice->category) == 'english' ? 'selected' : '' }}>B.A in English</option>
                <!-- Add more categories as needed -->
            </select>
            @error('category')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="date" class="form-label">Date</label>
            <input type="date" class="form-control" id="date" name="date" value="{{ old('date', $notice->date->format('Y-m-d')) }}" required>
            @error('date')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="file" class="form-label">Upload File</label>
            <input type="file" class="form-control" id="file" name="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx">
            @if(isset($notice->file) && $notice->file)
                <p>Current File: <a href="{{ asset('storage/' . $notice->file) }}" target="_blank">View File</a></p>
            @endif
            @error('file')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="important" class="form-label">Mark as Important</label>
            <div class="form-check">
            <input type="checkbox" class="form-check-input" id="important" name="important" value="1" {{ old('important', $notice->important) ? 'checked' : '' }}>
            <label class="form-check-label" for="important">Yes</label>
            </div>
        </div>

        <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure?')">Update</button>
    </form>
</div>
@endsection
