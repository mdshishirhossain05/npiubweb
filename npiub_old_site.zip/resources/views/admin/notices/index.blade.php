@extends('adminlte::page')

@section('title', 'Notices Management')

@section('content_header')
    <h1>Notices Management</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">List of Notices</h3>
            <div class="card-tools">
                <a href="{{ route('notices.create') }}" class="btn btn-primary mb-3">Add New Notice</a>  
            </div>
        </div>
        @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
        <div class="card-body">
            <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>Title</th>
                    <!-- <th>Description</th> -->
                    <th>Published By</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th>Important</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($notices as $notice)
                <tr class="{{ $notice->important ? 'bg-warning' : '' }}">
                    <td>{{ $notice->title }}</td>
                    <!-- <td>{{ $notice->description }}</td> -->
                    <td>{{ $notice->published_by }}</td>
                    <td>{{ $notice->category }}</td>
                    <td>{{ $notice->date->format('d M Y') }}</td>
                    <td>{{ $notice->important ? 'Yes' : 'No' }}</td>
                    <td>
                        <a href="{{ route('notices.show', $notice->slug) }}" class="btn btn-info btn-sm">View</a>
                        <a href="{{ route('notices.edit', $notice->id) }}" class="btn btn-secondary btn-sm">Edit</a>
                        <form action="{{ route('notices.destroy', $notice->id) }}" method="POST" style="display:inline-block;">
                        @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        </div>
        <!-- Pagination Links -->
        <div class="container">
            {{ $notices->links('pagination::bootstrap-5') }}
        </div>
    </div>
@stop



