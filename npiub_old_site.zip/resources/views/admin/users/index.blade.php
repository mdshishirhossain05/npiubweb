@extends('adminlte::page')

@section('title', 'User Management')

@section('content_header')
    <h1>User Management</h1>
@stop

@section('content')
    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Users</h3>
            <a href="{{ route('users.create') }}" class="btn btn-primary float-right">Add New User</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <!--<th>ID</th>-->
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Department</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        <tr>
                            <!--<td>{{ $user->id }}</td>-->
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ ucfirst($user->role) }}</td>
                            <td>{{ $user->department }}</td>
                            <td>
                                <!-- Display "Primary" badge for primary user -->
                                @if ($user->is_primary)
                                    <span class="badge badge-warning">Primary</span>
                                    
                                    @if ($user->id === 1) <!-- Assuming the special primary user has ID 1 -->
                                        <span class="badge badge-danger badge-sm">Controller</span>
                                    @endif
                                @endif

                                <!-- Actions: Edit/Delete -->
                                @if (Auth::id() === $user->id || Auth::user()->role === 'admin' || (Auth::user()->is_primary && !($user->is_primary && Auth::id() !== $user->id)))
                                    <!-- Allow special primary user to edit/delete all users -->
                                    <a href="{{ route('users.edit', $user->id) }}" class="btn btn-sm btn-info">Edit</a>
                                    <form action="{{ route('users.destroy', $user->id) }}" method="POST" style="display:inline-block;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('User Management Page Loaded'); </script>
@stop
