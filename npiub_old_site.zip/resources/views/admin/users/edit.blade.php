@extends('adminlte::page')

@section('title', 'Edit User')

@section('content_header')
    <h1>Edit User</h1>
@stop

@section('content')
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            <form action="{{ route('users.update', $user->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" value="{{ old('name', $user->name) }}" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email', $user->email) }}" required>
                </div>

                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" class="form-control" required>
                        <option value="user" {{ $user->role == 'user' ? 'selected' : '' }}>User</option>
                        <option value="admin" {{ $user->role == 'admin' ? 'selected' : '' }}>Admin</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" class="form-control" required>
                        <option value="">Select Department</option>
                        <option value="all" {{ $user->department == 'all' ? 'selected' : '' }}>ALL</option>
                        <option value="cse" {{ $user->department == 'cse' ? 'selected' : '' }}>CSE</option>
                        <option value="eee" {{ $user->department == 'eee' ? 'selected' : '' }}>EEE</option>
                        <option value="food-eng" {{ $user->department == 'food-eng' ? 'selected' : '' }}>Food Eng</option>
                        <option value="bba" {{ $user->department == 'bba' ? 'selected' : '' }}>BBA</option>
                        <option value="mba" {{ $user->department == 'mba' ? 'selected' : '' }}>MBA</option>
                        <option value="english" {{ $user->department == 'english' ? 'selected' : '' }}>English</option>
                    </select>
                </div>
                
                @if(Auth::user()->id === 1)
    <div class="form-group">
        <label for="is_primary">Primary User</label><br>
        <!-- Hidden input to ensure is_primary is always sent -->
        <input type="hidden" name="is_primary" value="0">
        <input type="checkbox" name="is_primary" value="1" {{ old('is_primary', $user->is_primary) ? 'checked' : '' }}>
        <span>Yes</span>
    </div>
@else
    <!-- If the user is not the super admin (ID=1), don't allow modification of is_primary -->
    <input type="hidden" name="is_primary" value="{{ $user->is_primary }}">
@endif



                <button type="submit" class="btn btn-primary">Update User</button>
            </form>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Edit User Page Loaded'); </script>
@stop
