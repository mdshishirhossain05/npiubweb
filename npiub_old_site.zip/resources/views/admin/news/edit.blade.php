@extends('adminlte::page')

@section('title', 'Edit News')

@section('content_header')
    <h1>Edit News</h1>
@stop

@section('content')

 <!-- Display Validation Errors -->
 @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
    <form action="{{ route('news.update', $news->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="title" value="{{ $news->title }}" required>
        </div>
        <div class="form-group">
            <label for="content">Content</label>
            <textarea class="form-control" id="content" name="content" rows="5" required>{{ $news->content }}</textarea>
        </div>
        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control" id="image" name="image">
            @if ($news->image)
                <img src="{{ asset('storage/' . $news->image) }}" alt="Current Image" class="img-thumbnail mt-2" width="150">
            @endif
        </div>
        <div class="form-group">
            <label for="author_name">Author Name</label>
            <input type="text" class="form-control" id="author_name" name="author_name" value="{{ $news->author_name }}" required>
        </div>
        <div class="form-group">
            <label for="author_image">Author Image</label>
            <input type="file" class="form-control" id="author_image" name="author_image">
            @if ($news->author_image)
                <img src="{{ asset('storage/' . $news->author_image) }}" alt="Current Author Image" class="img-thumbnail mt-2" width="150">
            @endif
        </div>
        <div class="form-group">
            <label for="author_info">Author Info</label>
            <textarea class="form-control" id="author_info" name="author_info" rows="3" required>{{ $news->author_info }}</textarea>
        </div>
        <div class="form-group">
            <label for="published_at">Published Date</label>
            <input type="date" class="form-control" id="published_at" name="published_at" value="{{ $news->published_at->format('Y-m-d') }}" required>
        </div>
        <div class="form-group">
            <label for="category">Category</label>
            <select class="form-control" id="category" name="category" required>
                <option value="all" {{ $news->category == 'all' ? 'selected' : '' }}>All Departments</option>
                <option value="cse" {{ $news->category == 'cse' ? 'selected' : '' }}>Computer Science and Engineering (CSE)</option>
                <option value="eee" {{ $news->category == 'eee' ? 'selected' : '' }}>Electrical and Electronics Engineering (EEE)</option>
                <option value="food-eng" {{ $news->category == 'food-eng' ? 'selected' : '' }}>Food Engineering</option>
                <option value="bba" {{ $news->category == 'bba' ? 'selected' : '' }}>Bachelor of Business Administration (BBA)</option>
                <option value="mba" {{ $news->category == 'mba' ? 'selected' : '' }}>Master of Business Administration (MBA)</option>
                <option value="english" {{ $news->category == 'english' ? 'selected' : '' }}>B.A in English</option>
                <!-- Add more categories as needed -->
            </select>
        </div>

        <!-- <button type="submit" class="btn btn-primary">Update</button> -->
        <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure?')">Update</button>
    </form>
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
@stop