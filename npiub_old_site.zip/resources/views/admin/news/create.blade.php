@extends('adminlte::page')

@section('title', 'Add News')

@section('content_header')
    <h1>Add News</h1>
@stop

@section('content')

 <!-- Display Validation Errors -->
 @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
    <form action="{{ route('news.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="content">Content</label>
            <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
        </div>
        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control" id="image" name="image" required>
        </div>
        <div class="form-group">
            <label for="author_name">Author Name</label>
            <input type="text" class="form-control" id="author_name" name="author_name" required>
        </div>
        <div class="form-group">
            <label for="author_image">Author Image</label>
            <input type="file" class="form-control" id="author_image" name="author_image" required>
        </div>
        <div class="form-group">
            <label for="author_info">Author Info</label>
            <textarea class="form-control" id="author_info" name="author_info" rows="3" required></textarea>
        </div>
        <div class="form-group">
            <label for="published_at">Published Date</label>
            <input type="date" class="form-control" id="published_at" name="published_at" required>
        </div>
        <div class="form-group">
            <label for="category">Category</label>
            <select class="form-control" id="category" name="category" required>
                <option value="all">All Departments</option>
                <option value="cse">Computer Science and Engineering (CSE)</option>
                <option value="eee">Electrical and Electronics Engineering (EEE)</option>
                <option value="food-eng">Food Engineering</option>
                <option value="bba">Bachelor of Business Administration (BBA)</option>
                <option value="mba">Master of Business Administration (MBA)</option>
                <option value="english">B.A in English</option>
                <!-- Add more categories as needed -->
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
@stop

@section('css')
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
@stop
