@extends('layouts.default')

@section('title', 'Food Engineering - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('departments.food_eng.welcome')
    @include('galleries.galleries', ['latestGallery' => $latestGallery, 'department' => 'Food Engineering'])
    @include('faculties.faculties', ['faculties' => $faculties])
    @include('officers.officers', ['officers' => $officers])
    @include('alumni.alumni', ['latestAlumni' => $latestAlumni, 'department' => 'Food Engineering'])
    @include('notices.dept_notices', ['notices' => $notices, 'department' => 'Food Engineering'])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
     {{-- This line shows ONLY CSE admission info (no dropdown, no intro) --}}
    @include('departments.partials.undergrad_admission', ['program' => $program])
@endsection
