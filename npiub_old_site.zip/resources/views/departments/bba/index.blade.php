@extends('layouts.default')

@section('title', 'BBA - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('departments.bba.welcome')
    @include('galleries.galleries', ['latestGallery' => $latestGallery, 'department' => 'BBA'])
    @include('faculties.faculties', ['faculties' => $faculties])
    @include('alumni.alumni', ['latestAlumni' => $latestAlumni, 'department' => 'BBA'])
    @include('notices.dept_notices', ['notices' => $notices, 'department' => 'BBA'])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
     {{-- This line shows ONLY CSE admission info (no dropdown, no intro) --}}
    @include('departments.partials.undergrad_admission', ['program' => $program])
@endsection
