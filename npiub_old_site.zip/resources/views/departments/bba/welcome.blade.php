
  <style>
    /* Your custom CSS for the welcome section */
    #welcomeCSE {
      background-color: #ffffff;
      overflow: hidden;
    }
  
    .hero-image {
      position: relative;
      overflow: hidden;
    }

    .hero-image img{
      aspect-ratio: 16/9;
      
      object-fit:cover;
    }

    .typing-effect {
      position: absolute;
      top: 65%;
      left: 5%;
      transform: translateY(-50%);
      color: #ffd700; /* Goldish color (Hex: #ffd700) */
      font-size: 3.2vw; /* Adjust font size as needed */
      font-weight: 700;
      white-space: nowrap; /* Prevent text from wrapping */
      background: rgba(0, 0, 0, 0.5);
    }

    #cursor {
      display: inline-block;
      vertical-align: middle;
      width: 2px; /* Cursor width */
      height: 24px; /* Cursor height */
      background-color: white; /* Cursor color */
      animation: blink 0.75s infinite alternate; /* Cursor blinking animation */
    }

    .welcome_heading {
      position: absolute;
      top: 55%;
      left: 5%;
      transform: translateY(-50%);
      color: #fff;
      font-size: 3.5vw; /* Adjust font size as needed */
      font-weight: 700;
    }

    .welcome-message {
      text-align: justify;
      color: #000;
    }

    .welcome-message-heading {
      color: #054D94;
    }
  
    @media (max-width: 768px) {
      .typing-effect {
        top: 63%;
      }
    }

    @keyframes blink {
      0% {
        opacity: 0;
      }
      100% {
        opacity: 1;
      }
    }
  </style>

    <!-- Welcome Section -->
    <div id="welcomeCSE">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col">
                @foreach($latestWelcome as $galleries)
                    <div class="hero-image">
                        <!-- <a href="{{ asset('storage/' . $galleries->image) }}" data-fancybox="gallery" data-caption="{{ $galleries->title }}">
                        <img src="{{ asset('storage/' . $galleries->image) }}" class="img-fluid" alt="Galleries Image">
                        </a> -->
                        <img src="{{ asset('storage/' . $galleries->image) }}" class="img-fluid w-100" alt="Galleries Image">
                        <h1 class="welcome_heading">Welcome To:</h1>
                        <div class="typing-effect">
                            <p id="text"></p>
                            <!-- <span id="cursor"></span> -->
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Welcome message -->
        <div class="container-fluid p-4 p-md-5">
            <div class="row mt-2">
                <div class="col text-center">
                    <h2 class="welcome-message-heading"><b>Welcome to Our Department</b></h2>
                    <div class="welcome-message">
                        <b>Dear Students and Visitors,</b><br>
                        <p class="welcome-message-short d-block d-md-none">
                        On behalf of our esteemed faculty members, dedicated staff, and enthusiastic students, it is my pleasure to extend a warm welcome to all of our website visitors. At the Department of Business Administration of North Pacific International University of Bangladesh (NPIUB), we pride ourselves on being the pinnacle of educational excellence in this vibrant region. <a href="#" class="show-more-link text-primary">Show More</a>
                        </p>
                        <p class="welcome-message-full d-none d-md-block">
                        On behalf of our esteemed faculty members, dedicated staff, and enthusiastic students, it is my pleasure to extend a warm welcome to all of our website visitors. At the Department of Business Administration of North Pacific International University of Bangladesh (NPIUB), we pride ourselves on being the pinnacle of educational excellence in this vibrant region.
                        As the sole university in this dynamic area, we are steadfast in our commitment to nurturing a dynamic learning environment where innovation, excellence, and inclusivity flourish. Currently offering both BBA and MBA degrees, our department stands at the forefront of pioneering research and practical education. Here, students not only gain theoretical knowledge but also acquire hands-on experience that prepares them for the challenges of the ever-evolving business landscape. Our faculty members, with their wealth of expertise and dedication, guide students towards achieving their academic and professional goals.
                        Whether you're a prospective student, a curious visitor, or a valued partner, we invite you to explore the opportunities and resources available at our department. Together, let's embark on a journey of growth, discovery, and success.
                        Again, welcome to the Department of Business Administration at NPI University of Bangladesh. We look forward to embarking on this transformative journey with you. <a href="#" class="show-less-link text-primary d-md-none">Show Less</a>
                        </p>
                    </div>
                    <p class="welcome-message"><b>Warm regards,</b><br>
                        Md. Touhidul Islam<br>
                        Asst. Prof. & Head, Dept. of Business Administration<br>
                        North Pacific International University of Bangladesh.</p>
                </div>
            </div>
        </div>
    </div>


    <!-- Typing Effect Script -->
    <script>
        const texts = [
            "North Pacific International University of Bangladesh.",
            "Department of Business Administration.",
            "নর্থ প্যাসিফিক ইন্টারন্যাশনাল ইউনিভার্সিটি অব বাংলাদেশ।",
            "ব্যবসায় প্রশাসন বিভাগ।"
        ];

        const typeWriter = async (textElement, text) => {
            for (let i = 0; i <= text.length; i++) {
                textElement.textContent = text.substring(0, i);
                await new Promise(resolve => setTimeout(resolve, 50));
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            for (let i = text.length; i >= 0; i--) {
                textElement.textContent = text.substring(0, i);
                await new Promise(resolve => setTimeout(resolve, 25));
            }
            await new Promise(resolve => setTimeout(resolve, 500));
        };

        const startTyping = async () => {
            const textElement = document.getElementById("text");
            for (let i = 0; i < texts.length; i++) {
                await typeWriter(textElement, texts[i]);
            }
            startTyping();
        };

        window.onload = function() {
            startTyping();
        };
    </script>

    <!-- Show More/Less Script -->
    <script>
        $(document).ready(function() {
            $(".show-more-link").click(function(e) {
                e.preventDefault();
                $(".welcome-message-short").addClass("d-none");
                $(".welcome-message-full").removeClass("d-none");
            });

            $(".show-less-link").click(function(e) {
                e.preventDefault();
                $(".welcome-message-full").addClass("d-none");
                $(".welcome-message-short").removeClass("d-none");
            });
        });
    </script>

