@extends('layouts.default')

@section('title', 'MBA - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('departments.mba.welcome')
    @include('galleries.galleries', ['latestGallery' => $latestGallery, 'department' => 'MBA'])
    @include('faculties.faculties', ['faculties' => $faculties])
    @include('alumni.alumni', ['latestAlumni' => $latestAlumni, 'department' => 'MBA'])
    @include('notices.dept_notices', ['notices' => $notices, 'department' => 'MBA'])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
    {{-- This line shows ONLY CSE admission info (no dropdown, no intro) --}}
    @include('departments.partials.postgrad_admission', ['program' => $program])
@endsection
