@extends('layouts.default')

@section('title', 'EEE - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('departments.eee.welcome')
    @include('galleries.galleries', ['latestGallery' => $latestGallery, 'department' => 'EEE'])
    @include('faculties.faculties', ['faculties' => $faculties])
    @include('officers.officers', ['officers' => $officers])
    @include('alumni.alumni', ['latestAlumni' => $latestAlumni, 'department' => 'EEE'])
    @include('notices.dept_notices', ['notices' => $notices, 'department' => 'EEE'])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
     {{-- This line shows ONLY CSE admission info (no dropdown, no intro) --}}
    @include('departments.partials.undergrad_admission', ['program' => $program])
@endsection