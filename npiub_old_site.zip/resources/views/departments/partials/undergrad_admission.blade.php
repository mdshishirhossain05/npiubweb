{{-- resources/views/departments/partials/undergrad_admission.blade.php --}}

<style>
  body {
    background-color: #fff;
    color: #333;
  }

  .table-dark{
    --bs-table-bg: #054D94 !important;
  }

  .admission-heading{
    font-size: 2rem;
    font-weight: bold;
    color:  #054D94;
  }

  .section-admission {
    font-size: 1.5rem;
    font-weight: bold;
    border-bottom: 2px solid  #054D94;
    margin-bottom: 1rem;
    padding-bottom: .5rem;
    color:  #054D94;
  }

  .key-date-icon {
    font-size: 1.2rem;
    margin-right: 0.5rem;
    color: #007bff;
  }

  .table-responsive{
    overflow: hidden;
  }

  .scholarships{
    height: auto;
  }

  .scholar-data, .cost-data {
    padding: 0 1rem;
  }

  .contact-card {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.5s ease, box-shadow 0.3s ease;
    border: none;
    padding: 1rem;
  }

  .contact-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
  }

  .contact-icon {
    font-size: 3rem;
    color: #007bff;
  }

  .contact-card h4 {
    font-weight: 700;
    margin-bottom: 5px;
    font-size: 20px;
    color: #054D94;
  }

  .contact-card span {
    display: block;
    font-size: 15px;
    padding-bottom: 10px;
    position: relative;
    font-weight: 500;
  }

  .contact-card p {
    margin: .5rem 0 0 0;
    font-size: 14px;
  }

  .contact-card .social {
    margin-top: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .contact-card .social a {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #eff2f8;
    text-decoration: none;
  }

  .card-admission .social a i {
    color: #054D94;
    font-size: 16px;
    margin: 0 2px;
    transition: transform 0.5s ease;
  }

  .card-admission .social a:hover {
    background: #054D94;
  }

  .card-admission .social a:hover i {
    color: #fff;
  }

  .card-admission .social a+a {
    margin-left: 8px;
  }
</style>

<section id="admission">
  <div class="container my-5">

    {{-- Header Section --}}
    <div class="text-center mb-5">
      <h2 class="admission-heading">
        {{ $program['admission_heading'] ?? 'Admission Information' }}
      </h2>
      @if(!empty($program['admission_lead']))
        <p class="lead text-muted">{{ $program['admission_lead'] }}</p>
      @endif
      @if(!empty($program['semester_note']))
        <p class="lead">{{ $program['semester_note'] }}</p>
      @endif
    </div>

    {{-- Eligibility Section --}}
    <div class="mb-5">
      <h2 class="section-admission">Eligibility Requirements</h2>
      <p class="lead">Are you ready to embark on an exciting academic journey? Ensure you meet our eligibility criteria:</p>
      <ul class="list-unstyled">
        @if(!empty($program['eligibility']))
          @foreach($program['eligibility'] as $item)
            <li class="mb-2">
              <i class="fa-duotone fa-check-circle text-success"></i>
              {{ $item }}
            </li>
          @endforeach
        @endif

        @if(!empty($program['syllabus_files']))
          <ul class="list-unstyled mt-2">
            @foreach($program['syllabus_files'] as $file)
              <li class="mb-2">
                <a class="text-decoration-none" href="{{ asset($file['path']) }}" download>
                  <i class="fa-duotone fa-file-pdf text-danger"></i>
                  {{ $file['label'] }}
                </a>
              </li>
            @endforeach
          </ul>
        @endif
      </ul>
    </div>

    {{-- Cost Breakdown --}}
    <div class="mb-5">
      <h2 class="section-admission">Cost Breakdown</h2>
      <div class="table-responsive">
        <table class="table cost table-striped table-hover table-bordered align-middle">
          <thead class="table-dark">
            <tr>
              <th>
                <div class="cost-data">
                  <div>Description</div>
                </div>
              </th>
              <th>
                <div class="cost-data">
                  <div>Cost (BDT)</div>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            @if(!empty($program['cost']))
              @foreach($program['cost'] as $row)
                <tr>
                  <td class="col-8">
                    <div class="cost-data">
                      <div>{{ $row['label'] }}</div>
                    </div>
                  </td>
                  <td>
                    <div class="cost-data text-center">
                      <div>{{ $row['amount'] }}</div>
                    </div>
                  </td>
                </tr>
              @endforeach
            @endif

            @if(!empty($program['regular_totals']))
              @foreach($program['regular_totals'] as $row)
                <tr>
                  <td>
                    <div class="cost-data">
                      <div>{{ $row['label'] }}</div>
                    </div>
                  </td>
                  <td>
                    <div class="cost-data text-center">
                      <div>{{ $row['amount'] }}</div>
                    </div>
                  </td>
                </tr>
              @endforeach
            @endif

            @if(!empty($program['discount_banner']))
              <tr>
                <td colspan="2" class="text-center text-danger fw-bold">
                  <div class="cost-data">
                    <div>{{ $program['discount_banner'] }}</div>
                  </div>
                </td>
              </tr>
            @endif

            @if(!empty($program['discount_totals']))
              @foreach($program['discount_totals'] as $row)
                <tr>
                  <td>
                    <div class="cost-data">
                      <div>{{ $row['label'] }}</div>
                    </div>
                  </td>
                  <td>
                    <div class="cost-data text-center">
                      <div>{{ $row['amount'] }}</div>
                    </div>
                  </td>
                </tr>
              @endforeach
            @endif

          </tbody>
        </table>
      </div>
    </div>

    {{-- Scholarship Tables --}}
@if(!empty($program['scholarships']) && is_array($program['scholarships']))
    <div class="mb-5">
        <h2 class="section-admission">Scholarship Opportunities</h2>
        <div class="table-responsive">
            <div class="row">
                @foreach($program['scholarships'] as $group)
                    <div class="col-md-4 mb-3">
                        <table class="table scholarships table-striped table-hover table-bordered align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th colspan="2" class="text-center">
                                        {{ $group['title'] ?? 'Scholarship' }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!empty($group['rows']) && is_array($group['rows']))
                                    @foreach($group['rows'] as $row)
                                        <tr>
                                            <td class="col-8">
                                                <div class="scholar-data">
                                                    <div>{{ $row['label'] ?? '' }}</div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="scholar-data text-end">
                                                    <div>{{ $row['amount'] ?? ($row['waiver'] ?? '') }}</div>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="2" class="text-center">
                                            No scholarship data available for this category.
                                        </td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@else
    {{-- Optional fallback if a program has no scholarship config --}}
    <div class="mb-5">
        <h2 class="section-admission">Scholarship Opportunities</h2>
        <p class="text-muted">
            Scholarship information for this program will be announced soon.
        </p>
    </div>
@endif


    {{-- Contact Us --}}
    <div class="mb-5">
      <h2 class="section-admission">Contact Us</h2>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        @if(!empty($program['contacts']))
          @foreach($program['contacts'] as $contact)
            <div class="col">
              <div class="card bg-light h-100 text-center contact-card">
                <div class="card-admission">
                  <i class="fa-duotone fa-user-headset fa-2xl p-4"></i>
                  <h4>{{ $contact['name'] }}</h4>
                  @if(!empty($contact['title']))
                    <span>{{ $contact['title'] }}</span>
                  @endif
                  @if(!empty($contact['phone']))
                    <p>
                      Contact: <a href="tel:{{ $contact['phone'] }}">{{ $contact['phone'] }}</a>
                    </p>
                  @endif
                  <div class="social">
                    @if(!empty($contact['facebook']))
                      <a href="{{ $contact['facebook'] }}"><i class="fa-brands fa-facebook"></i></a>
                    @endif
                    @if(!empty($contact['email']))
                      <a href="mailto:{{ $contact['email'] }}"><i class="fa-solid fa-envelope"></i></a>
                    @endif
                    @if(!empty($contact['linkedin']))
                      <a href="{{ $contact['linkedin'] }}"><i class="fa-brands fa-linkedin"></i></a>
                    @endif
                    @if(!empty($contact['whatsapp']))
                      <a href="https://wa.me/{{ $contact['whatsapp'] }}"><i class="fa-brands fa-whatsapp"></i></a>
                    @endif
                  </div>
                </div>
              </div>
            </div>
          @endforeach
        @endif
      </div>
    </div>

    <!--{{-- How to Apply --}}-->
    <!--<div class="mb-5">-->
    <!--  <h2 class="section-admission">How to Apply</h2>-->
    <!--  <p class="lead">Ready to take the first step toward your future? Follow these simple instructions:</p>-->
    <!--  <ol class="list-unstyled">-->
    <!--    @if(!empty($program['how_to_apply']))-->
    <!--      @foreach($program['how_to_apply'] as $step)-->
    <!--        <li>-->
    <!--          <i class="fa-duotone fa-check-circle text-success"></i>-->
    <!--          {{ $step }}-->
    <!--        </li>-->
    <!--      @endforeach-->
    <!--    @endif-->
    <!--  </ol>-->
    <!--</div>-->

    <!--{{-- Key Dates --}}-->
    <!--<div>-->
    <!--  <h2 class="section-admission">Key Dates</h2>-->
    <!--  <ul class="list-unstyled">-->
    <!--    @if(!empty($program['key_dates']))-->
    <!--      @foreach($program['key_dates'] as $date)-->
    <!--        <li>-->
    <!--          <i class="{{ $date['icon'] }} text-success key-date-icon"></i>-->
    <!--          <strong>{{ $date['label'] }}:</strong> {{ $date['value'] }}-->
    <!--        </li>-->
    <!--      @endforeach-->
    <!--    @endif-->
    <!--  </ul>-->
    <!--</div>-->

  </div>
</section>

<script>
  $(document).ready(function() {
    var maxTableHeight = Math.max.apply(null, $(".scholarships").map(function () {
      return $(this).height();
    }).get());

    $(".scholarships").height(maxTableHeight);
  });
</script>
