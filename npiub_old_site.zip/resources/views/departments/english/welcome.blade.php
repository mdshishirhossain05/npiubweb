
  <style>
    /* Your custom CSS for the welcome section */
    #welcomeCSE {
      background-color: #ffffff;
      overflow: hidden;
    }
  
    .hero-image {
      position: relative;
      overflow: hidden;
    }

    .hero-image img{
      aspect-ratio: 16/9;
      
      object-fit:cover;
    }


    .typing-effect {
      position: absolute;
      top: 65%;
      left: 5%;
      transform: translateY(-50%);
      color: #ffd700; /* Goldish color (Hex: #ffd700) */
      font-size: 3.2vw; /* Adjust font size as needed */
      font-weight: 700;
      white-space: nowrap; /* Prevent text from wrapping */
      background: rgba(0, 0, 0, 0.5);
    }

    #cursor {
      display: inline-block;
      vertical-align: middle;
      width: 2px; /* Cursor width */
      height: 24px; /* Cursor height */
      background-color: white; /* Cursor color */
      animation: blink 0.75s infinite alternate; /* Cursor blinking animation */
    }

    .welcome_heading {
      position: absolute;
      top: 55%;
      left: 5%;
      transform: translateY(-50%);
      color: #fff;
      font-size: 3.5vw; /* Adjust font size as needed */
      font-weight: 700;
    }

    .welcome-message {
      text-align: justify;
      color: #000;
    }

    .welcome-message-heading {
      color: #054D94;
    }
  
    @media (max-width: 768px) {
      .typing-effect {
        top: 63%;
      }
    }

    @keyframes blink {
      0% {
        opacity: 0;
      }
      100% {
        opacity: 1;
      }
    }
  </style>

    <!-- Welcome Section -->
    <div id="welcomeCSE">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col">
                @foreach($latestWelcome as $galleries)
                    <div class="hero-image">
                        <!-- <a href="{{ asset('storage/' . $galleries->image) }}" data-fancybox="gallery" data-caption="{{ $galleries->title }}">
                        <img src="{{ asset('storage/' . $galleries->image) }}" class="img-fluid" alt="Galleries Image">
                        </a> -->
                        <img src="{{ asset('storage/' . $galleries->image) }}" class="img-fluid w-100" alt="Galleries Image">
                        <h1 class="welcome_heading">Welcome To:</h1>
                        <div class="typing-effect">
                            <p id="text"></p>
                            <!-- <span id="cursor"></span> -->
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Welcome message -->
        <div class="container-fluid p-4 p-md-5">
            <div class="row mt-2">
                <div class="col text-center">
                    <h2 class="welcome-message-heading"><b>Welcome to Our Department</b></h2>
                    <div class="welcome-message">
                        <b>Dear Students and Visitors,</b><br>
                        <p class="welcome-message-short d-block d-md-none">
                            Welcome to the Department of English at North Pacific International University of Bangladesh (NPIUB), a vibrant academic community dedicated to fostering excellence in literature, language, and creative expression. <a href="#" class="show-more-link text-primary">Show More</a>
                        </p>
                        <p class="welcome-message-full d-none d-md-block">
                             Welcome to the Department of English at North Pacific International University of Bangladesh (NPIUB), a vibrant academic community dedicated to fostering excellence in literature, language, and creative expression. Our department is home to a diverse and accomplished faculty who are passionate about teaching, research, and mentorship. Through innovative coursework, engaging seminars, and hands-on learning experiences, we challenge our students to explore the power of words, both as a means of understanding the world and shaping it. Whether your interests lie in classical literature, contemporary writing, linguistics, or digital storytelling, our programs provide a dynamic platform to hone your skills and expand your horizons. Thank you for visiting, and I hope you will join us on this exciting journey of discovery and achievement. <a href="#" class="show-less-link text-primary d-md-none">Show Less</a>
                        </p>
                    </div>
                    <p class="welcome-message"><b>Warm regards,</b><br>
                        Md. Fahad Hossen Shovo<br>
                        Lecturer & Head (act.), Dept. of English<br>
                        NPI University of Bangladesh.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Typing Effect Script -->
    <script>
        const texts = [
          "North Pacific International University of Bangladesh.",
          "Department of English.",
          "নর্থ প্যাসিফিক ইন্টারন্যাশনাল ইউনিভার্সিটি অব বাংলাদেশ।",
          "ইংরেজি বিভাগ।"
        ];

        const typeWriter = async (textElement, text) => {
            for (let i = 0; i <= text.length; i++) {
                textElement.textContent = text.substring(0, i);
                await new Promise(resolve => setTimeout(resolve, 50));
            }
            await new Promise(resolve => setTimeout(resolve, 1000));
            for (let i = text.length; i >= 0; i--) {
                textElement.textContent = text.substring(0, i);
                await new Promise(resolve => setTimeout(resolve, 25));
            }
            await new Promise(resolve => setTimeout(resolve, 500));
        };

        const startTyping = async () => {
            const textElement = document.getElementById("text");
            for (let i = 0; i < texts.length; i++) {
                await typeWriter(textElement, texts[i]);
            }
            startTyping();
        };

        window.onload = function() {
            startTyping();
        };
    </script>

    <!-- Show More/Less Script -->
    <script>
        $(document).ready(function() {
            $(".show-more-link").click(function(e) {
                e.preventDefault();
                $(".welcome-message-short").addClass("d-none");
                $(".welcome-message-full").removeClass("d-none");
            });

            $(".show-less-link").click(function(e) {
                e.preventDefault();
                $(".welcome-message-full").addClass("d-none");
                $(".welcome-message-short").removeClass("d-none");
            });
        });
    </script>

