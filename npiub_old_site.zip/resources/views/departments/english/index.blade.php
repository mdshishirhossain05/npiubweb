@extends('layouts.default')

@section('title', 'English - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('departments.english.welcome')
    @include('galleries.galleries', ['latestGallery' => $latestGallery, 'department' => 'English'])
    @include('faculties.faculties', ['faculties' => $faculties])
    @include('alumni.alumni', ['latestAlumni' => $latestAlumni, 'department' => 'English'])
    @include('notices.dept_notices', ['notices' => $notices, 'department' => 'English'])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
     {{-- This line shows ONLY CSE admission info (no dropdown, no intro) --}}
    @include('departments.partials.undergrad_admission', ['program' => $program])
@endsection
