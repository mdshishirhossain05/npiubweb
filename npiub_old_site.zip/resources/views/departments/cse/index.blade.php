@extends('layouts.default')

@section('title', 'CSE - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('departments.cse.welcome')
    @include('galleries.galleries', ['latestGallery' => $latestGallery, 'department' => 'CSE'])
    @include('faculties.faculties', ['faculties' => $faculties])
    @include('officers.officers', ['officers' => $officers])
    @include('alumni.alumni', ['latestAlumni' => $latestAlumni, 'department' => 'CSE'])
    @include('notices.dept_notices', ['notices' => $notices, 'department' => 'CSE'])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
    
     {{-- This line shows ONLY CSE admission info (no dropdown, no intro) --}}
    @include('departments.partials.undergrad_admission', ['program' => $program])
@endsection


    


