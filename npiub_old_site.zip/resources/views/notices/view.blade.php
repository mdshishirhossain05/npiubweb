@extends('layouts.default')

@section('title', $notice->title . ' - Notices View - NPIUB, North Pacific International University of Bangladesh')

@section('content')

<style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f8f9fa;
        color: #333;
    }
    .breadcrumb {
        background-color: transparent;
        margin-bottom: 30px;
    }
    .notice-container {
        background: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .notice-header {
        border-bottom: 1px solid #ddd;
        margin-bottom: 20px;
        padding-bottom: 10px;
    }
    .notice-header h1 {
        font-size: 28px;
        color: #0056b3;
    }
    .notice-meta {
        font-size: 14px;
        color: #777;
        margin-bottom: 20px;
    }
    .notice-meta strong {
        color: #333;
    }
    .notice-content {
        font-size: 16px;
        line-height: 1.6;
    }
    .btn-view-file {
        margin-top: 20px;
    }
    .related-notices {
        margin-top: 40px;
    }
    .related-notices h3 {
        font-size: 22px;
        margin-bottom: 20px;
    }
    .related-notice-item {
        margin-bottom: 15px;
    }
    
    .related-notices a{
        text-decoration: underline !important;
        color: #777;
    }
        
    </style>


    <div class="container pt-5 pb-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="/notices">Notices</a></li>
                <li class="breadcrumb-item active" aria-current="page">{{ $notice->title }}</li>
            </ol>
        </nav>
    
        <!-- Notice Container -->
        <div class="notice-container">
            <div class="notice-header">
                <h1>{{ $notice->title }}</h1>
                <div class="notice-meta">
                    <p><strong>Date:</strong> {{ $notice->date->format('d M Y') }}</p>
                    <p><strong>Published by:</strong> {{ $notice->published_by }}</p>
                    <p><strong>Total Views:</strong> {{ $notice->views }}</p>
                </div>
            </div>
    
            <div class="notice-content">
                <p>{{ $notice->description }}</p>
                @if($notice->file)
                    <a href="{{ Storage::url($notice->file) }}" target="_blank" class="btn btn-primary btn-view-file">
                        <i class="fas fa-file-download"></i> View/Download File
                    </a>
                @endif
            </div>
        </div>
    
        <!-- Related Notices -->
        @if($relatedNotices->isNotEmpty())
            <div class="related-notices">
                <h3>Related Notices</h3>
                @foreach($relatedNotices as $relatedNotice)
                    <div class="related-notice-item">
                        <a href="{{ route('notices.view', $relatedNotice->slug) }}"><i class="fas fa-tag"></i> {{ $relatedNotice->title }}</a>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
@endsection

