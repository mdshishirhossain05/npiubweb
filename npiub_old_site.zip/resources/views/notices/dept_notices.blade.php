
    <style>
        /* Custom styles */
        

        .categories{
            z-index: 2 !important;
        }

    
        .dropdown-menu {
            width: 100%;
            border: none;
            border-radius: 0.25rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            --bs-dropdown-padding-y: 0;
        }
        .dropdown-item {
            padding: .8rem !important;
            transition: background-color 0.3s, color 0.3s;
        }
        .dropdown-item:hover {
            background-color: #054D94;
            color: white;
        }
        .dropdown-toggle::after {
            transition: transform 0.3s;
        }
        .dropdown-toggle.collapsed::after {
            /* transform: rotate(180deg); */
        }

        table thead th {
            background-color: #054D94;
            color: #fff;
            text-align: center;
            padding: 12px;
        }

        table tbody tr {
            transition: background-color 0.3s, transform 0.3s;
        }

        table td a {
            color: #054D94;
            /* text-decoration: none; */
        }

        table td a:hover {
            text-decoration: underline;
        }

        .table-responsive {
            margin-top: 20px;
        }

        table td, table th {
            vertical-align: middle;
            /* text-align: center; */
        }

        table td {
            padding: 10px;
        }

        .table-date {
            text-align: center;
        }

        .btn-secondary {
            background-color: #054D94 !important;
        }
        
        .table-dark {
            --bs-table-bg: #054D94 !important;
        }

        .heading-section {
            color: #054D94;
        }

        @media only screen and (min-width: 769px) {
            .btn-dropdown {
                position: absolute;
                top: 30px;
            }
        }

        #noCategoryMessage {
            display: none;
        }

        /* Important Notices Styling */

        .table-danger {
            --bs-table-color: #000 !important; /* Text color */
            --bs-table-bg: #f5b7b1 !important; /* Light red/pink background color */
            --bs-table-border-color: #e6a8a1 !important; /* Border color slightly darker than background */
            --bs-table-striped-bg: #f3a699 !important; /* Striped row background color */
            --bs-table-striped-color: #000 !important; /* Text color for striped rows */
            --bs-table-active-bg: #e89a92 !important; /* Background color when a row is active */
            --bs-table-active-color: #000 !important; /* Text color when a row is active */
            --bs-table-hover-bg: #f1c0b9 !important; /* Background color when a row is hovered over */
            --bs-table-hover-color: #000 !important; /* Text color when a row is hovered over */
            color: var(--bs-table-color) !important; /* Apply text color */
            border-color: var(--bs-table-border-color) !important; /* Apply border color */
        }

        .notices-btn{
            
            z-index: 1;
            
        }
    </style>

@php
    $departmentName = ucfirst($department ?? 'department');
@endphp


<div class="container notice-section pt-5 pb-5">
    <div class="text-center">
        <h2 class="heading-section">Notices, Dept. of {{ $departmentName }}, NPIUB</h2>
        <p class="lead">Explore Important Notices: Your Source for {{ $departmentName }} Department Updates</p>
    </div>

    <div id="notice-content">
        <div class="notice-category">
            <div class="table-responsive">
                <table id="myTable" class="table table-striped table-hover table-bordered"
                       data-toggle="table"
                       data-search="true"
                       data-show-toggle="true"
                       data-show-columns="true"
                       data-pagination="true"
                       data-buttons-align="right"
                       data-search-align="left"
                       data-show-refresh="false"
                       data-show-search-button="false"
                       >
                    <thead class="table-dark">
                    <tr>
                        <th class="col-md-2 table-date" data-field="date" data-sortable="true">Date</th>
                        <th class="col-md-4" data-field="title" data-sortable="true">Title</th>
                        <th class="col-md-4" data-field="description">Description</th>
                        <th class="col-md-2" data-field="views" data-visible="false">Total Views</th>
                        <th class="col-md-2" data-field="published" data-visible="false">Published by</th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($notices as $notice)
                            <tr class="{{ $notice->important ? 'table-danger' : '' }}" data-category="{{ $notice->category }}" >
                                <td>{{ $notice->created_at->format('d M Y') }}</td>
                                <td><a href="{{ route('notices.view', $notice->slug) }}">{{ $notice->title }}</a></td>
                                <td>{{ $notice->description }}</td>
                                <td>{{ $notice->views }} views</td>
                                <td>{{ $notice->published_by }}</td>
                            </tr>
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row text-center mt-4">
            <div class="col-md-12">
            <a href="{{ url('/notices') }}"><button class="btn btn btn-primary notices-btn"  type="button" >Notice Board</button></a>
            </div>
    </div>

</div>

