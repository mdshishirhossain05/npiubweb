@extends('layouts.default')

@section('title', 'News Archives - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    <style>
    /* Custom styles */
    .dropdown-menu {
            width: 100%;
            border: none;
            border-radius: 0.25rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            --bs-dropdown-padding-y: 0;
            
        }
        .dropdown-item {
            padding: .8rem !important;
            transition: background-color 0.3s, color 0.3s;
          
        }
        .dropdown-item:hover {
            background-color: #054D94;
            color: white;
        }
        .dropdown-toggle::after {
            transition: transform 0.3s;
        }
        .dropdown-toggle.collapsed::after {
            /* transform: rotate(180deg); */
        }

    .news-card {
      background: #fff;
      border: none;
      border-top: 4px solid #007BFF;
      border-radius: 0 0 .5rem .5rem;
      overflow: hidden;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      /* display: flex;
    flex-direction: column;
    justify-content: space-between; */
    height: 100%; /* Ensure the card takes up the full height */
    }
    .news-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 30px 60px rgba(0, 0, 0, 0.2);
    }
    .news-card img {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
      object-fit: cover;
      transition: transform 0.3s ease;
      width: 100%;
    height: auto;
    aspect-ratio: 16/9; /* Set a fixed aspect ratio */
    }
    .news-card:hover img {
      transform: scale(1.05);
    }

    .card-title {
      display: -webkit-box;
      -webkit-line-clamp: 2; /* Limit to 2 lines */
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      /* Optional: add additional styling as needed */
    }
    .card-text {
      font-size: 18px;
      line-height: 1.6;
      color: #666;
    }
    .news-head {
      font-weight: 700;
      color: #054D94;
    }

    .page-link{
        z-index: 0 !important;
    }
    
  </style>

    <section id="news-archives" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center news-head mb-4">News & Events</h2>
            <div class="row justify-content-between mb-4">
                <div class="col-md-6 mb-2">
                    <div class="dropdown categories">
                        <button class="btn btn btn-outline-primary dropdown-toggle w-100 d-flex justify-content-between align-items-center btn-dropdown position "  type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        {{ $categories[$category] ?? 'Select Category' }}
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            @foreach($categories as $key => $cat)
                                <li><a class="dropdown-item" href="{{ route('news.archives', ['category' => $key]) }}" {{ $key === $category ? 'aria-current="true"' : '' }}>
                                    {{ $cat }}
                                </a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <form action="{{ route('news.archives') }}" method="GET" class="d-flex">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search News..." value="{{ request('search') }}">
                        <input type="hidden" name="category" value="{{ $category }}">
                        <button type="submit" class="btn btn-primary ">Search</button>
                    </form>
                </div>
            </div>

            <div id="newsContainer" class="row">
              @forelse ($news as $item)
                  <div class="newscard col-md-3 mb-4">
                      <a href="{{ route('news.view', $item->slug) }}" class="news-card-link text-decoration-none">
                          <div class="news-card" data-category="{{ $item->category }}">
                              <img src="{{ asset('storage/' . $item->image) }}" class="card-img-top" alt="News Image">
                              <div class="card-body p-3 bg-white">
                                  <h6 class="card-title mb-2 text-decoration-underline">{{ $item->title }}</h6>
                                  <p class="card-date small m-0 text-muted">{{ $item->published_at->format('F j, Y') }}</p>
                              </div>
                          </div>
                      </a>
                  </div>
                  @empty
                <div class="col-12">
                    <p id="emptyMessage" class="text-center">No news records found.</p>
                </div>
              @endforelse
          </div>


              <!-- Pagination Links -->
       <div class="container mb-5">
            {{ $news->appends(['search' => request()->query('search')])->links('pagination::bootstrap-5') }}
        </div>

        </div>
    </section>
@endsection

