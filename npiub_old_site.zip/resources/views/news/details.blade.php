@extends('layouts.default')

@section('title', $news->title . ' - News Details - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    <style>
        .news-article {
            margin: 0 auto;
        }

        .news-detail-container {
            background-color: #fff;
        }

        .news-detail-header h1 {
            font-size: 2rem;
            color: #054D94;
            margin-bottom: 1rem;
        }

        .news-detail-header .news-date {
            font-size: 1rem;
            color: #6c757d;
            text-decoration: none; /* Remove underline from news date */
        }

        .news-detail-content {
            line-height: 1.8;
            font-size: 1.1rem;
            text-align: justify;
        }

        .news-detail-img {
            width: 100%;
            height: auto;
            margin-bottom: 1.5rem;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .news-author {
            display: flex;
            align-items: center;
            margin-top: 2rem;
            border-top: 1px solid #6c757d;
            padding-top: 2rem;
        }

        .news-author img {
            border-radius: 50%;
            width: 70px;
            height: 70px;
            margin-right: 1.5rem;
        }

        .news-author .author-info {
            font-size: 1.1rem;
            color: #054D94;
        }

        .related-article {}

        .related-news {
            /* padding: 2rem 0; */
        }

        .related-news h3 {
            font-size: 1.8rem;
            color: #054D94;
            margin-bottom: 1.5rem;
        }

        .related-item {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            padding: 0.8rem;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease; /* Add smooth hover effect */
            cursor: pointer;
        }

        .related-item:hover {
            transform: translateY(-5px); /* Lift up on hover */
        }

        .related-item img {
            width: 90px;
            height: auto;
            aspect-ratio: 16/16; /* Set a fixed aspect ratio */
            object-fit: cover;
            margin-right: 1.5rem;
        }

        .related-item h4 {
            font-size: 1.1rem;
            color: #054D94;
        }

        .related-item p {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 0;
        }

        .related-title {
      display: -webkit-box;
      -webkit-line-clamp: 3; /* Limit to 2 lines */
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      /* Optional: add additional styling as needed */
    }

        .back-to-archives {
            display: block;
            margin-top: 2rem;
            color: #007bff;
            transition: color 0.3s;
            text-align: center;
        }

        .back-to-archives:hover {
            color: #054D94;
        }
    </style>


    <div class="container news-detail-container">
        <div class="row">
            <div class="col-md-8 p-3 news-article">
                <div class="news-detail-header">
                    <h1>{{ $news->title }}</h1>
                    <p class="news-date">{{ $news->published_at->format('F j, Y') }}</p>
                </div>
                <!-- Display the news image -->
                <img src="{{ asset('storage/' . $news->image) }}" alt="News Image" class="news-detail-img">
                <div class="news-detail-content mb-5">
                    {!! nl2br(e($news->content)) !!}
                </div>

                <!-- Social Media Sharing -->
                <div class="social-share">
                    <!-- ShareThis buttons -->
                    <div class="sharethis-inline-share-buttons"></div>
                </div>

                <!-- Author Section -->
                <div class="news-author">
                    <img src="{{ asset('storage/' . $news->author_image) }}" alt="Author Image">
                    <div class="author-info">
                        <strong>{{ $news->author_name }}</strong><br>
                        <span>{{ $news->author_info }}</span>
                    </div>
                </div>
            </div>

            <div class="col-md-4 p-3 related-article">
                <!-- Related News -->
                <div class="related-news">
                    <h3>Related News</h3>
                    @foreach ($relatedNews as $item)
                        <a href="{{ route('news.view', $item->slug) }}" class="related-item text-decoration-none">
                            <img src="{{ asset('storage/' . $item->image) }}" alt="Related News Image">
                            <div class="related-item-info">
                                <h4 class="text-decoration-underline related-title">{{ $item->title }}</h4>
                                <p>{{ $item->published_at->format('F j, Y') }}</p>
                            </div>
                        </a>
                    @endforeach
                    <a href="{{ route('news.archives') }}" class="back-to-archives">Back to News Archives</a>
                </div>
            </div>
        </div>
    </div>

    <!-- <script>
        $(document).ready(function () {
            $('.related-title').each(function () {
                var title = $(this);
                if (title.text().length > 50) {
                    title.text(title.text().substring(0, 60) + '...');
                }
            });
        });
    </script> -->

@endsection

