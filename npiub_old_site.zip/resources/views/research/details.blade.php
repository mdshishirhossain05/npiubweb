<!DOCTYPE html>
<html>
<head>
    <title>{{ $research->title }}</title>
  <link rel="icon" type="image/x-icon" href="{{ asset('images/logo/logo_npiub.ico') }}">
    <!-- Add necessary CSS or include your stylesheet -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=6684098fa88bfa0019b9372b&product=inline-share-buttons&source=platform" async="async"></script>
    <style>
        .research-article {
            margin: 0 auto;
        }

        .research-detail-container {
            background-color: #fff;
        }

        .research-detail-header h1 {
            font-size: 2rem;
            color: #054D94;
            margin-bottom: 1rem;
        }

        .research-detail-header .research-date {
            font-size: 1rem;
            color: #6c757d;
            text-decoration: none; /* Remove underline from research date */
        }

        .research-detail-content {
            line-height: 1.8;
            font-size: 1.1rem;
            text-align: justify;
        }

        .research-detail-img {
            width: 100%;
            height: auto;
            margin-bottom: 1.5rem;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .research-author {
            display: flex;
            align-items: center;
            margin-top: 2rem;
            border-top: 1px solid #6c757d;
            padding-top: 2rem;
        }

        .research-author img {
            border-radius: 50%;
            width: 70px;
            height: 70px;
            margin-right: 1.5rem;
        }

        .research-author .author-info {
            font-size: 1.1rem;
            color: #054D94;
        }

        .related-article {}

        .related-research {
            /* padding: 2rem 0; */
        }

        .related-research h3 {
            font-size: 1.8rem;
            color: #054D94;
            margin-bottom: 1.5rem;
        }

        .related-item {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            padding: 0.8rem;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease; /* Add smooth hover effect */
            cursor: pointer;
        }

        .related-item:hover {
            transform: translateY(-5px); /* Lift up on hover */
        }

        .related-item img {
            width: 90px;
            height: auto;
            aspect-ratio: 16/16; /* Set a fixed aspect ratio */
            object-fit: cover;
            margin-right: 1.5rem;
        }

        .related-item h4 {
            font-size: 1.1rem;
            color: #054D94;
        }

        .related-item p {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 0;
        }

        .related-title {
      display: -webkit-box;
      -webkit-line-clamp: 3; /* Limit to 2 lines */
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      /* Optional: add additional styling as needed */
    }

        .back-to-archives {
            display: block;
            margin-top: 2rem;
            color: #007bff;
            transition: color 0.3s;
            text-align: center;
        }

        .back-to-archives:hover {
            color: #054D94;
        }
    </style>
</head>
<body>
@include('partials.header')
@include('partials.mobilehead')
    <div class="container research-detail-container">
        <div class="row">
            <div class="col-md-8 p-3 research-article">
                <div class="research-detail-header">
                    <h1>{{ $research->title }}</h1>
                    <p class="research-date">{{ $research->published_at->format('F j, Y') }}</p>
                </div>
                <!-- Display the research image -->
                <img src="{{ asset('storage/' . $research->image) }}" alt="Research Image" class="research-detail-img">
                <div class="research-detail-content mb-5">
                    {!! nl2br(e($research->content)) !!}
                </div>

                <!-- Social Media Sharing -->
                <div class="social-share">
                    <!-- ShareThis buttons -->
                    <div class="sharethis-inline-share-buttons"></div>
                </div>

                <!-- Author Section -->
                <div class="research-author">
                    <img src="{{ asset('storage/' . $research->author_image) }}" alt="Author Image">
                    <div class="author-info">
                        <strong>{{ $research->author_name }}</strong><br>
                        <span>{{ $research->author_info }}</span>
                    </div>
                </div>
            </div>

            <div class="col-md-4 p-3 related-article">
                <!-- Related Research -->
                <div class="related-research">
                    <h3>Related Research</h3>
                    @foreach ($relatedResearch as $item)
                        <a href="{{ route('research.view', $item->slug) }}" class="related-item text-decoration-none">
                            <img src="{{ asset('storage/' . $item->image) }}" alt="Related Research Image">
                            <div class="related-item-info">
                                <h4 class="text-decoration-underline related-title">{{ $item->title }}</h4>
                                <p>{{ $item->published_at->format('F j, Y') }}</p>
                            </div>
                        </a>
                    @endforeach
                    <a href="{{ route('research.archives') }}" class="back-to-archives">Back to Research Archives</a>
                </div>
            </div>
        </div>
    </div>

    <!-- <script>
        $(document).ready(function () {
            $('.related-title').each(function () {
                var title = $(this);
                if (title.text().length > 50) {
                    title.text(title.text().substring(0, 60) + '...');
                }
            });
        });
    </script> -->

    @include('partials.footer')
</body>
</html>
