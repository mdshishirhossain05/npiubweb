@extends('layouts.default')

@section('title', $officer->name . ' - Officer Details - NPIUB, North Pacific International University of Bangladesh')

@section('content')

<style>
        /* CSS styles */
        
        
         .officer-details-page {
        /* background: #f8f9fa; */
        padding-top: 5rem;
        color: #333;
    }

    .officer-details-page .container {
        position: relative;
        overflow: visible;
        padding-bottom: 3rem;
    }

        .officer-header {
            position: relative;
            padding-top: 4rem !important;
            padding: 2rem;
            background: linear-gradient(to right, #1d3557, #054D94);
            color: #fff;
            text-align: center;
            border: none;
            border-top: 4px solid #007BFF;
            border-radius: 0 0rem .5rem .5rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .officer-header img {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
            object-fit: cover;
            transition: transform 0.3s ease;
            border-radius: 50%;
            max-width: 150px;
            margin: 0 auto;
            position: absolute;
            top: -5rem;
            left: 50%;
            transform: translateX(-50%);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }

        .officer-header:hover img {
            transform: scale(1.03) translateX(-50%);
        }

        .officer-name {
            font-size: 1.6rem;
            font-weight: bold;
            margin-top: 15px;
            color: #fff;
        }

        .officer-position {
            font-size: 1rem;
            color: #d4e6f1;
        }

        .officer-contact {
            margin-top: 15px;
        }

        .officer-contact a {
            color: #d4e6f1;
            text-decoration: none;
        }

        .officer-body {
            background: #fff;
            padding: 4rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: -2rem;
        }

        .officer-section {
            margin-bottom: 2rem;
        }

        .officer-section h3 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #054D94;
            margin-bottom: 1rem;
            border-bottom: 2px solid #1d3557;
            padding-bottom: 0.5rem;
        }

        .officer-section p {
            font-size: 1rem;
            line-height: 1.6;
            color: #333;
        }

        .social {
            margin-top: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .social a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            background: #eff2f8;
            border-radius: 50%;
            text-decoration: none;
        }

        .social a i {
            color: #054D94;
            font-size: 16px;
            margin: 0 2px;
        }

        .social a:hover {
            background: #054D94;
        }

        .social a:hover i {
            color: #fff;
        }

        .social a+a {
            margin-left: 8px;
        }

        .officer-section .biography {
            text-align: justify;
        }
    </style>

<div id="officerDetails" class="p-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item"><a href="/department-{{ strtolower($officer->department) }}">Dept of {{ ($officer->department) }}</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ $officer->name }}</li>
        </ol>
    </nav>

    <div class="officer-details-page">
        <div class="container">
            <div class="officer-header">
                <img src="{{ asset('storage/' . $officer->image) }}" alt="Officer Image">
                <h2 class="officer-name">{{ $officer->name }}</h2>
                <p class="officer-position pb-2">{{ $officer->position }},
                                Dept. of {{ $officer->department }}, NPIUB</p>
                <div class="officer-contact">
                    <i class="fa-solid fa-phone"></i> <strong>Contact:</strong> <a href="tel:{{ $officer->contact }}">{{ $officer->contact }}</a>
                </div>
            </div>

            <div class="officer-body">
                <!-- Academic Background Section -->
                <div class="officer-section">
                    <h3><i class="fa-solid fa-graduation-cap"></i> Academic Background</h3>
                    <ul style="list-style-type: disc;">
                        @forelse(json_decode($officer->degrees, true) as $background)
                            <li><strong>{{ $background['degree_name'] }}</strong>
                                <p>{{ $background['degree_university'] }}</p>
                            </li>
                        @empty
                            <li>No academic background information available.</li>
                        @endforelse
                    </ul>
                </div>

                <!-- Biography Section -->
                <div class="officer-section biography">
                    <h3><i class="fa-solid fa-user"></i> Biography</h3>
                    <p>{{ $officer->biography }}</p>
                </div>

                <!-- Social Links -->
                <div class="officer-contact social mt-3">
                    @if($officer->facebook)
                        <a href="{{ $officer->facebook }}"><i class="fab fa-facebook"></i></a>
                    @endif
                    @if($officer->email)
                        <a href="mailto:{{ $officer->email }}"><i class="fas fa-envelope"></i></a>
                    @endif
                    @if($officer->linkedin)
                        <a href="{{ $officer->linkedin }}"><i class="fab fa-linkedin"></i></a>
                    @endif
                    @if($officer->whatsapp)
                        <a href="https://wa.me/{{ $officer->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection


