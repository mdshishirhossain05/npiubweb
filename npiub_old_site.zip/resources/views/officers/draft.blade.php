<style>
    .officers-section {
        background: linear-gradient(to right, #1d3557, #054D94);
        padding: 3rem !important;
        color: #000;
        display: block;
        position: relative;
    }

    .officers-section::before {
    content: "";
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 80%; /* Set the border width to 50% */
    height: 4px; /* Adjust the height for the thickness of the border */
    background-color: #ffffff; /* Adjust the color as needed */
}

    .section-title {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 30px;
        color: #fff;
    }

    .officers-grid {
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }

    .officer-card {
        background-color: #fff;
        border: 1px solid #457b9d;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        display: flex;
        transition: all 0.3s ease;
        align-items: center;
    }

    .officer-card:hover {
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .officer-image {
        overflow: hidden;
        align-items: center;
        max-width: 180px;
        aspect-ratio: 1/1;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 50%;
    }

    .officer-image img {
        object-fit: cover;
        border-radius: 50%;
        aspect-ratio: 4/4;
    }

    .officer-details {
        padding: 20px;
    }

    .officer-name {
        font-size: 1.5rem;
        font-weight: bold;
        color: #000;
        margin-bottom: 5px;
    }

    .officer-position,
    .officer-department {
        font-size: 1rem;
        color: #333;
        border-bottom: 1px solid #054D94;
        display: inline-block;
    }

    .officer-contact {
        margin-top: 15px;
        color: #000;
    }

    .social {
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
    }
    
    .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration: none;
    }
    
    .social a i {
        color: #054D94;
        font-size: 16px;
    }
    
    .social a:hover {
        background: #054D94;
    }
    
    .social a:hover i {
        color: #fff;
    }
    
    .social a+a {
        margin-left: 8px;
    }

    @media (max-width: 767px) {
        .officer-card {
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        .officer-card img {
            margin-bottom: 20px;
        }
        .social {
            justify-content: center;
        }
    }
</style>

<section class="officers-section p-3">
    <div class="container">
        <h2 class="section-title">Meet Our Officers</h2>
        <div class="officers-grid">
            @forelse($officers as $index => $officer)
                <div class="row justify-content-center officer-card-wrapper" @if($index >= 3) style="display: none;" @endif>
                    <div class="officer-card col-md-8 mb-4">
                        <div class="officer-image m-2">
                            @if($officer->image)
                                <img src="{{ asset('storage/' . $officer->image) }}" alt="{{ $officer->name }}">
                            @else
                                <img src="{{ asset('storage/default-image.jpg') }}" alt="Default Image">
                            @endif
                        </div>
                        <div class="officer-details">
                            <h3 class="officer-name">{{ $officer->name }}</h3>
                            <p class="officer-position pb-2">{{ $officer->position }}, Dept. of {{ $officer->department }}, NPIUB</p>

                            <!-- Academic Background Section -->
                            @if($officer->degrees)
                                <div class="academic-background">
                                    <strong><i class="fa-solid fa-graduation-cap"></i> Academic Background:</strong>
                                    <ul style="list-style-type: disc;">
                                        @foreach(json_decode($officer->degrees, true) as $degree)
                                            <!-- <li>{{ $degree['degree_name'] }}, {{ $degree['degree_university'] }}</li> -->
                                            <li><strong>{{ $degree['degree_name'] }},</strong>
                                                {{ $degree['degree_university'] }}
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            
                            <div class="officer-contact">
                                <i class="fa-solid fa-phone"></i> <strong>Contact:</strong> <a href="tel:{{ $officer->contact }}">{{ $officer->contact }}</a>
                            </div>
                            <div class="officer-contact social mt-3">
                                @if($officer->facebook)
                                    <a href="{{ $officer->facebook }}"><i class="fab fa-facebook"></i></a>
                                @endif
                                @if($officer->email)
                                    <a href="mailto:{{ $officer->email }}"><i class="fas fa-envelope"></i></a>
                                @endif
                                @if($officer->linkedin)
                                    <a href="{{ $officer->linkedin }}"><i class="fab fa-linkedin"></i></a>
                                @endif
                                @if($officer->whatsapp)
                                    <a href="https://wa.me/{{ $officer->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                                @endif
                            </div>
                            <!-- <div class="">
                                <a href="{{ route('officers.view', $officer->slug) }}">
                                    <button class="btn btn-primary officer-btn mt-3">View More</button>
                                </a>
                            </div> -->
                        </div>
                    </div>
                </div>
            @empty
                <p class="text-center text-light">No officers found.</p>
            @endforelse
        </div>
        @if(count($officers) > 3)
            <div class="text-center">
                <button id="see-more" class="btn btn-primary mt-3">See More</button>
                <button id="see-less" class="btn btn-secondary mt-3" style="display: none;">See Less</button>
            </div>
        @endif
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    $(document).ready(function() {
        $('#see-more').click(function() {
            $('.officer-card-wrapper').slice(3).slideDown();
            $('#see-more').hide();
            $('#see-less').show();
        });

        $('#see-less').click(function() {
            $('.officer-card-wrapper').slice(3).slideUp();
            $('#see-more').show();
            $('#see-less').hide();
        });
    });
</script>
