
  
  <style>
    /* Custom styles */

    #galleries{
      /* background-color: #ffffff !important; */
      /*background-image: url("https://www.transparenttextures.com/patterns/cream-pixels.png");*/

      padding: 2rem 0 0;


    }

    .galleries-container {
      position: relative; /* Ensure relative positioning for absolute positioning of pagination */
      /* border: 1px solid red; */
      padding: 6rem 1rem;
      overflow: hidden;
      
    }
    .galleries-pagination {
      position: absolute; /* Position the pagination dots */
      bottom: 0 !important; /* Adjust as per your requirement */
      
    }
    
    
    .swiper-slide {
      /* padding: 0 10px; Adjust padding to maintain spacing */
      
    }

    .swiper-button-prev:after,
 .swiper-button-next:after {
   --swiper-navigation-size: 1rem;
 }


 .swiper-button-prev,
.swiper-button-next {
  background: rgba(0, 123, 255, 0.5); /* Reduced opacity */
  width: 2.8rem;
  height: 2.8rem;
  color: #fff; /* Text color of the buttons */
  border-radius: 50%; /* Make the buttons circular */
  cursor: pointer; /* Change cursor to pointer on hover */
  z-index: 10; /* Ensure buttons are above other elements */
  transition: background-color 0.3s; /* Smooth transition */
}

.swiper-button-prev:hover,
.swiper-button-next:hover {
  background: rgba(0, 123, 255, 1); /* Full opacity on hover */
}

    
    .swiper-button-prev {
      left: 5px; /* Position the previous button */
    }
    .swiper-button-next {
      right: 5px; /* Position the next button */
    }
    .swiper-slide {
      padding: 0 10px; /* Adjust padding to maintain spacing */
    }


    .galleries-head{
        font-weight: 700;
        color: #054d94;
    }

    .slide {
      position: relative;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      
    }

    .slide:hover {
      transform: translateY(-10px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    .slide-body img {
      border-top: 3px solid rgba(0, 123, 255, 1);
      border-bottom: 3px solid rgba(0, 123, 255, 1);
      display: inline-block;
      aspect-ratio: 16/9;
    }

    .gallary-head {
      font-weight: 700;
      color: #054d94;
    }

    .swiper-slide-active .slide {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      transform: scale(1.6);  
      /* margin-bottom: 2rem; */
    }

   

    .swiper-slide-active {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .swiper-slide-active:hover {
      transform: translateY(-10px);
    }

    @media (max-width: 768px) {

      .swiper-slide-active .slide {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      transform: scale(1);  
      /* margin-bottom: 2rem; */
    }

    .galleries-container {
      position: relative; /* Ensure relative positioning for absolute positioning of pagination */
      /* border: 1px solid red; */
      padding:1rem 1rem 3rem;
      overflow: hidden;
      
    }
     
    }
  </style>

@php
    $departmentName = ucfirst($department ?? 'department');
@endphp
    <section id="galleries" class="bg-light text-dark">
        <h2 class="text-center galleries-head mb-3">Galleries, Dept. of {{ $departmentName }}, NPIUB</h2> <!-- Section Heading -->
        <div class="container-fluid"> 
            <div class="swiper-container galleries-container">
                <div class="swiper-wrapper text-center">
                
                @foreach($latestGallery as $galleries)
                  <div class="swiper-slide">
                    <div class="slide">
                      <div class="slide-body">
                        <a href="{{ asset('storage/' . $galleries->image) }}" data-fancybox="gallery" data-caption="{{ $galleries->title }}">
                        <img src="{{ asset('storage/' . $galleries->image) }}" class="img-fluid" alt="Galleries Image">
                        </a>
                      </div>
                    </div>
                  </div>
                  @endforeach
                
                </div>
                <!-- Add pagination -->
                <div class="swiper-pagination galleries-pagination"></div>
                <!-- Add navigation buttons -->
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
                
            </div>

            <div class="text-center">
            <a href="{{ route('galleries.galleries') }}"><button class="btn btn-primary galleries-btn mt-4 mb-5">Galleries Archives</button></a> <!-- Search Archives Button -->
        </div>
        </div>
    </section>

 

    <script>
    var swiper = new Swiper('.galleries-container', {
      slidesPerView: 4,
      spaceBetween: 100,
      centeredSlides: true, // Center the active slide
      loop: true, // Enable loop
      
      autoplay: {
        delay: 2500,
        disableOnInteraction: true,
      },
      keyboard: {
        enabled: true,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
        // dynamicBullets: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
     
      breakpoints: {
        992: {
          slidesPerView: 3,
        },
        768: {
          slidesPerView: 2,
        },
        0: {
          slidesPerView: 1,
        },
      },
    });

    Fancybox.bind("[data-fancybox]", {
  // Your custom options
  Carousel: {
    transition: "slide",
  },
});
  </script>

