
    <style>
    /* Custom styles */

    .gallery-body img{
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .dropdown-menu {
        width: 100%;
        border: none;
        border-radius: 0.25rem;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        --bs-dropdown-padding-y: 0;
        
    }
    .dropdown-item {
        padding: .8rem !important;
        transition: background-color 0.3s, color 0.3s;
      
    }
    .dropdown-item:hover {
        background-color: #054D94;
        color: white;
    }
    .dropdown-toggle::after {
        transition: transform 0.3s;
    }
    .dropdown-toggle.collapsed::after {
        /* transform: rotate(180deg); */
    }

      
    
    .galleries-head {
        font-weight: 700;
        color: #054d94;
    }
    
    .gallery-body img{
        aspect-ratio: 16/9;
    }
        
    </style>

    <section id="galleries-archives" class="bg-light py-5 ">
        <div class="container">
            <h2 class="text-center galleries-head mb-4">Explore Our Galleries</h2>
            <div class="row justify-content-between dropdown-search  mb-5">
            <div class="col-md-6">
                    <div class="dropdown departments">
                        <button class="btn btn-outline-primary dropdown-toggle w-100 d-flex justify-content-between align-items-center btn-dropdown position" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            {{ $departments[$department] ?? 'Select Department' }}
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            @foreach($departments as $key => $dept)
                                <li><a class="dropdown-item" href="{{ route('galleries.galleries', ['department' => $key]) }}" {{ $key === $department ? 'aria-current="true"' : '' }}>
                                    {{ $dept }}
                                </a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <form action="{{ route('galleries.galleries') }}" method="GET" class="d-flex">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search Galleries..." value="{{ request('search') }}">
                        <input type="hidden" name="department" value="{{ $department }}">
                        <button type="submit" class="btn btn-primary ">Search</button>
                    </form>
                </div>
            </div>

            <div id="galleriesContainer" class="row">
                @php
                    $departmentNames = [
                        'cse' => 'CSE',
                        'eee' => 'EEE',
                        'food-eng' => 'Food Engineering',
                        'bba' => 'BBA',
                        'mba' => 'MBA',
                        'english' => 'B.A in English'
                    ];
                @endphp

                    @forelse ($galleries as $item)
                    <div class="gallery-body col-md-4 mb-4">
                        <a href="{{ asset('storage/' . $item->image) }}" data-fancybox="gallery" data-caption="{{ $item->title }}">
                        <img src="{{ asset('storage/' . $item->image) }}" class="img-fluid" alt="Galleries Image">
                        </a>
                    </div>
                        @empty
                        <div class="col-12">
                    <p id="emptyMessage" class="text-center">No news records found.</p>
                </div>
              @endforelse
            </div>


            <!-- Pagination Links -->
            <div class="container mb-5">
                {{ $galleries->appends(['search' => request()->query('search')])->links('pagination::bootstrap-5') }}
            </div>

        </div>
    </section>


    <script>

    Fancybox.bind("[data-fancybox]", {
        // Your custom options
        Carousel: {
            transition: "slide",
        },
    });
</script>


