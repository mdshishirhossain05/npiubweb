@extends('layouts.default')

@section('title', 'Galleries Archives - NPIUB, North Pacific International University of Bangladesh')

@section('content')
    @include('galleries.gallery')
@endsection
