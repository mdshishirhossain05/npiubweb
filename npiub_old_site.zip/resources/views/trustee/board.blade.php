@extends('layouts.default')

@section('title', 'Board of Trustee - NPIUB, North Pacific International University of Bangladesh')

@section('content')

@include('trustee.trustee')
@endsection