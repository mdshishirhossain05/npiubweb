<div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="display-4 fw-bold text-dark">Board of Trustees</h1>
        <p class="lead text-secondary">
            The governance of NPI University of Bangladesh is entrusted to a distinguished panel of visionaries and thought leaders.
        </p>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
        @php
            $trustees = [
                ['title' => 'Chairman (BOT)', 'name' => 'Engr. Md. Shamsur Rahman', 'phone' => '01711-349947', 'email' => 'mdsrahman1953@gmail.com', 'image' => 'trustees/1.  Md. Shamsur Rahman.jpg'],
                ['title' => 'Vice-Chairman (BOT)', 'name' => 'Mahadev Kundu', 'phone' => '01973-014547', 'email' => 'mahadebkundu071@gmail.com', 'image' => 'trustees/2. Mahadev Kundu.jpg'],
                ['title' => 'Vice-Chairman (BOT)', 'name' => 'Md. Zakir Hossain', 'phone' => '01715-651300', 'email' => 'zhossain286@gmail.com', 'image' => 'trustees/3. Md. Zakir Hossain.jpg'],
                ['title' => 'Member Secretary (BOT)', 'name' => 'Engr. Nirmal Chandra Sikder', 'phone' => '01711-240266', 'email' => 'ncsikder@gmail.com', 'image' => 'trustees/4. Nirmal Sikder.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Freedom Fighter Engr. Md. Idris Ali', 'phone' => '01711-855030', 'email' => '56aliidris@gmail.com', 'image' => 'trustees/5. Freedom Fighter  Engr. Md. Idris Ali.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'FMA Salam', 'phone' => '01704-444888', 'email' => 'salamfma888@gmail.com', 'image' => 'trustees/6. FMA Salam.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Mohammod Faruque Hossain', 'phone' => '01735-782829', 'email' => 'faruquecontro@gmail.com', 'image' => 'trustees/8. Mohammad Faruque Hossain.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Md. Tariqul Islam', 'phone' => '01711-955385', 'email' => 'milon102@gmail.com', 'image' => 'trustees/10.Engr. Md. Tariqul Islam.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Md. Mahbubul Alam', 'phone' => '01712-136580', 'email' => 'mahbubalam72004@gmail.com', 'image' => 'trustees/11. Engr. Md. Mahbubul Alam.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Md. Asif Idris', 'phone' => '01738-194690', 'email' => 'mdasif172@gmail.com', 'image' => 'trustees/12. Engr. Md. Asif Idris.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Argha Sikder Saurav', 'phone' => '01834-634610', 'email' => 'ssargha@gmail.com', 'image' => 'trustees/13. Engr. Argha Sikder Saurav.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Mohammad Arafat Idris', 'phone' => '01971-855030', 'email' => 'arafat.idris.porosh@gmail.com', 'image' => 'trustees/13.2Engr. Mohammad Arafat Idris.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'A S M Shakib Rahman', 'phone' => '01886-969365', 'email' => 'asmshakibrahman@gmail.com', 'image' => 'trustees/14. Engr. A S M Shakib Rahman.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Md. Zahidul Islam', 'phone' => '01707-881780', 'email' => 'zahidislam600@gmail.com', 'image' => 'trustees/15. Engr. Md. Zahidul Islam.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Aurnob Kundu', 'phone' => '017950-41664', 'email' => 'aurnob6577@gmail.com', 'image' => 'trustees/16.Aurnob Kundu.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Afrin Haque Moni', 'phone' => '01704-444888', 'email' => 'haqueafrin233@gmail.com', 'image' => 'trustees/17. Afrin Haque Moni.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'Engr. Nargish Pervin', 'phone' => '01716-816240', 'email' => 'rinamollick123@gmail.com', 'image' => 'trustees/18.Engr. Nargis Parvin.jpg'],
                ['title' => 'Member (BOT)', 'name' => 'S M Kamruzzaman', 'phone' => '017115-62078', 'email' => 'tradeportbd@gmail.com', 'image' => 'trustees/19. S M Kamruzzaman.jpg'],
            ];
        @endphp

        @foreach ($trustees as $trustee)
            <div class="col">
                <div class="card border-0 shadow-sm h-100 trustee-card text-center">
                    <img src="{{ asset('images/' . $trustee['image']) }}"
                         class="card-img-top trustee-img"
                         alt="{{ $trustee['name'] }}">
                    <div class="card-body">
                        <h5 class="fw-bold text-dark mb-1">{{ $trustee['name'] }}</h5>
                        <p class="text-primary small mb-2">{{ $trustee['title'] }}</p>
                        <p class="mb-1">
                            <i class="bi bi-telephone-fill me-1 text-secondary"></i>
                            <a href="tel:{{ $trustee['phone'] }}" class="text-decoration-underline text-dark">
                                {{ $trustee['phone'] }}
                            </a>
                        </p>
                        <p>
                            <i class="bi bi-envelope-fill me-1 text-secondary"></i>
                            <a href="mailto:{{ $trustee['email'] }}" class="text-decoration-underline text-dark">
                                {{ $trustee['email'] }}
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<style>
    .trustee-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .trustee-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.75rem 1.5rem rgba(0, 0, 0, 0.1);
    }

    .trustee-img {
        height: 300px;
        object-fit: cover;
        border-bottom: 4px solid #0d6efd;
    }

    @media (max-width: 768px) {
        .trustee-img {
            height: 100%;
        }
    }
</style>
