@extends('layouts.default')

@section('content')
    @include('partials.slider', ['latestGallery' => $latestGallery])
    @include('partials.npiub_numbers')
    @include('partials.news_events', ['latestNews' => $latestNews])
    @include('partials.our_research', ['latestResearch' => $latestResearch])
    @include('partials.our_leadership')
    @include('partials.our_faculties')
    @include('partials.our_alumni', ['latestAlumni' => $latestAlumni])
@endsection

