<x-mail::message>
# Hello, {{ $user->name }}

You have been added as a {{ $role }} to our system. Please click the button below to set your password:

<x-mail::button :url="$url" color="primary">
Set Your Password
</x-mail::button>

If you did not request this action, you can ignore this email.

Regards,  
{{ config('app.name') }}

<x-slot:subcopy>
If you're having trouble clicking the "Set Your Password" button, copy and paste the URL below into your web browser:  
[{{ $url }}]({{ $url }})
</x-slot:subcopy>
</x-mail::message>
