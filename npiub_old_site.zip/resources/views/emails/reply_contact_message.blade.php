<x-mail::message>
# Hello, {{ $contactName }}

Thank you for reaching out to us! We appreciate your inquiry and are here to help.

### Your Message:
<em>"{{ $originalMessage }}"</em>

### Our Response:
{{ $replyMessage }}

@if ($attachmentPath)
### Attachment:
Download the attachment by clicking the link below:
- [Download File]({{ asset('storage/' . $attachmentPath) }})
@endif

If you have any further questions or need additional assistance, please don't hesitate to reply to this email or contact our support team.

<x-mail::button :url="url('/contact')">
Contact Support
</x-mail::button>

Best Regards,  
**{{ config('app.name') }} Support Team**

---

### Stay Connected:
Thank you for being a valued member of our community.  
If you have trouble viewing this email, you can access it online: [View Email](#)

Follow us on [Facebook](https://www.facebook.com/yourpage) | [Twitter](https://twitter.com/yourpage) | [Instagram](https://www.instagram.com/yourpage)

<x-slot:subcopy>
If you're having trouble clicking the buttons above, copy and paste the URL below into your web browser:  
[{{ url('/contact') }}]({{ url('/contact') }})
</x-slot:subcopy>
</x-mail::message>
