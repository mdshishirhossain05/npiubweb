
<style>
    .faculties-section {
        /* background-color: red; */
    background: linear-gradient(to right, #1d3557, #054D94);
    padding: 3rem  !important;
    color: #333;
    display: block;
}

.section-title {
    text-align: center;
    font-size: 2.5rem;
    margin-bottom: 30px;
    color: #fff;
}

.faculties-grid {
    /* display: flex; */
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
}

.faculty-card {
    background-color: #fff;
    border: 1px solid #457b9d;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    display: flex;
    transition: all 0.3s ease;
    align-items: center;
}

.faculty-card:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.faculty-image {
    overflow: hidden;
    align-items: center;
    max-width: 180px;
    aspect-ratio: 1/1;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 50%;
}

.faculty-image img {
    object-fit: cover;
    border-radius: 50%;
    /* border: 4px solid #fff; */
    aspect-ratio: 4/4;
}

.faculty-details {
  
    padding: 20px;
}

.faculty-name {
    font-size: 1.5rem;
    font-weight: bold;
    color: #054D94;
    margin-bottom: 5px;
}

.faculty-position,
.faculty-department {
    font-size: 1rem;
    color: #333;
    border-bottom: 1px solid #054D94;
    display: inline-block;
}

.faculty-contact {
    margin-top: 15px;
    color: #054D94;
}

.social {
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        }
        
        .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration:none;
        }
        
        .social a i {
        color: #054D94;
        font-size: 16px;
        margin: 0 2px;
        }
        
       .social a:hover {
        background: #054D94;
        }
        
        .social a:hover i {
        color: #fff;
        }
        
        .social a+a {
        margin-left: 8px;
        }

    @media (max-width: 767px) {
    .faculty-card {
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    .faculty-card img {
        margin-bottom: 20px;
        margin-right: 0;
    }
    .social {
        justify-content: center;
    }
</style>
<section class="faculties-section p-3">
    <div class="container">
        <h2 class="section-title">Meet Our Faculty</h2>
        <div class="faculties-grid">
            @forelse($faculties as $index => $faculty)
                <div class="row justify-content-center faculty-card-wrapper" @if($index >= 3) style="display: none;" @endif>
                    <div class="faculty-card col-md-8 mb-4">
                        <div class="faculty-image m-2">
                            @if($faculty->image)
                                <img src="{{ asset('storage/' . $faculty->image) }}" alt="{{ $faculty->name }}">
                            @else
                                <img src="{{ asset('storage/default-image.jpg') }}" alt="Default Image">
                            @endif
                        </div>
                        <div class="faculty-details">
                            <h3 class="faculty-name">{{ $faculty->name }}</h3>
                            <p class="faculty-position pb-2">{{ $faculty->position }}, Dept. of {{ $faculty->department }}, NPIUB</p>
                            <div class="faculty-contact">
                                <i class="fa-solid fa-phone"></i> <strong>Contact:</strong> <a href="tel:{{ $faculty->contact }}">{{ $faculty->contact }}</a>
                            </div>
                            <div class="faculty-contact social mt-3">
                                @if($faculty->facebook)
                                    <a href="{{ $faculty->facebook }}"><i class="fab fa-facebook"></i></a>
                                @endif
                                @if($faculty->email)
                                    <a href="mailto:{{ $faculty->email }}"><i class="fas fa-envelope"></i></a>
                                @endif
                                @if($faculty->linkedin)
                                    <a href="{{ $faculty->linkedin }}"><i class="fab fa-linkedin"></i></a>
                                @endif
                                @if($faculty->whatsapp)
                                    <a href="https://wa.me/{{ $faculty->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                                @endif
                            </div>
                            <div class="">
                                <a href="{{ route('faculties.view', $faculty->slug) }}">
                                    <button class="btn btn-primary faculty-btn mt-3">View More</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <p class="text-center text-light">No faculties found.</p>
            @endforelse
        </div>
        @if(count($faculties) > 3)
            <div class="text-center">
                <button id="see-more" class="btn btn-primary mt-3">See More</button>
                <button id="see-less" class="btn btn-secondary mt-3" style="display: none;">See Less</button>
            </div>
        @endif
    </div>
</section>


<script>
    $(document).ready(function() {
        $('#see-more').click(function() {
            $('.faculty-card-wrapper').slice(3).slideDown();
            $('#see-more').hide();
            $('#see-less').show();
        });

        $('#see-less').click(function() {
            $('.faculty-card-wrapper').slice(3).slideUp();
            $('#see-more').show();
            $('#see-less').hide();
        });
    });
</script>

