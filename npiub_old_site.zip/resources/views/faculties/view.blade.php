@extends('layouts.default')

@section('title', $faculty->name . ' - Faculty Details - NPIUB, North Pacific International University of Bangladesh')

@section('content')

<style>
    .faculty-details-page {
        padding-top: 5rem;
        color: #333;
    }

    .faculty-details-page .container {
        position: relative;
        overflow: visible;
        padding-bottom: 3rem;
    }

    .faculty-header {
        position: relative;
        padding-top: 4rem !important;
        padding: 2rem;
        background: linear-gradient(to right, #1d3557, #054D94);
        color: #fff;
        text-align: center;
        border: none;
        border-top: 4px solid #007BFF;
        border-radius: 0 0 .5rem .5rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .faculty-header img {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        object-fit: cover;
        transition: transform 0.3s ease;
        border-radius: 50%;
        max-width: 150px;
        margin: 0 auto;
        position: absolute;
        top: -5rem;
        left: 50%;
        transform: translateX(-50%);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
    }

    .faculty-header:hover img {
        transform: scale(1.03) translateX(-50%);
    }

    .faculty-name {
        font-size: 1.6rem;
        font-weight: bold;
        margin-top: 15px;
        color: #fff;
    }

    .faculty-position {
        font-size: 1rem;
        color: #d4e6f1;
    }

    .faculty-contact {
        margin-top: 15px;
    }

    .faculty-contact a {
        color: #d4e6f1;
        text-decoration: none;
    }

    .faculty-body {
        background: #fff;
        padding: 4rem;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-top: -2rem;
    }

    .faculty-section {
        margin-bottom: 2rem;
    }

    .faculty-section h3 {
        font-size: 1.5rem;
        font-weight: bold;
        color: #054D94;
        margin-bottom: 1rem;
        border-bottom: 2px solid #1d3557;
        padding-bottom: 0.5rem;
    }

    .faculty-section p {
        font-size: 1rem;
        line-height: 1.6;
        color: #333;
    }

    .social {
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration: none;
    }

    .social a i {
        color: #054D94;
        font-size: 16px;
        margin: 0 2px;
    }

    .social a:hover {
        background: #054D94;
    }

    .social a:hover i {
        color: #fff;
    }

    .social a + a {
        margin-left: 8px;
    }

    .research-name {
        margin-bottom: 1rem;
    }

    .faculty-section .biography {
        text-align: justify;
    }
</style>

<section id="facultyDetails" class="bg-light p-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">
                <a href="/departments/{{ strtolower($faculty->department) }}">
                    Dept of {{ $faculty->department }}
                </a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">{{ $faculty->name }}</li>
        </ol>
    </nav>

    <div class="faculty-details-page">
        <div class="container">
            <div class="faculty-header">
                @if($faculty->image)
                    <img src="{{ asset('storage/' . $faculty->image) }}" alt="{{ $faculty->name }}">
                @else
                    {{-- Optional placeholder --}}
                    <img src="{{ asset('images/default-avatar.png') }}" alt="{{ $faculty->name }}">
                @endif

                <h2 class="faculty-name">{{ $faculty->name }}</h2>
                <p class="faculty-position pb-2">
                    {{ $faculty->position }},
                    Dept. of {{ $faculty->department }}, NPIUB
                </p>

                @if($faculty->contact)
                    <div class="faculty-contact">
                        <i class="fa-solid fa-phone"></i>
                        <strong>Contact:</strong>
                        <a href="tel:{{ $faculty->contact }}">{{ $faculty->contact }}</a>
                    </div>
                @endif
            </div>

            <div class="faculty-body">
                {{-- Academic Background Section --}}
                <div class="faculty-section">
                    <h3><i class="fa-solid fa-graduation-cap"></i> Academic Background</h3>
                    <ul style="list-style-type: disc;">
                        @forelse($degrees as $background)
                            <li>
                                @if(!empty($background['degree_name']))
                                    <strong>{{ $background['degree_name'] }}</strong>
                                @endif

                                @if(!empty($background['degree_university']))
                                    <p class="mb-0">{{ $background['degree_university'] }}</p>
                                @endif

                                @if(!empty($background['degree_details']))
                                    <p class="mb-0">{{ $background['degree_details'] }}</p>
                                @endif
                            </li>
                        @empty
                            <li>No academic background information available.</li>
                        @endforelse
                    </ul>
                </div>

                {{-- Research Interests Section --}}
                <div class="faculty-section">
                    <h3><i class="fa-solid fa-microscope"></i> Research Interests</h3>
                    <ul style="list-style-type: disc;">
                        @forelse($researchInterests as $interest)
                            <li>
                                @if(is_array($interest))
                                    @if(!empty($interest['title']))
                                        <strong>{{ $interest['title'] }}</strong>
                                    @endif

                                    @if(!empty($interest['url']))
                                        <br>
                                        <a href="{{ $interest['url'] }}" target="_blank">
                                            {{ $interest['url'] }}
                                        </a>
                                    @endif

                                    @if(!empty($interest['description']))
                                        <p class="mb-0">{{ $interest['description'] }}</p>
                                    @endif
                                @else
                                    {{ $interest }}
                                @endif
                            </li>
                        @empty
                            <li>No research interests available.</li>
                        @endforelse
                    </ul>
                </div>

                {{-- Biography Section --}}
                <div class="faculty-section biography">
                    <h3><i class="fa-solid fa-user"></i> Biography</h3>
                    <p>{!! nl2br(e($faculty->biography)) !!}</p>
                </div>

                {{-- Social Links --}}
                <div class="faculty-contact social mt-3">
                    @if($faculty->facebook)
                        <a href="{{ $faculty->facebook }}" target="_blank">
                            <i class="fab fa-facebook"></i>
                        </a>
                    @endif

                    @if($faculty->email)
                        <a href="mailto:{{ $faculty->email }}">
                            <i class="fas fa-envelope"></i>
                        </a>
                    @endif

                    @if($faculty->linkedin)
                        <a href="{{ $faculty->linkedin }}" target="_blank">
                            <i class="fab fa-linkedin"></i>
                        </a>
                    @endif

                    @if($faculty->whatsapp)
                        <a href="https://wa.me/{{ $faculty->whatsapp }}" target="_blank">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
