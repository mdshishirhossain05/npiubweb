@extends('layouts.default')

@section('title', $officeType . ' - Offices - NPIUB, North Pacific International University of Bangladesh')

@section('content')

    @include('offices.offices', ['offices' => $offices])
    
@endsection
    
    

