<style>
    .offices-section {
        background: linear-gradient(to right, #1d3557, #054D94);
        padding: 5rem 0 !important;
        color: #333;
        display: block;
    }

    .section-title {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 5rem;
        color: #fff;
    }

    .offices-grid {
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }

    .office-card {
        background-color: #fff;
        border: 1px solid #457b9d;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        display: flex;
        transition: all 0.3s ease;
        align-items: center;
    }

    .office-card:hover {
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .office-image {
        overflow: hidden;
        align-items: center;
        max-width: 180px;
        aspect-ratio: 1/1;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 50%;
    }

    .office-image img {
        object-fit: cover;
        border-radius: 50%;
        aspect-ratio: 4/4;
    }

    .office-details {
        padding: 20px;
    }

    .office-name {
        font-size: 1.5rem;
        font-weight: bold;
        color: #054D94;
        margin-bottom: 5px;
    }

    .office-position,
    .office-type {
        font-size: 1rem;
        color: #333;
        border-bottom: 1px solid #054D94;
        display: inline-block;
    }

    .office-contact {
        margin-top: 15px;
        color: #054D94;
    }

    .social {
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
    }
        
    .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration: none;
    }
        
    .social a i {
        color: #054D94;
        font-size: 16px;
        margin: 0 2px;
    }
        
    .social a:hover {
        background: #054D94;
    }
        
    .social a:hover i {
        color: #fff;
    }
        
    .social a+a {
        margin-left: 8px;
    }

    @media (max-width: 767px) {
        .office-card {
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        .office-card img {
            margin-bottom: 20px;
            margin-right: 0;
        }
        .social {
            justify-content: center;
        }
    }
</style>

<section class="offices-section p-3">
    <div class="container">
        <h2 class="section-title">Office of the {{ $officeType }}</h2>
        <div class="offices-grid">
            @forelse($offices as $index => $office)
                <div class="row justify-content-center office-card-wrapper" @if($index >= 3) style="display: none;" @endif>
                    <div class="office-card col-md-8 mb-4">
                        <div class="office-image m-2">
                            @if($office->image)
                                <img src="{{ asset('storage/' . $office->image) }}" alt="{{ $office->name }}">
                            @else
                                <img src="{{ asset('storage/default-image.jpg') }}" alt="Default Image">
                            @endif
                        </div>
                        <div class="office-details">
                            <h3 class="office-name">{{ $office->name }}</h3>
                            <p class="office-position pb-2">{{ $office->position }}</p>
                            <div class="office-contact">
                                @if($office->contact)
                                <i class="fa-solid fa-phone"></i> <strong>Contact:</strong> <a href="tel:{{ $office->contact }}">{{ $office->contact }}</a>
                                @endif
                            </div>
                            <div class="office-contact social mt-3">
                                @if($office->facebook)
                                    <a href="{{ $office->facebook }}"><i class="fab fa-facebook"></i></a>
                                @endif
                                @if($office->email)
                                    <a href="mailto:{{ $office->email }}"><i class="fas fa-envelope"></i></a>
                                @endif
                                @if($office->linkedin)
                                    <a href="{{ $office->linkedin }}"><i class="fab fa-linkedin"></i></a>
                                @endif
                                @if($office->whatsapp)
                                    <a href="https://wa.me/{{ $office->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                                @endif
                            </div>
                            <div class="">
                                <a href="{{ route('offices.view', $office->slug) }}">
                                    <button class="btn btn-primary office-btn mt-3">View More</button>
                                </a>
                            </div> 
                        </div>
                    </div>
                </div>
            @empty
                <p class="text-center text-light">No offices found.</p>
            @endforelse
        </div>
        @if(count($offices) > 3)
            <div class="text-center">
                <button id="see-more" class="btn btn-primary mt-3">See More</button>
                <button id="see-less" class="btn btn-secondary mt-3" style="display: none;">See Less</button>
            </div>
        @endif
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    $(document).ready(function() {
        $('#see-more').click(function() {
            $('.office-card-wrapper').slice(3).slideDown();
            $('#see-more').hide();
            $('#see-less').show();
        });

        $('#see-less').click(function() {
            $('.office-card-wrapper').slice(3).slideUp();
            $('#see-more').show();
            $('#see-less').hide();
        });
    });
</script>
