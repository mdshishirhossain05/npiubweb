<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $office->name }} - Office Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .office-details-page { padding: 3rem 0; color: #333; }
        .office-details-page .container { position: relative; overflow: visible; padding-bottom: 3rem; }
        .office-header {
            position: relative; padding-top: 4rem !important; padding: 2rem;
            background: linear-gradient(to right, #1d3557, #054D94); color: #fff; text-align: center;
            border: none; border-top: 4px solid #007BFF; border-radius: 0 0 .5rem .5rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .office-header img {
           object-fit: cover;
        border-radius: 50%;
        aspect-ratio: 2/2;
        max-width: 150px;
        margin: 0 auto;
            position: absolute; top: -5rem; left: 50%; transform: translateX(-50%);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1); transition: transform 0.3s ease;
            
        }
        .office-header:hover img { transform: scale(1.03) translateX(-50%); }
        .office-name { font-size: 1.6rem; font-weight: bold; margin-top: 15px; color: #fff; }
        .office-position { font-size: 1rem; color: #d4e6f1; }
        .office-contact { margin-top: 15px; }
        .office-contact a { color: #d4e6f1; text-decoration: none; }
        .office-body {
            background: #fff; padding: 4rem; border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); margin-top: -2rem;
        }
        .office-section { margin-bottom: 2rem; }
        .office-section h3 {
            font-size: 1.5rem; font-weight: bold; color: #054D94;
            margin-bottom: 1rem; border-bottom: 2px solid #1d3557; padding-bottom: 0.5rem;
        }
        .office-section p { font-size: 1rem; line-height: 1.6; color: #333; }
        .social { margin-top: 12px; display: flex; align-items: center; justify-content: center; }
        .social a {
            display: flex; align-items: center; justify-content: center; width: 32px; height: 32px;
            background: #eff2f8; border-radius: 50%; text-decoration: none;
        }
        .social a i { color: #054D94; font-size: 16px; margin: 0 2px; }
        .social a:hover { background: #054D94; }
        .social a:hover i { color: #fff; }
        .social a+a { margin-left: 8px; }
        .office-section .biography { text-align: justify; }
    </style>
</head>
<body>

<div class="container pt-5 pb-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">
                @switch($office->type)
                    @case('Vice Chancellor') <a href="{{ route('offices.vice_chancellor') }}">Vice Chancellor</a> @break
                    @case('Pro VC') <a href="{{ route('offices.pro_vc') }}">Pro VC</a> @break
                    @case('Treasurer') <a href="{{ route('offices.treasurer') }}">Treasurer</a> @break
                    @case('Registrar') <a href="{{ route('offices.registrar') }}">Registrar</a> @break
                    @case('Controller of Examinations') <a href="{{ route('offices.controller_of_examinations') }}">Controller of Examinations</a> @break
                    @case('Director of Accounts') <a href="{{ route('offices.director_of_accounts') }}">Director of Accounts</a> @break
                    @case('Library') <a href="{{ route('offices.library') }}">Library</a> @break
                    @case('Admissions') <a href="{{ route('offices.admissions') }}">Admissions</a> @break
                    @case('IQAC') <a href="{{ route('offices.iqac') }}">IQAC</a> @break
                @endswitch
            </li>
            <li class="breadcrumb-item active" aria-current="page">{{ $office->name }}</li>
        </ol>
    </nav>

    <div class="office-details-page">
        <div class="container">
            <div class="office-header">
                <img src="{{ asset('storage/' . $office->image) }}" alt="Office Image">
                <h2 class="office-name">{{ $office->name }}</h2>
                <p class="office-position pb-2">{{ $office->position }}</p>
                <div class="office-contact">
                                @if($office->contact)
                                <i class="fa-solid fa-phone"></i> <strong>Contact:</strong> <a href="tel:{{ $office->contact }}">{{ $office->contact }}</a>
                                @endif
                            </div>
            </div>

            <div class="office-body">

            <!--{{-- Degrees Section --}}-->
            @if(is_array($office->degrees) && collect($office->degrees)->filter(fn($d) =>
                !empty($d['degree_name']) || !empty($d['degree_university']) || !empty($d['degree_details'])
            )->count() > 0)
                <div class="office-section">
                    <h3><i class="fa-solid fa-graduation-cap"></i> Degrees</h3>
                    @foreach($office->degrees as $deg)
                        @php
                            $name = trim($deg['degree_name'] ?? '');
                            $inst = trim($deg['degree_university'] ?? '');
                            $details = trim($deg['degree_details'] ?? '');
                        @endphp
                        @if($name || $inst || $details)
                            <div class="mb-4">
                                @if($name)
                                    <h5 class="fw-bold mb-1">{{ $name }}</h5>
                                @endif
                                @if($inst)
                                    <h6 class="fw-semibold mb-1">{{ $inst }}</h6>
                                @endif
                                @if($details)
                                    <p class="mb-0">{!! nl2br(e($details)) !!}</p>
                                @endif
                            </div>
                        @endif
                    @endforeach
                </div>
            @endif


                <!-- Research Section -->
                @if(is_array($office->research_interests) && collect($office->research_interests)->filter(fn($r) => !empty($r['title']) || !empty($r['description']))->count() > 0)
                    <div class="office-section">
                        <h3><i class="fa-solid fa-flask"></i> Research</h3>
                        @foreach($office->research_interests as $r)
                            @if(!empty($r['title']) || !empty($r['description']))
                                <div class="mb-4 p-3 border rounded">
                                    <h5 class="mb-1">
                                        <a href="{{ $r['url'] ?? '#' }}" target="_blank" rel="noopener">
                                            {{ $r['title'] ?? 'Untitled' }}
                                        </a>
                                    </h5>
                                    <p class="mb-2">{!! nl2br(e($r['description'] ?? '')) !!}</p>
                                    @if(!empty($r['url']))
                                        <a href="{{ $r['url'] }}" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary">
                                            Read more <i class="fa-solid fa-arrow-right"></i>
                                        </a>
                                    @endif
                                </div>
                            @endif
                        @endforeach
                    </div>
                @endif
                
                <!-- Biography Section -->
                @if(!empty($office->biography))
                    <div class="office-section biography">
                        <h3><i class="fa-solid fa-user"></i> Biography</h3>
                        <p>{!! nl2br(e($office->biography)) !!}</p>
                    </div>
                @endif

                <!-- Social Links -->
                <div class="office-contact social mt-3">
                    @if($office->facebook)
                        <a href="{{ $office->facebook }}"><i class="fab fa-facebook"></i></a>
                    @endif
                    @if($office->email)
                        <a href="mailto:{{ $office->email }}"><i class="fas fa-envelope"></i></a>
                    @endif
                    @if($office->linkedin)
                        <a href="{{ $office->linkedin }}"><i class="fab fa-linkedin"></i></a>
                    @endif
                    @if($office->whatsapp)
                        <a href="https://wa.me/{{ $office->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
