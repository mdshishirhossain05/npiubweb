<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Contact Us Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome CDN Link -->
  <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.2/css/all.css">
  <style>
    body {
      /*background-color: #f8f9fa;*/
    }
    #contactOffice{
        background-color: #ffffff;
        background-image: url("https://www.transparenttextures.com/patterns/dimension.png");
        
    }
    .offices{
      max-width: 900px;

    }

    .office-details {
        padding: 20px;
    }

    .office-name {
        font-size: 1.2rem;
        font-weight: bold;
        color: #054D94;
        margin-bottom: 5px;
    }

    .office-position,
    .office-type {
        font-size: 1rem;
        color: #333;
        border-bottom: 1px solid #054D94;
        display: inline-block;
    }

    .office-contact {
        margin-top: 15px;
        color: #054D94;
    }

    .social {
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
    }
        
    .social a {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        background: #eff2f8;
        border-radius: 50%;
        text-decoration: none;
    }
        
    .social a i {
        color: #054D94;
        font-size: 16px;
        margin: 0 2px;
    }
        
    .social a:hover {
        background: #054D94;
    }
        
    .social a:hover i {
        color: #fff;
    }
        
    .social a+a {
        margin-left: 8px;
    }

    @media screen and (max-width: 767px) {
      .container .left-side::before {
        height: 2px;
        width: 80%;
        right: auto;
        left: 50%;
        top: 50%;
        transform: translateX(-50%) rotate(180deg);
      }
    }


    .office-item {
      margin-bottom: 1rem;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .office-item .card-header {
      cursor: pointer;
      position: relative;
      padding-right: 40px; /* Space for the icons */
    }
    .office-item .card-header .btn-link {
      color: #292525;
      font-weight: 600;
      text-decoration: none;
      display: block;
    }
    .office-item .card-header .btn-link:hover {
      text-decoration: none;
    }
    .office-item .card-header .icon {
      position: absolute;
      top: 50%;
      right: 2rem;
      transform: translateY(-50%);
      font-size: 1.2em;
    }

    .office-heading{
      font-weight: 700;
      color: #054D94;
    }

    .card , .card-header{
      border: none !important;
    }
  </style>
</head>
<body>
    
<div id="contactOffice" class="pt-5 pb-5">
    <div class="container offices">
        <h2 class="text-center mb-4 office-heading">Office Contacts Directory</h2> 
        <div id="accordionOffice" class="row">
            <div class="col-md-12 mx-auto">
                @foreach($types as $type)
                    <div class="office-item">
                        <div class="card bg-light">
                            <div class="card-header" id="heading-{{ $loop->index }}">
                                <h5 class="mb-0 d-flex justify-content-between align-items-center">
                                    <button class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapse-{{ $loop->index }}" aria-expanded="false" aria-controls="collapse-{{ $loop->index }}">
                                        Office of the {{ $type->type }}
                                    </button>
                                    <span class="icon">
                                        <i class="fa-regular fa-plus"></i>
                                    </span>
                                </h5>
                            </div>
                            <div id="collapse-{{ $loop->index }}" class="collapse" aria-labelledby="heading-{{ $loop->index }}" data-parent="#accordionOffice">
                                <div class="card-body">
                                    <div class="row">
                                        @foreach($offices->where('type', $type->type) as $office)
                                        <div class="col-md-12">
                                            <div class="office-details">
                                                <h3 class="office-name">{{ $office->name }}</h3>
                                                <p class="office-position pb-2">{{ $office->position }}</p>
                                                <div class="office-contact">
                                                    <i class="fa-solid fa-phone"></i> <strong>Contact:</strong> <a href="tel:{{ $office->contact }}">{{ $office->contact }}</a>
                                                </div>
                                                <div class="office-contact social mt-3">
                                                    @if($office->facebook)
                                                        <a href="{{ $office->facebook }}"><i class="fab fa-facebook"></i></a>
                                                    @endif
                                                    @if($office->email)
                                                        <a href="mailto:{{ $office->email }}"><i class="fas fa-envelope"></i></a>
                                                    @endif
                                                    @if($office->linkedin)
                                                        <a href="{{ $office->linkedin }}"><i class="fab fa-linkedin"></i></a>
                                                    @endif
                                                    @if($office->whatsapp)
                                                        <a href="https://wa.me/{{ $office->whatsapp }}"><i class="fab fa-whatsapp"></i></a>
                                                    @endif
                                                </div>
                                                <!-- <div class="">
                                                    <a href="{{ route('offices.show', $office->slug) }}">
                                                        <button class="btn btn-primary office-btn mt-3">View More</button>
                                                    </a>
                                                </div> -->
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

  

  <!-- Bootstrap JS (optional, only needed if you want to use Bootstrap's JS features) -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    $(document).ready(function(){
      $('.office-item').click(function(){
        var collapse = $(this).find('.collapse');
        $('.collapse').not(collapse).collapse('hide'); // Close all open collapse items except the clicked one
        collapse.collapse('toggle'); // Toggle the clicked item's collapse
        $('.icon i').not($(this).find('.icon i')).removeClass('fa-minus').addClass('fa-plus'); // Reset all icons to plus except the clicked one
        $(this).find('.icon i').toggleClass('fa-plus fa-minus'); // Toggle icon for the clicked item
      });
    });
  </script>
</body>
</html>
