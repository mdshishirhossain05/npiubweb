@extends('layouts.default')

@section('title', 'একাডেমিক কাউন্সিল - এনপিআইইউবি')

@section('content')

<section class="page-header py-5">
    <div class="container">
        <h1 class="mb-3">একাডেমিক কাউন্সিল</h1>
        <p class="lead">
            এনপিআইইউবির একাডেমিক কাউন্সিল হলো বিশ্ববিদ্যালয়ের শিক্ষা, পাঠ্যক্রম, পরীক্ষা এবং একাডেমিক 
            নীতিমালা প্রণয়ন ও অনুমোদনের সর্বোচ্চ একাডেমিক কর্তৃপক্ষ।
        </p>
    </div>
</section>

<section class="py-4">
    <div class="container">

        <h2 class="h4 mb-3">একাডেমিক কাউন্সিলের সম্মানিত সদস্যবৃন্দ</h2>

        <div class="table-wrapper shadow-sm bg-white p-3 rounded-3">

            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0 academic-table">
                    <thead class="table-light">
                        <tr>
                            <th class="text-center th-serial-ac">ক্রম</th>
                            <th class="th-role-ac">ভূমিকা</th>
                            <th class="th-name-ac">নাম</th>
                            <th class="th-details-ac">পদবি / পরিচিতি</th>
                        </tr>
                    </thead>

                    <tbody>

                        {{-- Row 1 --}}
                        <tr>
                            <td class="text-center">১</td>
                            <td>সভাপতি</td>
                            <td>প্রফেসর ড. মোঃ ফরহাদ হোসেন</td>
                            <td>উপাচার্য, এনপিআইইউবি</td>
                        </tr>
                    
                        {{-- Row 2 --}}
                        <tr>
                            <td class="text-center">২</td>
                            <td>সদস্য</td>
                            <td>বীর মুক্তিযোদ্ধা প্রফেসর ড. ফরমুজুল হক</td>
                            <td>ডীন, ইঞ্জিনিয়ারিং অনুষদ, এনপিআইইউবি</td>
                        </tr>
                    
                        {{-- Row 3 (UPDATED: comma only) --}}
                        <tr>
                            <td class="text-center">৩</td>
                            <td>সদস্য</td>
                            <td>ড. মোঃ রমজান আলী</td>
                            <td>
                                সাবেক ডীন, ঢাকা বিশ্ববিদ্যালয়, সাবেক অধ্যক্ষ, টিটিটিসি, 
                                সহযোগী অধ্যাপক, সোনারগাঁও বিশ্ববিদ্যালয়, ঢাকা, 
                                বোর্ড অব ট্রাস্টিজ কর্তৃক মনোনীত, এনপিআইইউবি
                            </td>
                        </tr>
                    
                        {{-- Row 4 --}}
                        <tr>
                            <td class="text-center">৪</td>
                            <td>সদস্য</td>
                            <td>ইঞ্জিঃ মোঃ মাহবুবুর রহমান</td>
                            <td>বিভাগীয় প্রধান, কম্পিউটার সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগ, এনপিআইইউবি</td>
                        </tr>
                    
                        {{-- Row 5 --}}
                        <tr>
                            <td class="text-center">৫</td>
                            <td>সদস্য</td>
                            <td>মোঃ তৌহিদুল ইসলাম</td>
                            <td>বিভাগীয় প্রধান, ব্যবসায় প্রশাসন বিভাগ, এনপিআইইউবি</td>
                        </tr>
                    
                        {{-- Row 6 --}}
                        <tr>
                            <td class="text-center">৬</td>
                            <td>সদস্য</td>
                            <td>মোঃ ফাহাদ হোসেন</td>
                            <td>বিভাগীয় প্রধান, ইংরেজি বিভাগ, এনপিআইইউবি</td>
                        </tr>
                    
                        {{-- Row 7 --}}
                        <tr>
                            <td class="text-center">৭</td>
                            <td>সদস্য</td>
                            <td>ইঞ্জিঃ খালেদ সাইফুল্লাহ</td>
                            <td>বিভাগীয় প্রধান, ইইই বিভাগ, এনপিআইইউবি</td>
                        </tr>
                    
                        {{-- Row 8 --}}
                        <tr>
                            <td class="text-center">৮</td>
                            <td>সদস্য</td>
                            <td>প্রফেসর মোঃ শহীদুজ্জামান</td>
                            <td>
                                অধ্যক্ষ, সরকারি দেবেন্দ্র কলেজ, মানিকগঞ্জ,
                                বোর্ড অব ট্রাস্টিজ কর্তৃক মনোনীত সদস্য, এনপিআইইউবি
                            </td>
                        </tr>
                    
                        {{-- Row 9 --}}
                        <tr>
                            <td class="text-center">৯</td>
                            <td>সদস্য</td>
                            <td>মোঃ ইউনুস আল মামুন</td>
                            <td>
                                অধ্যক্ষ, তেতুলঝোরা কলেজ, সাভার, ঢাকা,
                                বোর্ড অব ট্রাস্টিজ কর্তৃক মনোনীত সদস্য, এনপিআইইউবি
                            </td>
                        </tr>
                    
                        {{-- Row 10 --}}
                        <tr>
                            <td class="text-center">১০</td>
                            <td>সদস্য</td>
                            <td>মোঃ মোশাররফ হোসেন</td>
                            <td>
                                পরীক্ষা নিয়ন্ত্রক, সিন্ডিকেট কর্তৃক মনোনীত, এনপিআইইউবি
                            </td>
                        </tr>
                    
                        {{-- Row 11 --}}
                        <tr>
                            <td class="text-center">১১</td>
                            <td>সদস্য</td>
                            <td>মোঃ নূর উদ্দিন</td>
                            <td>
                                অধ্যক্ষ, সিঙ্গাইর সরকারি কলেজ, সিঙ্গাইর, মানিকগঞ্জ
                            </td>
                        </tr>
                    
                        {{-- Row 12 --}}
                        <tr>
                            <td class="text-center">১২</td>
                            <td>সদস্য সচিব</td>
                            <td>মুহাম্মাদ আবদুল গফুর</td>
                            <td>রেজিস্ট্রার, এনপিআইইউবি</td>
                        </tr>
                    
                    </tbody>

                </table>
            </div>

        </div>

    </div>
</section>

@endsection

@push('styles')
<style>
    .table-wrapper {
        border-radius: 12px;
        border: 1px solid #e5e7eb;
    }

    /* Desktop widths */
    .th-serial-ac { width: 70px; }
    .th-role-ac { width: 170px; }
    .th-name-ac { width: 230px; }
    .th-details-ac { width: 260px; }

    .table-bordered tbody tr:hover {
        background-color: #f0f7ff;
        transition: 0.2s ease-in-out;
    }

    /* Mobile responsive */
    @media (max-width: 768px) {

        .th-serial-ac,
        .academic-table td:nth-child(1) {
            min-width: 80px !important;
        }

        .th-role-ac,
        .academic-table td:nth-child(2) {
            min-width: 140px !important;
        }

        .th-name-ac,
        .academic-table td:nth-child(3) {
            min-width: 200px !important;
        }

        .th-details-ac,
        .academic-table td:nth-child(4) {
            min-width: 240px !important;
        }

        .academic-table td,
        .academic-table th {
            font-size: 0.95rem !important;
            padding: 0.65rem 0.75rem !important;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
        }
    }
</style>
@endpush
